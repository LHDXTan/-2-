package dao;

public interface IBaseDao {
	public String getAllCity(String mgg);

}
