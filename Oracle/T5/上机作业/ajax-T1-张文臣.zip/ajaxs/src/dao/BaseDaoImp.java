package dao;

public class BaseDaoImp implements IBaseDao {

	@Override
	public String getAllCity(String mgg) {
		// TODO Auto-generated method stub
		return null;
	}

}
