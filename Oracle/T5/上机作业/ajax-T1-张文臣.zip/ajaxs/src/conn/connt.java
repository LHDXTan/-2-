package conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class connt {
	private static final String driverClass = "oracle.jdbc.driver.OracleDriver";
    private static final String jdbcUrl = "jdbc:oracle:thin:@liumo:1521:ORCL";
    private static final String user = "scott";
    private static final String password = "tiger";
 
    public static Connection getConn() {
        // 1.注册驱动
        try {
            Class.forName(driverClass);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
 
        // 2.创建Connection(数据库连接对象)
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(jdbcUrl, user, password);
            conn.setAutoCommit(false);
            return conn;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(conn);
		return conn;
}
    public static void main(String[] ages){
    	connt.getConn();
    	
    }
}
