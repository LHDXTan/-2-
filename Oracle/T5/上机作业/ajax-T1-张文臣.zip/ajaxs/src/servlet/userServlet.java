package servlet;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.BaseDaoImp;
import dao.IBaseDao;

public class userServlet {
//	 private void checkuser(HttpSeretRequest request,HttpServletResponse response){
//		 try{
//			 
//		 }
//	 }
	private void changePro(HttpServletRequest request,HttpServletResponse response){
		try{
			PrintWriter out = response.getWriter();
			//
			String ProNo = request.getParameter("proNo");
			//
			IBaseDao dao = new BaseDaoImp();
			String list = dao.getAllCity(ProNo);
			//
			StringBuffer sb = new StringBuffer();
			//
			//
			out.println(sb.toString());
			out.flush();
			out.close();
		}catch(Exception e){
			
		}
		
	}

}
