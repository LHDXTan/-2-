package action;


public class UserAction {
	String result;
	String uname;
	public String checkUser() {
		if ("admin".equals(uname)) {
			result = "该用户名已被占用！";
			System.out.println(1);
		}else {
			result = "可以注册！";
		}
		
		return "ajax";
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
}
