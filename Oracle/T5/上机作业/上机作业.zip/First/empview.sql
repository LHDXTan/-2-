create or replace view empview as
select "eid","ename","sex","hire","sar","did" from emp where "sar">5000
   with check option;
   
   select * from empview;
   
   select * from emp;
   
create unique index deptindex on dept("dname");
create index empindex on emp("ename");

drop index deptindex;
drop index empindex;

create user class2 identified by class2 account unlock;
grant connect to scott;
grant connect to class2;
grant ulimited tablespace to class2;
grant resource to class2;
grant resource to scott;

grant create public synonym to scott;
create public synonym sc for emp;
grant select on sc to class2;
grant select on sc2 to scott;

select * from sc;

create synonym sc2 for emp;
select * from sc2;

drop public synonym sc;
drop synonym sc2;
