select * from emp;

select "eid","ename" from emp where "sar">(select avg("sar") from emp) order by "eid" desc;

create sequence seqpig
increment by 1
start with 15
minvalue 0
maxvalue 20
cycle
nocache;

create tablespace test
nologging
datafile 'E:/Study/PLSQL/Five/OA.dbf' size 5M reuse
autoextend on next 500k maxsize 10M extent
management local;

create temporary tablespace testtemp
tempfile 'E:/Study/PLSQL/Five/OAtemp.dbf' size 1M
extent management local;
