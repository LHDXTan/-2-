create sequence seqname
increment by 1
start with 3
minvalue 0
maxvalue 10
cycle
nocache;

select seqname.currval from dual;
select seqname.nextval from dual;

grant create sequence to scott;

create tablespace test
nologging
datafile 'E:/Study/PLSQL/Five/test01.dbf' size 5M reuse
autoextend on next 32k maxsize 10M
extent management local;

create temporary tablespace testtemp
tempfile 'E:/Study/PLSQL/Five/testtemp01.dbf' size 1M
extent management local;

create undo tablespace testundo
datafile 'E:/Study/PLSQL/Five/testundo01.log' size 500k;

alter tablespace test offline normal
alter tablespace test
rename datafile 'E:/Study/PLSQL/Five/TESTTEMP01.dbf' to
'E:/Study/PLSQL/Five/testtemp02.dbf'
alter tablespace test online
