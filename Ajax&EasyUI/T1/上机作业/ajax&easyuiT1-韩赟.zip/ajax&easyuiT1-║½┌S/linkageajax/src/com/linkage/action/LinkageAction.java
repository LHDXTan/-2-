/**
 * 
 */
package com.linkage.action;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.linkage.dao.ServlceDao;
import com.opensymphony.xwork2.ActionSupport;

/**
 * @project linkageajax 项目名称
 * @name LinkageAction 类名称   
 * @describe (用一句话描述本类的作用)
 * @author Chichi 作者
 * @time 2018-3-23 下午2:25:47
 */
public class LinkageAction extends ActionSupport{
	private ServlceDao dao=new ServlceDao();
	private String code;
      public void privince() throws IOException{
      List<String> privince = dao.privince();
      HttpServletResponse response = ServletActionContext.getResponse();
      response.setCharacterEncoding("utf-8");
      response.getWriter().print(privince);
      }
      
      public void city() throws IOException{
    	  List<String> city = dao.city(code);
    	  HttpServletResponse response = ServletActionContext.getResponse();
          response.setCharacterEncoding("utf-8");
          response.getWriter().print(city);
      }
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
      
      
}
