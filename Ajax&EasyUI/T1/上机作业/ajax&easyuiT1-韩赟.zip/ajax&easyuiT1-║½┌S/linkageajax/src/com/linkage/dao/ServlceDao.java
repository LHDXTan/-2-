/**
 * 
 */
package com.linkage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import org.json.JSONObject;

import com.linkage.util.OracleConnection;

/**
 * @project linkageajax 项目名称
 * @name ServlceDao 类名称   
 * @describe (用一句话描述本类的作用)
 * @author Chichi 作者
 * @time 2018-3-23 下午3:00:46
 */
public class ServlceDao {
    public List<String> privince(){
    	String sql="select * from province";
    	List<String> list=new ArrayList<String>();
    	Connection conn = OracleConnection.conn();
    	try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
	    while(rs.next()){
	    	JSONObject  jsonObj=new JSONObject();
	    	jsonObj.put("id", rs.getString("code"));
	    	jsonObj.putOpt("name", rs.getString("name"));
	    	list.add(jsonObj.toString());
	        }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return list;
    }
    
    public List<String> city(String data){
    	String sql="select * from city where provincecode=?";
    	List<String> list=new ArrayList<String>();
    	Connection conn = OracleConnection.conn();
    	PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, data);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				JSONObject  jsonObj=new JSONObject();
				jsonObj.put("id", rs.getString("code"));
				jsonObj.put("name", rs.getString("name"));
				list.add(jsonObj.toString());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
    	return list;
    }
}
