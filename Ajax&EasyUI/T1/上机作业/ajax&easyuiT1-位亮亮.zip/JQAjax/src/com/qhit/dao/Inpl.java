package com.qhit.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.qhit.test.orclejdbc;

public class Inpl {
	
	Connection conn = orclejdbc.aaa();

  public String sel(String str){
	    String s="";
		String sql="select name from a where name=?";
		try {
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, str);
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
		 s= rs.getString("name");
		}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;	
	}

}
