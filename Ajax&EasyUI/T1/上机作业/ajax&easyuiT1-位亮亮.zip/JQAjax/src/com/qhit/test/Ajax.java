package com.qhit.test;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts2.ServletActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.qhit.dao.Inpl;

public class Ajax extends ActionSupport {

	
	
	public void aaa() throws IOException{

		HttpServletRequest request = ServletActionContext.getRequest();
		String parameter = request.getParameter("name");
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		Inpl i=new Inpl();
		String sel = i.sel(parameter);
		if(sel==""){
			out.print("可以注册");	
		}else{
			out.print("NO PROBLEM");
		}	
		out.flush();
		out.close();	
	}
	
	
}
