package com.qhit.test;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;





public class orclejdbc{
	
	private static Connection connection=null;
	
	public static Connection aaa(){
		
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url="jdbc:oracle:thin:@localhost:1521:orcl";
		String nam="scott";
		String pwd="tiger";
	    connection = DriverManager.getConnection(url, nam, pwd);
 	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return connection;
	
	}
	
}
