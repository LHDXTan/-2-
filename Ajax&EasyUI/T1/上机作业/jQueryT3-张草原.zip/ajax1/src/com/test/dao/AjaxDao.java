package com.test.dao;

public interface AjaxDao {
	boolean checkuser(String uname);
}
