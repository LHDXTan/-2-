package com.test.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.test.pojo.StuFz;


public class AjaxDaoImp implements AjaxDao {

	@Override
	public boolean checkuser(String uname) {
		boolean b = true;
		StuFz st = new StuFz();
		Connection con = Lj.getConnection();
		String sql = "select * from student where uname ='"+uname+"'";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				st.setUname(rs.getString("uname"));
				b=false;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
	}
}
