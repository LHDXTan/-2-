package com.dxw.dao;

public class actiondao {
	 public boolean list(String name){
		  
			return false;  
		  }

}
