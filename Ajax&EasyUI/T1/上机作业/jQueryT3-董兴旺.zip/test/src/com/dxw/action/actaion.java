package com.dxw.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.dxw.dao.actiondao;
import com.opensymphony.xwork2.Action;

public class actaion implements Action{

		
		public String execute() throws Exception {
			
			return null;
		}
		public String aluka() throws IOException{
			HttpServletRequest request=ServletActionContext.getRequest();
			HttpServletResponse response=ServletActionContext.getResponse();
			response.setContentType("text/html;charset=GBK");
			PrintWriter out = response.getWriter();
			actiondao dao=new actiondao();
			String name=request.getParameter("uname");
			boolean b=dao.list(name);
			if(b){
				out.print("no");
			}else{
				out.print("yes");
			}
			out.flush();
			out.close();
			return null;
		}
	}

