package action;

import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport {
	private String uname;
	private String panduan;
	public String user(){
		if(uname.equals("666")){
			 panduan="此账号已经存在";
			System.out.println("666");
		}else  if(uname.equals("")){
			panduan="不可以为空";
		}else {
			 panduan="您可以注册";
		}
		return "ccc";
		
		
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPanduan() {
		return panduan;
	}
	public void setPanduan(String panduan) {
		this.panduan = panduan;
	}
	
	

}
