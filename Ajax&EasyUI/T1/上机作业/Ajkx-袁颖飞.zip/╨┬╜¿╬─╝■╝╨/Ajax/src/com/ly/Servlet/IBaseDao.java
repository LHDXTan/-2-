package com.ly.Servlet;

import java.util.List;

public interface IBaseDao {

	boolean loginuser(String uname);

	List  getAllCity(String proNo);

}
