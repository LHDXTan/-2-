package com.ly.Servlet;

import java.util.List;

public class BaseDaoImp implements IBaseDao {

	
	public List getAllCity(String proNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean loginuser(String uname) {
		// TODO Auto-generated method stub
		return false;
	}

}
