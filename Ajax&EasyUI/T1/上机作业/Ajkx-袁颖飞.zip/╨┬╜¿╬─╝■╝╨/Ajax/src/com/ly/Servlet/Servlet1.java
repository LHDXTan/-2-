package com.ly.Servlet;

import java.awt.List;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Servlet1 extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		/*response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.flush();
		out.close();*/
		doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		String type=  request.getParameter("type");
		  
		  if(type.equals("checkuser")){
			  checkuser(request,response);
		  }else if(type.equals("sanji")){
			  sanji(request,response);
		  }
	}
	
	
	
	
	//У���û���
	public void checkuser(HttpServletRequest request,
			HttpServletResponse response){
		
		
		 try {
			 PrintWriter on =response.getWriter();
			 
		    String uname= request.getParameter("uname");
			 System.out.println(uname);
//		    IBaseDao dao = new BaseDaoImp();
//		    boolean p1=dao.loginuser(uname);
		    String name="admin";
		    
		    if(uname.equals(name)){
		    	on.println("�û����Ѵ��ڣ�����");
		    }else{
		    	on.println("����ʹ�ø��û���������");
		    }
		    on.flush();
		    on.close();
			 
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	
	
	//j
	public void sanji(HttpServletRequest request,
			HttpServletResponse response){
		
		try {
			PrintWriter out = response.getWriter();
			
			String Sfen = request.getParameter("pro");
			System.out.println("��ѡ���ʡ��"+Sfen);
			
			//---�˴�����̨ȡֵ�ķ����ķ�����������
//			IBaseDao dao = new BaseDaoImp();
//			List list = (List) dao.getAllCity(Sfen);
		
			StringBuffer sb = new StringBuffer();
			
			sb.append(" \n");
			sb.append("[ \n");
			sb.append(" {\"pid\":\"1\",\"pcity\":[\"������\",\"������\",\"������\",\"������\",\"��ƽ��\"]} \n");
			sb.append(",{\"pid\":\"2\",\"pcity\":[\"������\",\"ʮ����\",\"������\",\"�人��\"]} \n");
			sb.append(",{\"pid\":\"3\",\"pcity\":[\"ʯ��ׯ\",\"������\",\"������\",\"��̨��\"]} \n");
			sb.append("] \n");
		
			out.println(sb.toString());
			
			out.flush();
			out.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
