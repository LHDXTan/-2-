package com.lzc.dao;

public class actiondao {
  public boolean list(String name){
	  
	return false;  
  }
}
