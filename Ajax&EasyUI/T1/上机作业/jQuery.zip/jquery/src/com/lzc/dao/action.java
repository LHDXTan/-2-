package com.lzc.dao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.Action;

public class action implements Action {

	private String  reqtype;
	public String execute() throws Exception {
		
		return null;
	}
	public String zhuce(){
		HttpServletRequest request=ServletActionContext.getRequest();
		HttpServletResponse response=ServletActionContext.getResponse();
		response.setContentType("text/html;charset=GBK");		
		try {
			PrintWriter out = response.getWriter();
			actiondao dao=new actiondao();
			String name=request.getParameter("uname");
			boolean b=dao.list(name);
			if(b){
				out.print("");
			}else{
				out.print("可以注册!");
			}
			out.flush();
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	public String getReqtype() {
		return reqtype;
	}
	public void setReqtype(String reqtype) {
		this.reqtype = reqtype;
	}
	
}
