package com.ajax.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TestServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public TestServlet() {
		super();
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		response.setCharacterEncoding("utf-8");
		String reqType=  request.getParameter("reqType");
		
		if(reqType.equals("checkuser")){
			checkuser(request, response);
		}else if(reqType.equals("changePro")){
			changePro(request, response);
		}else if(reqType.equals("getJsonVal")){
			getJsonVal(request, response);
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	
	public void getJsonVal(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
			System.out.println(request.getParameter("nam"));
			PrintWriter out = response.getWriter();
			StringBuffer sb  = new StringBuffer();
			sb.append("[{");
			sb.append("\"ename\":\"章安\"");
			sb.append(",\"esex\":\"男\"");
			sb.append(",\"escore\":\"15\"");
			sb.append("}");
			sb.append(",{");
			sb.append("\"ename\":\"李四\"");
			sb.append(",\"esex\":\"女\"");
			sb.append(",\"escore\":\"17\"");
			sb.append("}]");
			System.out.println("服务端:\n"+sb.toString());
			response.setCharacterEncoding("utf-8");
			out.println(sb.toString());
			out.flush();
			out.close();
	
	}
	
	//校验用户名重写的方法
	private void checkuser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		//获取输入的用户名,并判断
		String nam= request.getParameter("nam");
		TestServlet ts= new TestServlet();
		boolean b = ts.checkuser(nam);
		//-------------------------------
		if(b){
			out.println("当前用户名已经存在");
		}else{
			out.println("可以注册");
		}
		out.flush();
		out.close();
	}
	
	//省市级联动
	private void changePro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		//获取当前切换的省份
		String proNo= request.getParameter("proNo");
		TestServlet ts= new TestServlet();
		List list= ts.getAllCity(proNo);
		StringBuffer sb = new StringBuffer();
		sb.append(" \n");
		sb.append("[ \n");
		sb.append(" {\"pid\":\"1\",\"pcity\":[\"东城区\",\"西城区\",\"朝阳区\",\"海淀区\",\"昌平区\"]} \n");
		sb.append(",{\"pid\":\"2\",\"pcity\":[\"襄阳市\",\"十堰市\",\"枣阳市\",\"武汉市\"]} \n");
		sb.append(",{\"pid\":\"3\",\"pcity\":[\"石家庄\",\"保定市\",\"邯郸市\",\"邢台市\"]} \n");
		sb.append("] \n");
		//----------选择城市的下拉列表数据构建完毕
		out.println(sb.toString());
		out.flush();
		out.close();
		
	}
	

	public boolean checkuser(String nam) {
		// TODO Auto-generated method stub
		return false;
	}

	public List getAllCity(String proNo) {
		// TODO Auto-generated method stub
		return null;
	}


}
