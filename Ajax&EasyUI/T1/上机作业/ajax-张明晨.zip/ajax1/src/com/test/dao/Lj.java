package com.test.dao;

import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class Lj {
	public static Connection getConnection(){
		Connection con=null;
		try {
			Context initContext=new InitialContext();
			DataSource ds=(DataSource) initContext.lookup("java:/comp/env/jdbc/ailx");
			con=ds.getConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	public static void close(Connection con){
		try {
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
