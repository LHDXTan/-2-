package com.qhit.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class JQueryservlet extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String name = request.getParameter("username");
		if(name.equals("111")){
			out.println("不可以注册");
		}else if(name.equals("222")){
			out.println("不可以注册");
		}else if(name.equals("333")){
			out.println("不可以注册");
		}else{
			out.println("可以注册");
		}
		out.flush();
		out.close();
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String name = request.getParameter("username");
		if(name.equals("111")){
			out.println("不可以注册");
		}else if(name.equals("222")){
			out.println("不可以注册");
		}else if(name.equals("333")){
			out.println("不可以注册");
		}else{
			out.println("可以注册");
		}
		out.flush();
		out.close();
	}

}
