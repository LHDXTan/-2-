package com.test;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.dao.BaseDaoImp;
import com.dao.IBaseDao;
import com.opensymphony.xwork2.Action;

public class AjAx implements Action {

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public String name() throws Exception {
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpServletResponse  response=ServletActionContext.getResponse();
	response.setContentType("text/html; charset=GBK"); 
	request.setCharacterEncoding("GBK");

	
	System.out.println("1");
	try {
		PrintWriter out = response.getWriter();
		String uname = request.getParameter("uname");
		IBaseDao dao = new BaseDaoImp();
		boolean b = dao.checkuser(uname);
		//-------------------------------
		if(b){
			out.println("1");
		}else{
			out.println("2");
		}
		out.flush();
		out.close();
	} catch (Exception e) {
		// TODO: handle exception
	}
	
	
	
	
	
		return null;
		
	}
	
	

}
