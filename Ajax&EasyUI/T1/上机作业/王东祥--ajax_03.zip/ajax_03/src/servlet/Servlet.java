package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;

import dao.IDao;

public class Servlet extends HttpServlet {

	
	private void checkuser(HttpServletRequest request,HttpServletResponse response){
		  
		try {
			PrintWriter out=response.getWriter();
			String uname=request.getParameter("uname");
			IDao dao=new IDao();
			boolean b=Boolean.parseBoolean("dao.checkuser(uname)");
			if(b){
				
				out.println("当前用户已经存在，请重新注册");
			}else {
				
				out.print("可以注册");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private void checkPro(HttpServletRequest request,HttpServletResponse response){
		
		try {
			PrintWriter out=response.getWriter();
			String pro=request.getParameter("pro");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
