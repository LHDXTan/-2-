package dao;

import java.util.List;

import bean.User;

public interface Dao {
 
	
	public User checkuser(String uname);
}
