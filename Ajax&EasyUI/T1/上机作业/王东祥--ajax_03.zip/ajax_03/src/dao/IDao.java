package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.ConnectionFactory;

import bean.User;

public class IDao implements Dao {

	@Override
	public User checkuser(String uname) {
		
		Connection con =ConnectionFactory.getConnection();
		String sql="select * from users";
		User user=new User();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, "uname");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				user.setUid(rs.getInt("uid"));
				user.setUname(rs.getString("uname"));
			
			}
				  
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
		

	}

}
