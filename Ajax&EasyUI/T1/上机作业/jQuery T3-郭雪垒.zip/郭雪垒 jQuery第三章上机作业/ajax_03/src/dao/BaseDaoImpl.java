package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import bean.Users;

import util.ConnectionFactory;

public class BaseDaoImpl implements IBaseDao {

	@Override
	public boolean checkuser(String uname) {
		Users u=new Users();
		Connection con=ConnectionFactory.getConnection();
		String sql="select nam from users";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				u.setNam(rs.getString(1));
				if(uname.equals(u.getNam())){
					return false;
				}else{
					return true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return (Boolean) null;
		
	}

	@Override
	public List getAllCity(String proNo) {
		// TODO Auto-generated method stub
		return null;
	}

}
