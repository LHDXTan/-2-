package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.BaseDaoImpl;
import dao.IBaseDao;

public class CityServlet extends HttpServlet {

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		response.setCharacterEncoding("utf-8");
		String reqType=request.getParameter("reqType");
//		String reqType=java.net.URLEncoder.encode(request.getParameter("reqType"),"UTF-8");
		if(reqType.equals("checkuser")){
			checkuser(request, response);
		}else if(reqType.equals("changePro")){
			changePro(request, response);
		}
	}
	
	
	private void checkuser(HttpServletRequest request,HttpServletResponse response){
		try {
			PrintWriter out=response.getWriter();
			String uname=request.getParameter("uname");
			IBaseDao dao=new BaseDaoImpl();
			boolean b=dao.checkuser(uname);
			if(b==false){
				out.println("��ǰ�û��Ѿ�����");
				
			}else{
				
				out.println("��ǰ�û�����ע��");
			}
			out.flush();
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private void changePro(HttpServletRequest request,HttpServletResponse response){
		try {
			PrintWriter out=response.getWriter();
			String proNo=request.getParameter("proNo");
			IBaseDao dao=new BaseDaoImpl();
			List list=dao.getAllCity(proNo);
			StringBuffer sb=new StringBuffer();
			out.println(sb.toString());
			out.flush();
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}
	
}
