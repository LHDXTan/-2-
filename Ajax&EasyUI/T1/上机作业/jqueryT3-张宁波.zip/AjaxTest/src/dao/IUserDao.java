package dao;

import java.util.List;


public interface IUserDao {

	public int selectByName(String uname);

	public List getAllCity(String pro);

}
