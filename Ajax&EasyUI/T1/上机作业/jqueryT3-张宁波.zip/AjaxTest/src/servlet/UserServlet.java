package servlet;

import java.awt.List;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.IUserDao;
import dao.UserDaoImpl;

public class UserServlet extends HttpServlet {

	IUserDao idao=new UserDaoImpl();
	public UserServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	 	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	 		String p=request.getParameter("reqType");
	 		if(p.equals("checkuser")){
	 			checkuser(request, response);
	 		}
	 		if(p.equals("changePro")){
	 			changePro(request, response);
	 		}

		}

		private void changePro(HttpServletRequest request,
				HttpServletResponse response){
			/*String city=request.getParameter("city");
			int c=Integer.parseInt(city);
			if(c==1){
			
			}*/
			
				try {
					PrintWriter out=response.getWriter();
					String pro=request.getParameter("pro");
					java.util.List list=idao.getAllCity(pro);
					StringBuffer sb=new StringBuffer();
					out.println(sb.toString());
					out.flush();
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

		}

		public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

			}

		public void init() throws ServletException {
	
	}
		
		private void checkuser(HttpServletRequest request, HttpServletResponse response){
			String uname=request.getParameter("uname");
			System.out.println(uname+"kkkkk");
			int i=idao.selectByName(uname);
			try {
				PrintWriter out=response.getWriter();
				if(i==1){
					out.println("���û��Ѵ���");
				}else{
					out.println("��ӭע��");
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	

}
