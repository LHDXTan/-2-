package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	
	public static Connection getconnectionDB(){
		Connection conn = null;
		String url = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=userinfo";
		String user= "sa";
		String password = "sa";
		try {
		
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			try {
			
				conn = DriverManager.getConnection(url, user, password);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		
		return conn;
		
	}

	
	
}
