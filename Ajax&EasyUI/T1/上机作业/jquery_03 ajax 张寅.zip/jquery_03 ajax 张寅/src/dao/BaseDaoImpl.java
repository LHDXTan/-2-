package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import bean.User_info;
import util.ConnectionFactory;

public class BaseDaoImpl implements IBaseDao {

	public boolean checkuser(String uname) {
	User_info info=null;
	Connection con = ConnectionFactory.getconnectionDB();
	String sql="select username from user_info ";	
	try {
		PreparedStatement p=con.prepareStatement(sql);
		ResultSet re=p.executeQuery();
		while(re.next()){
		   if((re.getString("username").equals(uname))){
			     return false;
		   }else{
			     return true;
		  }
			}
			
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	        return false;
		
	}

	public List getcity(String pro) {
		
		
		
		return null;
	}

}
