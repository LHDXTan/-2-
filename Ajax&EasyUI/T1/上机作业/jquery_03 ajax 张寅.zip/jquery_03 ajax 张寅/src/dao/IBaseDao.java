package dao;

import java.util.List;

public interface IBaseDao {
	public boolean checkuser(String uname);
	public List getcity(String pro);

}
