package com.qhit;

import java.util.List;

public interface IBaseDao {

	boolean checkuser(String uname);

	List getAllCity(String proNo);

}
