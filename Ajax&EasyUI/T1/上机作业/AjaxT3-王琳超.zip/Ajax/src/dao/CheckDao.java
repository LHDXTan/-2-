package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import util.JDBCMySql;

public class CheckDao {
	public static void main(String[]args){
		System.out.println(JDBCMySql.getConnection());
	}
	public int checkName(String name){
		Connection conn;
		int  i = 0;
		try {
			conn = JDBCMySql.getConnection();
			String sql = "select sname from student where sname = ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()){
				i = 1;
			}else {
				i = 2;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return i;
	}
}
