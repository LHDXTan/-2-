package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CheckDao;
import util.JDBCMySql;

public class TestServlet extends HttpServlet {
    
	CheckDao dao = new CheckDao();
	public TestServlet() {
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		      doPost(request,response);
	} 

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
            String cmd = request.getParameter("cmd");
            if(cmd.equals("checkuser")){
            	checkname(request,response);
            }else if(cmd.equals("changepro")){
            	changepro(request,response);
            }
	}
	public void checkname(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		  request.setCharacterEncoding("utf-8");
		  response.setCharacterEncoding("utf-8");
		  PrintWriter out = response.getWriter();
		  String uname = request.getParameter("uname");
		  try {
			int flag = dao.checkName(uname);
			if(flag==1){
				out.println("当前用户名已存在");
			}else{
				out.println("可以使用");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 out.flush();
		 out.close();
	}
	public void changepro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println(1111);
	}
}
