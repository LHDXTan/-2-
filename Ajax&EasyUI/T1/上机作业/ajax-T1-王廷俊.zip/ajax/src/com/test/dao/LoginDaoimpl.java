package com.test.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.test.bean.User;
import com.test.util.ConFactory;



public class LoginDaoimpl {
	
	public boolean seluser(String username){
		boolean b = true;
		User us = new User();
		
		String sql = "select * from userinfo where username='"+username+"'";
		Connection con = ConFactory.getConnection();
		PreparedStatement ps;
		ResultSet rs;
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				us.setUsername(rs.getString("username"));
				b=false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return b;
	}
	public List getAllCity(String proNo) {
		
		
		return null;
	}

}
