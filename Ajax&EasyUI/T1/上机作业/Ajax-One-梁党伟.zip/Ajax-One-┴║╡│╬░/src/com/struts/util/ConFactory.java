package com.struts.util;

import java.sql.Connection;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class ConFactory {
	//创建连接
	public static Connection getConnection(){
		Connection con=null;
		try{
			Context initContext=new InitialContext();
			DataSource ds=(DataSource)initContext.lookup("java:/comp/env/jdbc/ceshi");//
			con = ds.getConnection();
			System.out.println(con);
		}catch(Exception e){
			e.printStackTrace();
			
		}
		return con;
	}
	public static void main(String[] args) {
		getConnection();
	}
	//关闭连接
	public static void close(Connection con){
		try{
			con.close();
		}catch(Exception e){}
	}
}
