package com.zzg.dao;

import java.util.ArrayList;
import java.util.List;

public class LoginDaoImpl implements LoginDao {

	@Override
	public boolean unameGet(String uname) {
		// TODO Auto-generated method stub
		System.out.println("LoginDaoImpl.unameGet()"+uname);
		boolean b=false;
		return b;
	}

	@Override
	public List cutyGet(String cityMax) {
		// TODO Auto-generated method stub
		List list=new ArrayList();
		
		return list;
	}

}
