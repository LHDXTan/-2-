package com.zzg.dao;

import java.util.List;

public interface LoginDao {
       public boolean unameGet(String uname);
       public List cutyGet(String cityMax);
}
