package com.zzg.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.zzg.dao.LoginDaoImpl;

public class UserAction extends ActionSupport {

	private String uname;
	private String reqType;
	private String cityMax;
	 public void mesgGet(){
		 System.out.println(uname+"--"+reqType);
		 if(reqType!=null){
		    HttpServletResponse response=ServletActionContext.getResponse();
		    response.setContentType("text/html;charset=UTF-8");
		 try {
			PrintWriter out =response.getWriter();
			LoginDaoImpl login=new LoginDaoImpl();
			boolean b=login.unameGet(uname);
		 if(b){
				out.println("当前用户已存在");
		 }else{
				out.println("可以使用");
			  }
			out.flush();
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		 
	 }
	 
	 public void cityGet(){
		System.out.println(cityMax); 
		if(cityMax!=null){
			HttpServletResponse res=ServletActionContext.getResponse();
			res.setContentType("text/html;charset=UTF-8");
			try {
				PrintWriter out =res.getWriter();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	 }
	 
	 
	 
	 
	 
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getReqType() {
		return reqType;
	}
	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public String getCityMax() {
		return cityMax;
	}

	public void setCityMax(String cityMax) {
		this.cityMax = cityMax;
	}
	  
	 
}
