package dao;

import java.util.List;

import bean.Userinfo;

public interface IUserlistDao {

	public List<Userinfo> listUser();
	public void useradd(Userinfo userinfo);
	public Userinfo selectbyId(int id);
	public void userupdate(Userinfo userinfo);
	public void userdel(int id);
}
