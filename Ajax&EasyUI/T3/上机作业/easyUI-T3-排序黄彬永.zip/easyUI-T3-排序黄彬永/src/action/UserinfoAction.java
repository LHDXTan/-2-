package action;

import java.util.ArrayList;
import java.util.List;

import bean.Userinfo;

import com.opensymphony.xwork2.ActionSupport;

import dao.IUserlistDao;
import dao.UserlistImpl;

public class UserinfoAction extends ActionSupport{

	private List<Userinfo> userlist = new ArrayList<Userinfo>();
	private Userinfo userinfo = new Userinfo();
	IUserlistDao userlistdao = new UserlistImpl();
	
	public List<Userinfo> getUserlist() {
		return userlist;
	}
	public void setUserlist(List<Userinfo> userlist) {
		this.userlist = userlist;
	}
	public Userinfo getUserinfo() {
		return userinfo;
	}
	public void setUserinfo(Userinfo userinfo) {
		this.userinfo = userinfo;
	}
	
	public String list(){
		userlist = userlistdao.listUser();
		return "list";
	}
	
	public String useradd(){
		userlistdao.useradd(userinfo);
		return "toindex";
	}
	public String toindex(){
		return"index";
	}
	
	public String userupdate(){
		userlistdao.userupdate(userinfo);
		return "toindex";
	}
	
	public String userdel(){
		userlistdao.userdel(userinfo.getId());
		return "toindex";
	}
}
