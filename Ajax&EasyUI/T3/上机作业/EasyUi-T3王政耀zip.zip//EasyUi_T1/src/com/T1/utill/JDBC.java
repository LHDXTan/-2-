package com.T1.utill;

import java.sql.Connection;
import java.sql.DriverManager;



public class JDBC {
	

	
	public static void main(String[] args) {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:orcl";
			String nam="sys as sysdba";
			String pwd="123456";
			Connection con=DriverManager.getConnection(url,nam,pwd);			
			System.out.println(con);
			con.close();
		}catch(Exception e){e.printStackTrace();}
	}


}
