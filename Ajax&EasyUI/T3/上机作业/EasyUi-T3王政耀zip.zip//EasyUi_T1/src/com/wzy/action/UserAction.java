package com.wzy.action;


import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport{
	//添加用户
	public String addUser(){
		return "";
	}
	//修改用户
	public String updUser(){
		return "";
	}
	//删除用户
	public String delUser(){
		return "";
	}



}
