package com.ezui.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.ezui.dao.BaseDaoimpl;
import com.ezui.pojo.Login;
import com.google.gson.Gson;
import com.opensymphony.xwork2.Action;

public class loginAction implements Action {
	
	private Login login;
	private String name;
	private String pwd;
	private String sex;
	private int age;
	private String phone;
	private String adress;
	private int id;
	private String rows;
	private String page;
	
	
	BaseDaoimpl bdi = new BaseDaoimpl();
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpServletResponse response = ServletActionContext.getResponse();

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String add() throws IOException{
		System.out.println("进入添加");
		Login login = new Login();
		login.setName(name);
		login.setPwd(pwd);
		login.setSex(sex);
		login.setAge(age);
		login.setPhone(phone);
		login.setAdress(adress);
		bdi.add(login);
		return "tolist";
	}
	
	public String list() throws IOException{
		
		
		
		System.out.println("进入查询");
		
		System.out.println(rows);
		System.out.println(page);
		
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		ArrayList list =new ArrayList();	
		list=(ArrayList) bdi.getObjects("from Login");
		Gson gson = new Gson();
		String result = gson.toJson(list);
		System.out.println(result);
		out.print(result);
		out.flush();
		out.close();
		return null;
	}
	
	public String update() throws IOException{
		
		System.out.println("进入修改");
		System.out.println(id);
		Login lo = (Login)bdi.getObjectById(Login.class, id);
		lo.setName(name);
		lo.setPwd(pwd);
		lo.setSex(sex);
		lo.setAge(age);
		lo.setPhone(phone);
		lo.setAdress(adress);
		bdi.update(lo);
		
		return "tolist";
	}
	
	public String delete(){
		System.out.println("进入删除");
		Login lo = (Login)bdi.getObjectById(Login.class, id);
		System.out.println(lo);
		
		bdi.delete(lo);
		
		return "tolist";
	}

	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRows() {
		return rows;
	}

	public void setRows(String rows) {
		this.rows = rows;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}
	
	
	
	
	
	

}
