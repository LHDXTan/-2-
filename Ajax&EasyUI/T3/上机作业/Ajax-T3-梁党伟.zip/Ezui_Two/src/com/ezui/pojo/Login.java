package com.ezui.pojo;

/**
 * Login entity. @author MyEclipse Persistence Tools
 */

public class Login implements java.io.Serializable {

	// Fields

	private Integer id;
	private String name;
	private String pwd;
	private String sex;
	private Integer age;
	private String phone;
	private String adress;

	// Constructors

	/** default constructor */
	public Login() {
	}

	/** full constructor */
	public Login(String name, String pwd, String sex, Integer age,
			String phone, String adress) {
		this.name = name;
		this.pwd = pwd;
		this.sex = sex;
		this.age = age;
		this.phone = phone;
		this.adress = adress;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPwd() {
		return this.pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Integer getAge() {
		return this.age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAdress() {
		return this.adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

}