package com.ezui.action;

import java.util.List;

import com.ezui.dao.BaseDaoimpl;
import com.ezui.pojo.Login;
import com.opensymphony.xwork2.Action;

public class loginAction implements Action {
	private Login login;
	private List<Login> loginlist;
	
	BaseDaoimpl bdi = new BaseDaoimpl();

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		
		login.getName();
		return null;
	}
	public String list(){
		
		
		
		System.out.println("jinru");
		loginlist = bdi.getObjects("from login");
		System.out.println(loginlist);
		
		return "tolist";
	}
	
	public String add(){
		bdi.add(login);
		return null;
	}
	public Login getLogin() {
		return login;
	}
	public void setLogin(Login login) {
		this.login = login;
	}
	public List<Login> getLoginlist() {
		return loginlist;
	}
	public void setLoginlist(List<Login> loginlist) {
		this.loginlist = loginlist;
	}
	
	

}
