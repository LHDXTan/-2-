package com.ezui.dao;

import java.io.Serializable;
import java.util.List;

public interface BaseDao {
	
	public int add(Object obj);
	public int update(Object obj);	
	public int delete(Object obj);
	public Object getObjectById(Class clazz,Serializable id);
	public List getObjects(String hql);
		
		
	

}
