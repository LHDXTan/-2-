package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class  Jdbc {
//	连接数据库地址
	static String url="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=shengshixian";
	static Connection conn=null;
	public static Connection getConnection(){
		if(conn==null){
			try {
//				连接驱动
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//				链接的数据库 账号密码
				conn=DriverManager.getConnection(url, "sa", "775800");
				
				System.out.println(conn);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return conn;
		
	}  
	
  public static void main(String[] args) {
	Jdbc.getConnection();
}
	}
	
