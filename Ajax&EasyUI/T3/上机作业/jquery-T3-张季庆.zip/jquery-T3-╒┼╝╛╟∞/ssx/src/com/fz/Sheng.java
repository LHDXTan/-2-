package com.fz;

public class Sheng {
	private String seid;
	
	private String sheng;

	public String getSeid() {
		return seid;
	}

	public void setSeid(String seid) {
		this.seid = seid;
	}

	public String getSheng() {
		return sheng;
	}

	public void setSheng(String sheng) {
		this.sheng = sheng;
	}
	
	
	
	
}
