package com.zhong;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import com.dao.Dao;
import com.fz.Sheng;
import com.fz.Shi;
import com.fz.xian;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

public class Ac implements Action {
//	 private com.fz.Sheng Sheng;
//	 
//	 
//	public com.fz.Sheng getSheng() {
//		return Sheng;
//	}
//
//
//	public void setSheng(com.fz.Sheng sheng) {
//		Sheng = sheng;
//	}


	
	
	Dao d=new Dao();
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	//另一种ajax返回函数的方法  但是没弄会seruts.xml 所以这个方法无用
//	public class ProvinceAction extends ActionSupport{ 
//		
//	}
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	//当打开页面 自动加载省份
	 public String ajaxProvince(){  
		 System.out.println("这是省份");
		 
		//在struts中  不能直接使用response,request  需要自己添加引用
	        HttpServletResponse response = ServletActionContext.getResponse();    
	        response.setContentType("text/html;charset=UTF-8");       
	        response.setCharacterEncoding("UTF-8");// 防止弹出的信息出现乱码      
	        //声明流
	        PrintWriter writer=null;  
	        try {  
	            writer = response.getWriter();  
	        } catch (IOException e) {  
	            // TODO Auto-generated catch block  
	            e.printStackTrace();  
	        }  
	        ArrayList list=   d.sheng();
 
//	        实验的时候用的方法
	        //JSONArray.fromObject()因为架包不一样这个方法更方便，它本身的封装的有转换方法 。
	        //现在用的如下方式  自己把list写进 JSONArray里面
//	        JSONArray jsonArray=new JSONArray();
//	        
     //JSONArray jsonArray = JSONArray.fromObject(list);
	        
	        
	        
	        
	        //声明一个 JSONArray  导入json的架包
	        JSONArray json=new JSONArray();
	        
	        //循环出来list里的封装类  并且写进JSONObject  在把JSONObject这个写进JSONArray
	        for(int i=0;i<list.size();i++){
	        	 
	 	        JSONObject jo = new JSONObject();
	        	  Sheng s= (Sheng) list.get(i);
	        	try {
					jo.put("seid", s.getSeid());
					jo.put("sheng", s.getSheng());
					json.put(jo);	
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        	
	        }  
	      //注意   json.toString()  这样才是转换成功！！
	        System.out.println(json.toString());
	        
	      
	      //写进流里面  返回给success函数 
	        writer.print(json.toString());
	        writer.flush();
	        writer.close();
	        return null;  
	    }   

	 
	 //城市的方法
	 public String ajaxCity(){
		 System.out.println("这是城市");
		 HttpServletRequest request = ServletActionContext.getRequest();    
		 String seseid=request.getParameter("seseid");
		 System.out.println("传过来的省id"+seseid);
		 
		 HttpServletResponse response = ServletActionContext.getResponse();  
	        response.setContentType("text/html;charset=UTF-8");       
	        response.setCharacterEncoding("UTF-8");// 防止弹出的信息出现乱码      
	        PrintWriter writer=null;  
	        try {  
	            writer = response.getWriter();  
	        } catch (IOException e) {  
	            // TODO Auto-generated catch block  
	            e.printStackTrace();  
	        }  
		 
		 
		 
		 
		 ArrayList list=   d.shi(seseid);
		 
		 JSONArray json=new JSONArray();
		
	        
	        for(int i=0;i<list.size();i++){
	        	 
	 	        JSONObject jo = new JSONObject();
	        	  Shi s= (Shi) list.get(i);
	        	try {
					jo.put("sid", s.getSid());
					jo.put("shi", s.getShi());
					json.put(jo);	
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        	
	        }  
	        System.out.println(json.toString());
	        
	      
	        
	        writer.print(json.toString());
	        writer.flush();
	        writer.close();
		 
		return null;  
		 
		 
	 }
	 
	 //县的方法
	 
	 public String ajaxTown(){
		 System.out.println("这是县区");
		 HttpServletRequest request = ServletActionContext.getRequest();    
		 String sid=request.getParameter("sid");
		 System.out.println("传过来的市id"+sid);
		 
		 HttpServletResponse response = ServletActionContext.getResponse();  
	        response.setContentType("text/html;charset=UTF-8");       
	        response.setCharacterEncoding("UTF-8");// 防止弹出的信息出现乱码      
	        PrintWriter writer=null;  
	        try {  
	            writer = response.getWriter();  
	        } catch (IOException e) {  
	            // TODO Auto-generated catch block  
	            e.printStackTrace();  
	        }  
		 
		 
		 
		 
		 ArrayList list=   d.xian(sid);
		 
		 JSONArray json=new JSONArray();
		
	        
	        for(int i=0;i<list.size();i++){
	        	 
	 	        JSONObject jo = new JSONObject();
	        	  xian x= (xian) list.get(i);
	        	try {
	        		jo.put("xid", x.getXid());
					jo.put("xian", x.getXian());
					json.put(jo);	
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        	
	        }  
	        System.out.println(json.toString());
	        
	      
	        
	        writer.print(json.toString());
	        writer.flush();
	        writer.close();
		 
		return null;  
		 
		 
	 }
	 
	 
	 
}


