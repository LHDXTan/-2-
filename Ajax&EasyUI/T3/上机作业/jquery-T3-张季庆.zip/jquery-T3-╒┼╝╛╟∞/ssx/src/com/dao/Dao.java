package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.fz.Sheng;
import com.fz.Shi;
import com.fz.xian;
import com.jdbc.Jdbc;

public class Dao {
	public ArrayList sheng(){
		PreparedStatement ps=null;
	Connection	conn=Jdbc.getConnection();
	
	String sql="select * from sheng";
	ArrayList list=new ArrayList();
	
	try {
		ps=conn.prepareStatement(sql);
	   ResultSet re=	ps.executeQuery();
	   
	while(re!=null&&re.next()){
		Sheng se=new Sheng();
		
		se.setSeid(re.getString("seid"));
		se.setSheng(re.getString("sheng"));
		
		list.add(se);
		
	}

	
	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return list;
		
	}
//城市的查询
	public ArrayList shi(String seseid){
		PreparedStatement ps=null;
	Connection	conn=Jdbc.getConnection();
	String sql="select * from shi where seid='"+seseid+"'";
	ArrayList list=new ArrayList();
	
	try {
		ps=conn.prepareStatement(sql);
		 ResultSet re=	ps.executeQuery();
		 while(re!=null&&re.next()){
			 Shi s=new Shi();
			  s.setSid(re.getString("sid"));
			  s.setShi(re.getString("shi"));
			  list.add(s);
		 }
		 
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
	return list;
	}
	//县的查询
		public ArrayList xian(String sid){
			PreparedStatement ps=null;
		Connection	conn=Jdbc.getConnection();
		String sql="select * from xian where sid='"+sid+"'";
		ArrayList list=new ArrayList();
		
		try {
			ps=conn.prepareStatement(sql);
			 ResultSet re=	ps.executeQuery();
			 while(re!=null&&re.next()){
				xian x=new xian();
				  x.setXid(re.getString("xid"));
				  x.setXian(re.getString("xian"));
				  
				  list.add(x);
			 }
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return list;
		}
	
	
	
	
	
	
	
}
