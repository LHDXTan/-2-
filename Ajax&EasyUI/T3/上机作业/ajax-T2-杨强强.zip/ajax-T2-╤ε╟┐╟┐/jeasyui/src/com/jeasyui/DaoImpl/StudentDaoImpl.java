package com.jeasyui.DaoImpl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.jeasyui.util.HibernateSessionFactory;


public class StudentDaoImpl {

	public int add(Object obj) {
		int flag = 0;
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		try{
		    session.save(obj);
		    tx.commit();
		    flag = 1;
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		HibernateSessionFactory.closeSession();
		return flag;
	}

	public int update(Object obj) {
		int flag = 0;
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		
		try{
		    session.update(obj);
		    tx.commit();
		    flag = 1;
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			
		}
		HibernateSessionFactory.closeSession();
		return flag;
	}

	public int delete(Object obj) {
		int flag = 0;
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		
		try{
		    session.delete(obj);
		    tx.commit();
		    flag = 1;
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			
		}
		HibernateSessionFactory.closeSession();
		return flag;
	}

	public Object getObjectById(Class clazz, Serializable id) {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		Object obj=null;
		try{
		    obj=session.get(clazz, id);
		    tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		HibernateSessionFactory.closeSession();
		return obj;
	}

	public List getObjects(String hql) {
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List result =new ArrayList();
		try{
		    result=session.createQuery(hql).list();
		    tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			
		}
		HibernateSessionFactory.closeSession();
		return result;
	}
	
}
