package com.jeasyui.Action;

import com.jeasyui.Pro.Student;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

public class StudentAction extends ActionSupport {

	private Student stu;
	
	public String addStudent(){
		System.out.println("11");
		return "add";
	}

	public Student getStu() {
		return stu;
	}

	public void setStu(Student stu) {
		this.stu = stu;
	}
	
	

}
