package com.qhit.action;

import com.opensymphony.xwork2.ActionSupport;

public class Test extends ActionSupport{
	public String test() {
		return "t";
	}
}
