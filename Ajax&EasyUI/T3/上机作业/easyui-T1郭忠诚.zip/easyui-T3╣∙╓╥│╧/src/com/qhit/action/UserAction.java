package com.qhit.action;

import java.util.List;

import com.opensymphony.xwork2.ActionSupport;
import com.qhit.bean.Ustudent;

import dao.UserDao;

public class UserAction extends ActionSupport {
      
	 UserDao ud=new UserDao();
	 private List<Ustudent> userlist;
	 private Ustudent stu;
	 private String uid;
	 private String uname;
	 private String upwd;
	 private String usex;
	 private String uage;
	 private String uadress;
	 
	 
     public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUpwd() {
		return upwd;
	}

	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}

	public String getUsex() {
		return usex;
	}

	public void setUsex(String usex) {
		this.usex = usex;
	}

	public String getUage() {
		return uage;
	}

	public void setUage(String uage) {
		this.uage = uage;
	}

	public String getUadress() {
		return uadress;
	}

	public void setUadress(String uadress) {
		this.uadress = uadress;
	}

	public String stulist(){
    	 userlist=ud.userList();
    	 return "ulist";
     }
     
     public String addtu(){
    	 System.out.println(123);
    	 stu=new Ustudent();
    	 stu.setUadress(uadress);
    	 stu.setUage(uage);
    	 stu.setUname(uname);
    	 stu.setUpwd(upwd);
    	 stu.setUsex(usex);
    	 ud.addstu(stu);
         return "tu";
    	 
     }
     
     public String delstu(){
    	 System.out.println(uid);
    	 int id = Integer.parseInt(uid);
    	 ud.delstu(id);
		return "tu";
    	 
     }
     
     public String updatestu(){
    	 System.out.println(111);
    	 stu=new Ustudent();
    	 int id=Integer.parseInt(uid);
    	 stu.setUid(id);
    	 stu.setUadress(uadress);
    	 stu.setUage(uage);
    	 stu.setUname(uname);
    	 stu.setUpwd(upwd);
    	 stu.setUsex(usex);
    	 ud.update(stu);
		return "tu";
    	 
     }
     
     public String update(){
    	 stu=new Ustudent();
    	 int id=Integer.parseInt(uid);
    	 stu.setUid(id);
    	 stu.setUadress(uadress);
    	 stu.setUage(uage);
    	 stu.setUname(uname);
    	 stu.setUpwd(upwd);
    	 stu.setUsex(usex);
    	 ud.update(stu);
		return "tu";
    	 
     }

	public List<Ustudent> getUserlist() {
		return userlist;
	}

	public void setUserlist(List<Ustudent> userlist) {
		this.userlist = userlist;
	}

	public Ustudent getStu() {
		return stu;
	}

	public void setStu(Ustudent stu) {
		this.stu = stu;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}
	
}