package com.qhit.bean;

/**
 * Ustudent entity. @author MyEclipse Persistence Tools
 */

public class Ustudent implements java.io.Serializable {

	// Fields

	private Integer uid;
	private String uname;
	private String upwd;
	private String usex;
	private String uage;
	private String uadress;

	// Constructors

	/** default constructor */
	public Ustudent() {
	}

	/** full constructor */
	public Ustudent(String uname, String upwd, String usex, String uage,
			String uadress) {
		this.uname = uname;
		this.upwd = upwd;
		this.usex = usex;
		this.uage = uage;
		this.uadress = uadress;
	}

	// Property accessors

	public Integer getUid() {
		return this.uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public String getUname() {
		return this.uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUpwd() {
		return this.upwd;
	}

	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}

	public String getUsex() {
		return this.usex;
	}

	public void setUsex(String usex) {
		this.usex = usex;
	}

	public String getUage() {
		return this.uage;
	}

	public void setUage(String uage) {
		this.uage = uage;
	}

	public String getUadress() {
		return this.uadress;
	}

	public void setUadress(String uadress) {
		this.uadress = uadress;
	}

}