package dao;

import java.util.List;



import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.qhit.bean.Ustudent;



public class UserDao {
	
	public List<Ustudent> userList(){
	    Session sessionFactory=HibernateSessionFactory.getSession();
        Transaction tx= sessionFactory.beginTransaction();
        Query q=sessionFactory.createQuery("from Ustudent");
        List<Ustudent> list=(List<Ustudent>)q.list();
        tx.commit();
       
		return list;
		}
     
	public void addstu(Ustudent ustu){
		Session  sessionFactory=HibernateSessionFactory.getSession();
		Transaction tx=sessionFactory.beginTransaction();
		System.out.println(ustu.getUadress());
		sessionFactory.save(ustu);
		tx.commit();
		}
	
	public void delstu(int uid){
		Session  sessionFactory=HibernateSessionFactory.getSession();
		Transaction tx=sessionFactory.beginTransaction();
		Ustudent stu=(Ustudent) sessionFactory.get(Ustudent.class, uid);
		sessionFactory.delete(stu);
		tx.commit();
		
	}
   
	public void update(Ustudent ustu){
		Session  sessionFactory=HibernateSessionFactory.getSession();
		Transaction tx=sessionFactory.beginTransaction();
		System.out.println(ustu.getUid());
		Ustudent stu1=(Ustudent) sessionFactory.get(Ustudent.class, ustu.getUid());
		stu1.setUname(ustu.getUname());
		stu1.setUpwd(ustu.getUpwd());
		stu1.setUsex(ustu.getUsex());
		stu1.setUadress(ustu.getUadress());
		sessionFactory.update(stu1);       
		tx.commit();
		
	}
	
	public void updaate(Ustudent ustu){
		Session session=HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		Ustudent stu1=(Ustudent) session.get(Ustudent.class, ustu.getUid());
		stu1.setUid(ustu.getUid());
		stu1.setUname(ustu.getUname());
		stu1.setUpwd(ustu.getUpwd());
		stu1.setUsex(ustu.getUsex());
		stu1.setUadress(ustu.getUadress());
		session.update(stu1);       
		tx.commit();
		
	}
}

