package com.qhit;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

public class action {
public String as() throws IOException{
	System.out.println("你好！user！");
	HttpServletRequest request=ServletActionContext.getRequest();
	HttpServletResponse response=ServletActionContext.getResponse();
    PrintWriter out=	response.getWriter();
    String username= request.getParameter("user");
     if(username.equals("001")){
    	 out.print("1");
    	 System.out.println("succes");
     }else{
    	 out.print("2");
    	System.out.println("error"); 
     }
     System.out.println(username);
	return null;
}
public String ad() throws IOException{
	System.out.println("你好！password！");
	HttpServletRequest request=ServletActionContext.getRequest();
	HttpServletResponse response=ServletActionContext.getResponse();
 PrintWriter out=response.getWriter();
    int pass=Integer.parseInt(request.getParameter("pass"));
	if(pass==123456){
		out.print("1");
		System.out.println("succ");
	}else{
		out.print("2");
		System.out.println("err");
	}
	return null;
	
}

}
