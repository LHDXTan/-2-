package UserAddDao;

public interface UserAddService {

	public boolean checkuser(String uname);

}
