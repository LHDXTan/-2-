package sevletAction;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import UserAddDao.*;

public class UserAddServlet extends HttpServlet {
	
	
	private UserAddService  userdao=new UserAddImp();

    public UserAddServlet() {
		super();
	}

	
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
	}

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		doPost(request, response);	
    }

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		response.setCharacterEncoding("utf-8");
		String reqType=  request.getParameter("reqType");
		
		if(reqType.equals("checkuser")){
			checkuser(request, response);
		}else if(reqType.equals("changPro")){
			changPro(request, response);
		}
		out.flush();
		out.close();
	}

	//省市二级联动
	private void changPro(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String pro=request.getParameter("pro");
		int a=1;
		if(pro==null){
			out.println("湖北");
			System.out.println("测试1");
		}else if(pro!=null){
			out.println("北京");
			System.out.println("测试2");

		}
		out.flush();
		out.close();
	}


	
	//校验用户名是否重复
	private void checkuser(HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		    PrintWriter out =response.getWriter();
		    response.setCharacterEncoding("utf-8");
			String uname=request.getParameter("uname");
			System.out.println("ceshi:"+uname);
			//boolean a=userdao.checkuser(uname);
			
	        int i=1;
			if(i==1){
				out.println("此用户名已存在");
			}else{
				
				out.println("可以注册");
			}
			
			out.flush();
			out.close();
	}


		public void init() throws 
		
		ServletException {
	}

}
