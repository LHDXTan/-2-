package UserAddDao;

public class UserAddImp implements UserAddService {

    //校验用户名是否重复
	public boolean checkuser(String uname) {

		
		
		return false;
	}
	
	

}
