package dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;

import beans.Students;
import hb.HibernateSessionFactory;

public class StudentsDao {
	public static List<Students> getStudents () {
		Session session = HibernateSessionFactory.getSession();
		DetachedCriteria criteria = DetachedCriteria.forClass(Students.class);
		List<Students> list = (List<Students>) criteria.getExecutableCriteria(session).list();
		session.close();
		return list;
	}
	
	public static boolean saveStudents (Students students) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		int status = (int) session.save(students);
		transaction.commit();
		session.close();
		if (status != 0) {
			return true;
		}
		return false;
	}
	
	public static boolean updateStudents (Students students) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		try {
			session.update(students);
			transaction.commit();
		} catch (HibernateException e) {
			try {
				transaction.rollback();
			} catch (HibernateException e2) {
				session.close();
				return false;
			}
			session.close();
			return false;
		}
		return true;
	}
	
	public static boolean deleteStudents (Students students) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		try {
			session.delete(students);
			transaction.commit();
		} catch (HibernateException e) {
			try {
				transaction.rollback();
			} catch (HibernateException e2) {
				session.close();
				return false;
			}
			session.close();
			return false;
		}
		return true;
	}
}
