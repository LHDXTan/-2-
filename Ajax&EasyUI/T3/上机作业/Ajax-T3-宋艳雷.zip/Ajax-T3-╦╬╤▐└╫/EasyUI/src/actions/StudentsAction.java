package actions;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import beans.Students;
import dao.StudentsDao;

public class StudentsAction extends ActionSupport {
	private String result;
	private Students students;
	private List<Students> list;
	public String all() {
		list = StudentsDao.getStudents();
		return "json";
	}
	public String add() {
		PrintWriter out = null;
		try {
			out = ServletActionContext.getResponse().getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (StudentsDao.saveStudents(students)) {
			out.print("success");
			return null;
		}else {
			out.print("fail");
			return null;
		}
	}
	
	public String edit () {
		PrintWriter out = null;
		try {
			out = ServletActionContext.getResponse().getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (StudentsDao.updateStudents(students)) {
			out.print("success");
			return null;
		}else {
			out.print("fail");
			return null;
		}
	}
	public String del () {
		PrintWriter out = null;
		try {
			out = ServletActionContext.getResponse().getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (StudentsDao.deleteStudents(students)) {
			out.print("success");
			return null;
		}else {
			out.print("fail");
			return null;
		}
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public List<Students> getList() {
		return list;
	}
	public void setList(List<Students> list) {
		this.list = list;
	}
	public Students getStudents() {
		return students;
	}
	public void setStudents(Students students) {
		this.students = students;
	}
}
