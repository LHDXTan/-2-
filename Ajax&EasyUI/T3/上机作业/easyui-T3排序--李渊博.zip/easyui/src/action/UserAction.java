package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import dao.UserDaoImp;
import pojo.Users;

public class UserAction {
	
	UserDaoImp dao = new  UserDaoImp();
	private List<Users> userlist =new ArrayList<Users>();
	private Users users;
	
	public List<Users> getUserlist() {
		return userlist;
	}

	public void setUserlist(List<Users> userlist) {
		this.userlist = userlist;
	}
	

	public Users getUsers() {
		return users;
	}

	public void setUsers(Users users) {
		this.users = users;
	}


	public String list(){
		userlist = dao.listuser();
		return "list";
		
	}
   public String useradd(){
	   PrintWriter out = null;
	   try {
		out = ServletActionContext.getResponse().getWriter();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	     if(dao.useradd(users)){
	    	 out.print(1);
	    	 return null;
	      }else{
	    	  out.print(2);
		      return null;
	      }
		
	}

   public String toasui(){
	   return "asui";
   }
   public String delete(){
	   PrintWriter out = null;
	   try {
	      out = ServletActionContext.getResponse().getWriter();
	   } catch (IOException e) {
		  // TODO Auto-generated catch block
		  e.printStackTrace();
	   }
	     if( dao.delete(users.getId())){
	    	 out.print(1);
	    	 return null;
	      }else{
	    	  out.print(2);
		      return null;
	      }
   }
   public String updateadd(){
	   PrintWriter out = null;
	   try {
	      out = ServletActionContext.getResponse().getWriter();
	   } catch (IOException e) {
		  // TODO Auto-generated catch block
		  e.printStackTrace();
	   } 
	   System.out.println(users.getId());
	     if(dao.updateadd(users)){
	    	 out.print(1);
	    	 return null;
	      }else{
	    	  out.print(2);
		      return null;
	      }
	
   }
	
}
