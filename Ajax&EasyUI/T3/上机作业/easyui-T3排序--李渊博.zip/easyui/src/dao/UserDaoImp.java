package dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import sf.HibernateSessionFactory;

import pojo.Users;


public class UserDaoImp {

	public List<Users> listuser() {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		String hql = "from Users";
		Query query = session.createQuery(hql);
		List list = query.list();
		
		tx.commit();
		HibernateSessionFactory.closeSession();
		return list;
	}

	public boolean useradd(Users users) {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		try {
			session.save(users);
			tx.commit();
			return true;
		} catch (Exception e) {
		      e.printStackTrace();
		      return false;
		}
	}

	public boolean delete(int id) {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
        Users users=(Users) session.get(Users.class, id);	
		try {
			session.delete(users);
			tx.commit();
			return true;
		} catch (Exception e) {
		      e.printStackTrace();
		    return false;
		}
	}

	public boolean updateadd(Users users) {
		// TODO Auto-generated method stub
		
		Session session=HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		System.out.println(users.getId());
		Users jj = (Users) session.get(Users.class, users.getId());
		jj.setUsername(users.getUsername());
		jj.setSex(users.getSex());
		jj.setAge(users.getAge());
		jj.setAddress(users.getAddress());
		try {
			session.update(jj);
			tx.commit();
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
	
	}
	
	
}