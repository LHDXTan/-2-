package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import bean.Student;
import dao.IStudentDao;
import dao.ImpStudentDao;

public class StudentAction {
	private List<Student> list;
	private Student st;
    public Student getSt() {
		return st;
	}
	public void setSt(Student st) {
		this.st = st;
	}
	private IStudentDao students = new ImpStudentDao(); 
    
    
	public List<Student> getList() {
		return list;
	}
	public void setList(List<Student> list) {
		this.list = list;
	}

    public String getStudent(){
		list=students.getStudent();
    	return "index";	
    }
    public String insertStudent(){
    	PrintWriter out = null;
		try {
			out = ServletActionContext.getResponse().getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}
    	if (students.insertStudent(st)) {
    		out.print("ok");
    		return null;
    	}else {
    		out.print("fail");
    		return null;
    	}
    }
    public String deleteStudent(){
    	PrintWriter out = null;
		try {
			out = ServletActionContext.getResponse().getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}
    	if (students.deleteStudent(st)) {
    		out.print("ok");
    		return null;
    	}else {
    		out.print("fail");
    		return null;
    	}
    }
    public String editStudent(){
    	PrintWriter out = null;
		try {
			out = ServletActionContext.getResponse().getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (students.editStudent(st)) {
    		out.print("ok");
    		return null;
    	}else {
    		out.print("fail");
    		return null;
    	}
    	
    }
}
