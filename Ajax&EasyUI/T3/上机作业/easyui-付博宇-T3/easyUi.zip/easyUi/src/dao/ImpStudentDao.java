package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Student;
import hibernatefactory.HibernateSessionFactory;

public class ImpStudentDao implements IStudentDao {
    List<Student> list =new ArrayList<Student>();
    private Student str=new Student();
	@Override
	public List<Student> getStudent() {
		Session se =HibernateSessionFactory.getSession();
		Transaction tr=se.beginTransaction();
		Query qe=se.createQuery("from Student");
		list=qe.list();
		tr.commit();
		se.close();
 		return list;
	}
	@Override
	public boolean insertStudent(Student st) {
		Session se =HibernateSessionFactory.getSession();
		Transaction tr=se.beginTransaction();
		int flag = (int)se.save(st);
		tr.commit();
		se.close();
		if (flag != 0) {
			return true;
		}else {
			return false;
		}
		
	}
	@Override
	public boolean  deleteStudent(Student student){
		Session se =HibernateSessionFactory.getSession();
		Transaction tr=se.beginTransaction();
		try {
			se.delete(student);
			tr.commit();
		} catch (Exception e) {
			tr.rollback();
			e.printStackTrace();
			return false;
		}
		se.close();
		return true;
	}
	@Override
	public boolean editStudent(Student st) {
		Session se =HibernateSessionFactory.getSession();
		Transaction tr=se.beginTransaction();
		try {
			se.update(st);
			tr.commit();
		} catch (Exception e) {
			tr.rollback();
			e.printStackTrace();
			return false;
		}
		se.close();
		return true;
	}

}
