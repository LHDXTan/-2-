package com.easyui.basedao;

import java.util.List;


public interface BaseDao {
	
	public void add(Object obj);
	public void update(Object obj);
	public void delete(Object obj);
	public Object getObjectById(Class clazz, Integer id);
	public List getObjects(String hql);
	
	

}
