package com.easyui.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.Action;


public class EasyAction implements Action {
	
	EasyAction action=new EasyAction();
	
	private Integer[] eid;

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public boolean list(String name){
		  
		return false;  
	}
	
	

	public String add(){
		HttpServletRequest request=ServletActionContext.getRequest();
		HttpServletResponse response=ServletActionContext.getResponse();
		response.setContentType("text/html;charset=UTF-8");		
		try {
			PrintWriter out = response.getWriter();
			String name=request.getParameter("uname");
			boolean b=action.list(name);
			if(b){
				out.print("");
			}else{
				out.print("可以添加!");
			}
			out.flush();
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	public Integer[] getEid() {
		return eid;
	}

	public void setEid(Integer[] eid) {
		this.eid = eid;
	}
	
	


}
