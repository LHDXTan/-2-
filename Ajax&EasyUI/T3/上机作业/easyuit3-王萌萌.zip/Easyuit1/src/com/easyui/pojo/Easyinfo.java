package com.easyui.pojo;

/**
 * Easyinfo entity. @author MyEclipse Persistence Tools
 */

public class Easyinfo implements java.io.Serializable {

	// Fields

	private Integer eid;
	private String ename;
	private String esex;
	private String ephone;

	// Constructors

	/** default constructor */
	public Easyinfo() {
	}

	/** full constructor */
	public Easyinfo(Integer eid, String ename, String esex, String ephone) {
		this.eid = eid;
		this.ename = ename;
		this.esex = esex;
		this.ephone = ephone;
	}

	// Property accessors

	public Integer getEid() {
		return this.eid;
	}

	public void setEid(Integer eid) {
		this.eid = eid;
	}

	public String getEname() {
		return this.ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEsex() {
		return this.esex;
	}

	public void setEsex(String esex) {
		this.esex = esex;
	}

	public String getEphone() {
		return this.ephone;
	}

	public void setEphone(String ephone) {
		this.ephone = ephone;
	}

}