package action;

import java.util.List;

import bean.Student;
import dao.IStudentDao;
import dao.ImpStudentDao;

public class StudentAction {
	private List<Student> list;
	private Student st;
    public Student getSt() {
		return st;
	}
	public void setSt(Student st) {
		this.st = st;
	}
	private IStudentDao students = new ImpStudentDao(); 
    
    
	public List<Student> getList() {
		return list;
	}
	public void setList(List<Student> list) {
		this.list = list;
	}

    public String getStudent(){
		list=students.getStudent();
    	return "index";	
    }
    public String insertStudent(){
    	students.insertStudent(st);
		return "toindex";
    	
    }
    public String deleteStudent(){
    	
    	students.deleteStudent(st.getSid());
		return "toindex";
    	
    }
}
