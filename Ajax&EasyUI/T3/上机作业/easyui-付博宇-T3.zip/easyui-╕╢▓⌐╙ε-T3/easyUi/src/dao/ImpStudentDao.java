package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Student;
import hibernatefactory.HibernateSessionFactory;

public class ImpStudentDao implements IStudentDao {
    List<Student> list =new ArrayList<Student>();
    private Student str=new Student();
	@Override
	public List<Student> getStudent() {
		Session se =HibernateSessionFactory.getSession();
		Transaction tr=se.beginTransaction();
		Query qe=se.createQuery("from Student");
		list=qe.list();
		tr.commit();
 		return list;
	}
	@Override
	public void insertStudent(Student st) {
		Session se =HibernateSessionFactory.getSession();
		Transaction tr=se.beginTransaction();
		se.save(st);
		tr.commit();
	}
	@Override
	public void  deleteStudent(int sid){
		Session se =HibernateSessionFactory.getSession();
		Transaction tr=se.beginTransaction();
		str = (Student)se.get(Student.class,sid);
		se.delete(str);
		tr.commit();
		
	
	}

}
