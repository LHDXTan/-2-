package dao;

import java.util.List;

import bean.Student;

public interface IStudentDao {
   public List<Student> getStudent();
   
   public void insertStudent(Student st);
   
   public void deleteStudent(int sid);
}
