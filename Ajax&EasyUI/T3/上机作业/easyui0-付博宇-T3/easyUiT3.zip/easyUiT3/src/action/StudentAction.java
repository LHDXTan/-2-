package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import bean.Student;
import dao.IStudentDao;
import dao.ImpStudentDao;

public class StudentAction {
	private List<Student> list;
	private Student st;
    private int rows;
    private int page;
    private String sort;
    private String order;
    
    public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	private HashMap<String, Object> lists;
	private IStudentDao students = new ImpStudentDao(); 
    
	public int getRows() {
		return rows;
	}
	public void setRows(int rows) {
		this.rows = rows;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public Student getSt() {
		return st;
	}
	public void setSt(Student st) {
		this.st = st;
	}

	public List<Student> getList() {
		return list;
	}
	public void setList(List<Student> list) {
		this.list = list;
	}

    public String getStudent(){
    	lists=new HashMap<String, Object>();
		list=students.getStudent(rows,page,order,sort);
		lists.put("rows", list);
		lists.put("total", students.getStudentCount());
    	return "index";	
    }
    
    public String insertStudent(){
    	PrintWriter out = null;
		try {
			out = ServletActionContext.getResponse().getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}
    	if (students.insertStudent(st)) {
    		out.print("ok");
    		return null;
    	}else {
    		out.print("fail");
    		return null;
    	}
    }
    public HashMap<String, Object> getLists() {
		return lists;
	}
	public void setLists(HashMap<String, Object> lists) {
		this.lists = lists;
	}
	public String deleteStudent(){
    	PrintWriter out = null;
		try {
			out = ServletActionContext.getResponse().getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}
    	if (students.deleteStudent(st)) {
    		out.print("ok");
    		return null;
    	}else {
    		out.print("fail");
    		return null;
    	}
    }
    public String editStudent(){
    	PrintWriter out = null;
		try {
			out = ServletActionContext.getResponse().getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (students.editStudent(st)) {
    		out.print("ok");
    		return null;
    	}else {
    		out.print("fail");
    		return null;
    	}
    	
    }
}
