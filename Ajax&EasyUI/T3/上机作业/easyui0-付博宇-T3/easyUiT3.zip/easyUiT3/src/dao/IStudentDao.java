package dao;

import java.util.List;

import bean.Student;

public interface IStudentDao {
   
   public List<Student> getStudent(int rows,int page,String order,String sort);
   
   public int getStudentCount();
   
   public boolean insertStudent(Student st);
   
   public boolean deleteStudent(Student st);

   public boolean editStudent(Student st);
}
