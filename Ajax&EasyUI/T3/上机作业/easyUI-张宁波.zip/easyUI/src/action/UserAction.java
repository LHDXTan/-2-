package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.swing.text.StyledEditorKit.BoldAction;

import org.apache.struts2.ServletActionContext;

import bean.UserInfo;

import com.google.gson.Gson;
import com.opensymphony.xwork2.ActionSupport;

import dao.IUserDao;
import dao.UserDaoImpl;

public class UserAction extends ActionSupport {
	
	private List<UserInfo> userlist;
	IUserDao idao=new UserDaoImpl();
	private UserInfo userInfo;
	
	private String uname;
	private String email;
	private String address;
	private String phone;
	private int uid;
	
	

	

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public UserInfo getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	public List<UserInfo> getUserlist() {
		return userlist;
	}

	public void setUserlist(List<UserInfo> userlist) {
		this.userlist = userlist;
	}

	
	public String getUserList(){
		userlist=idao.getUser();
		Gson gs=new Gson();
		String str=gs.toJson(userlist);
		HttpServletResponse response=ServletActionContext.getResponse();
		response.setCharacterEncoding("UTF-8");
		try {
			PrintWriter out=response.getWriter();
			out.write(str);
			out.flush();
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		

		return "userlist";
	}
	
	public String addUser(){
		UserInfo userinfo=new UserInfo();
		userinfo.setUname(uname);
		userinfo.setEmail(email);
		userinfo.setAddress(address);
		userinfo.setPhone(phone);
		userinfo.setUid(uid);
		if(uid==0){
			idao.insertUser(userinfo);
		}else{
			idao.updateU(userinfo);

		}
		
		try {
			PrintWriter out = ServletActionContext.getResponse().getWriter();
			int a=1;
			out.write(a);
			out.flush();
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 	return "addUser";

	}
	
	//修改信息
	private String selectUserById(){
		userInfo=idao.getUserById(uid);
		try {
			PrintWriter out=ServletActionContext.getResponse().getWriter();
			out.println(userInfo);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "updateUser";
	}
	
	public String updateUser(){
		userInfo.setUname(uname);
		userInfo.setEmail(email);
		userInfo.setAddress(address);
		userInfo.setPhone(phone);
		userInfo.setUid(uid);
		idao.updateU(userInfo);
		return "updateUser";
		
	} 

	//删除信息
	public String deleteUser(){
		idao.deleteU(userInfo.getUid());
		HttpServletResponse response=ServletActionContext.getResponse();
		try {
			PrintWriter out=response.getWriter();
			int a=1;
			out.write(a);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "deleteUser";
		
	}
}
