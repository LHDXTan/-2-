package com.text;

import java.util.List;

import com.opensymphony.xwork2.Action;

public class textaction implements Action {
  private List<stu> list;
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		
		 stu s = new stu();
		   s.setName("aa");
		   list.add(s);
		
		
		return null;
	}

	public List<stu> getList() {
		return list;
	}

	public void setList(List<stu> list) {
		this.list = list;
	}
  

	
	
	
}
