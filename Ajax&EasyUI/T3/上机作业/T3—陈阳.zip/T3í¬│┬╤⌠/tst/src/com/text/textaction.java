package com.text;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.beans.Stu;
import com.dao.BaseDaoImpl;
import com.google.gson.Gson;
import com.opensymphony.xwork2.Action;




public class textaction implements Action {
   
    	private int id;
		private String name;
		private String age;
		private String sex;
		private String phone;
		private String birthday; 
		private String page;
		private String rows;
	 BaseDaoImpl dao = new BaseDaoImpl();
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		
		   
		return null;
	}
//查询所有信息
	public String selStu () throws IOException {
		
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
	     ArrayList list = new ArrayList();
	     list=(ArrayList) dao.getObjects("from Stu");
	     Gson gson= new Gson();
	    String result =  gson.toJson(list);
	     out.print(result);
	     out.flush();
	     out.close();
		System.out.println("查询所有人");
		System.out.println(page);
		System.out.println(rows);
		return "";
	}
	
	
//添加信息
	public String addStu (){
		
		Stu s = new Stu();
		s.setName(name);
		s.setAge(age);
		s.setSex(sex);
		s.setBirthday(birthday);
		s.setPhone(phone);
		dao.add(s);
		System.out.println("添加信息");

		return "tolist";
	}
	//修改信息
	public String updateStu(){
		Stu ss =(Stu) dao.getObjectById(Stu.class, id);
	 
		ss.setName(name);
		ss.setAge(age);
		ss.setSex(sex);
		ss.setBirthday(birthday);
		ss.setPhone(phone);
		dao.update(ss);
		return "tolist";
	}
	//删除信息
	public String delStu(){
	Stu s=	(Stu) dao.getObjectById(Stu.class, id);
		dao.delete(s);
		
		return "tolist";
	}
	
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getPage() {
		return page;
	}
	public void setPage(String page) {
		this.page = page;
	}
	public String getRows() {
		return rows;
	}
	public void setRows(String rows) {
		this.rows = rows;
	}

	
  

	
	
	
}
