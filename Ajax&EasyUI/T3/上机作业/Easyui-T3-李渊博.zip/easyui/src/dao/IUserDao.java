package dao;



import java.util.List;

import pojo.Users;


public interface IUserDao {
       
	public List<Users> listuser();
	public void useradd(Users users);
	
	
}
