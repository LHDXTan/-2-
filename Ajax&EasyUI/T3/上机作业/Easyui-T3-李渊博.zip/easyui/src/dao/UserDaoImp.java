package dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import sf.HibernateSessionFactory;

import pojo.Users;


public class UserDaoImp implements IUserDao {

	@Override
	public List<Users> listuser() {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		String hql = "from Users";
		Query query = session.createQuery(hql);
		List list = query.list();
		
		tx.commit();
		HibernateSessionFactory.closeSession();
		return list;
	}

	@Override
	public void useradd(Users users) {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		
		session.save(users);
		tx.commit();
		HibernateSessionFactory.closeSession();

	}
	
	
}