package action;

import java.util.ArrayList;
import java.util.List;

import pojo.Users;
import service.IUserService;
import service.UserServiceImpl;

public class UserAction {
	
	IUserService userservice = new UserServiceImpl();
	private List<Users> userlist =new ArrayList<Users>();
	private Users users;
	private String address;
	
	public List<Users> getUserlist() {
		return userlist;
	}

	public void setUserlist(List<Users> userlist) {
		this.userlist = userlist;
	}
	

	public Users getUsers() {
		return users;
	}

	public void setUsers(Users users) {
		this.users = users;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String list(){
		userlist = userservice.listuser();
		for(int i=0;i<userlist.size();i++){
		}
		return "list";
		
	}
   public String useradd(){
		
	   userservice.useradd(users);
		userlist = userservice.listuser();
		return "list";
	}

	
}
