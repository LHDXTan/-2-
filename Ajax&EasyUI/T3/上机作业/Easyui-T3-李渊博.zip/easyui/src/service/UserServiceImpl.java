package service;

import java.util.List;

import dao.IUserDao;
import dao.UserDaoImp;
import pojo.Users;

public class UserServiceImpl implements IUserService {

	IUserDao userdao= new UserDaoImp();
	@Override
	public List<Users> listuser() {
		// TODO Auto-generated method stub
		return userdao.listuser();
	}
	@Override
	public void useradd(Users users) {
		// TODO Auto-generated method stub
		 userdao.useradd(users);
	}

}
