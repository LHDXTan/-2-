package service;

import java.util.List;

import pojo.Users;

public interface IUserService {
	
	

	public List<Users> listuser();
	public void useradd(Users users);
	
}
