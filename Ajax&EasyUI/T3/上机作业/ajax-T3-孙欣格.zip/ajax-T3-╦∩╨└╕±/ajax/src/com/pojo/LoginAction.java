package com.pojo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.Action;
import bean.User;
import dao.LoginDaoimpl;



public class LoginAction implements Action {
	
      private String username;
      private User user;
	

		@Override
		public String execute() throws Exception {
		
			
            return null;
    		
      
		
	}
		
		public String selname(){
			
			System.out.println(user.getUsername());
            
			LoginDaoimpl dd =new LoginDaoimpl();
			
    		HttpServletRequest request =ServletActionContext.getRequest();
    		HttpServletResponse response =ServletActionContext.getResponse();
    		response.setContentType("text/html; charset=utf-8 ");
    		
    		PrintWriter out;
			try {
				out = response.getWriter();
				
	    		
	    		username=user.getUsername();
	    		System.out.println(username);
	    		
	    		boolean b=dd.seluser(username);
	    		if(b){
	    			
	    			out.println("可以注册使用");
	    		}else{
	    			out.println("已经存在！");
	    			
	    		}

	    		out.flush();
	    		out.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		
    	
			return null;
		}
		
		
		public String liandong(){
			
			System.out.println("进入联动");
			
			HttpServletRequest request =ServletActionContext.getRequest();
    		HttpServletResponse response =ServletActionContext.getResponse();
    		response.setContentType("text/html; charset=utf-8 ");
			try {
				PrintWriter out = response.getWriter();
				//获取当前切换的省份
				String proNo = request.getParameter("proNo");
				//---此处将后台取值的方法的方法补充完整
				LoginDaoimpl dd =new LoginDaoimpl();
				List list = dd.getAllCity(proNo);
				//-------------------------------
				
				//----此处构建页面显示选择城市的下拉列表数据
				/************补充代码***********/
				StringBuffer sb = new StringBuffer();
				sb.append(" \n");
				sb.append("[ \n");
				sb.append(" {\"pid\":\"1\",\"pcity\":[\"东城区\",\"西城区\",\"朝阳区\",\"海淀区\",\"昌平区\"]} \n");
				sb.append(",{\"pid\":\"2\",\"pcity\":[\"襄阳市\",\"十堰市\",\"枣阳市\",\"武汉市\"]} \n");
				sb.append(",{\"pid\":\"3\",\"pcity\":[\"周口市\",\"漯河市\",\"郑州市\",\"信阳市\"]} \n");
				sb.append("] \n");
				//----------选择城市的下拉列表数据构建完毕
				out.println(sb.toString());
				out.flush();
				out.close();
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			return null;
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public User getUser() {
			return user;
		}

		public void setUser(User user) {
			this.user = user;
		}
		
		
	
	    


}
