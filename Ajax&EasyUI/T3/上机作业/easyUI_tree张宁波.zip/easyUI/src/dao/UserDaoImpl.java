package dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import sessionFactory.HibernateSessionFactory;
import bean.UserInfo;

public class UserDaoImpl implements IUserDao {

	@Override
	public List<UserInfo> getUser(String sort, String order) {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Transaction ts=session.beginTransaction();
		String hql="from UserInfo";
		if(sort!=null&&sort!=""){
			hql+=" order by "+sort+" "+order;
		}
		System.out.println(hql);
		Query q=session.createQuery(hql);
		List<UserInfo> list=q.list();
		ts.commit();
		HibernateSessionFactory.closeSession();
		return list;
	}

	@Override
	public void insertUser(UserInfo userinfo) {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Transaction ts=session.beginTransaction();
			session.save(userinfo);
		ts.commit();
		HibernateSessionFactory.closeSession();
		
	}

	@Override
	public UserInfo getUserById(int uid) {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Transaction ts=session.beginTransaction();
		UserInfo userinInfo=(UserInfo) session.get(UserInfo.class,uid);
		return userinInfo;
	}

	@Override
	public void deleteU(int uid) {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Transaction ts=session.beginTransaction();
		UserInfo us=(UserInfo) session.get(UserInfo.class, uid);
		session.delete(us);
		ts.commit();
		HibernateSessionFactory.closeSession();
				
		
	}

	@Override
	public void updateU(UserInfo userinfo) {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Transaction ts=session.beginTransaction();
		UserInfo us=(UserInfo) session.get(UserInfo.class,userinfo.getUid());
		us.setUname(userinfo.getUname());
		us.setEmail(userinfo.getEmail());
		us.setAddress(userinfo.getAddress());
		us.setPhone(userinfo.getPhone());
		us.setUid(userinfo.getUid());
		session.update(us);
		ts.commit();
		HibernateSessionFactory.closeSession();
	}

}
