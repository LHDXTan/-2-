package dao;

import java.util.List;

import bean.UserInfo;

public interface IUserDao {

	public List<UserInfo> getUser(String sort, String order);

	public void insertUser(UserInfo userinfo);

	public UserInfo getUserById(int uid);

	public void deleteU(int uid);

	public void updateU(UserInfo userinfo);

}
