package com.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.Provider.Service;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.daoimpl.BaseDaoimpl;
import com.google.gson.Gson;
import com.opensymphony.xwork2.Action;


public class action implements Action {
	BaseDaoimpl dao=new BaseDaoimpl();
	private String name;
	private String password;
	private String sex;
	private int age;
	private String dh;
	private String	dz;
	private int id;
	
	


	//添加
	public String add(){
		//测试
	System.out.println("进入添加页面成功");
Zc z=new Zc();
z.setName(name);
z.setPassword(password);
z.setSex(sex);
z.setAge(age);
z.setDh(dh);
z.setDz(dz);
//调用daoimpl里面的添加方法
		dao.add(z);	
		return "to_list";
	}
	
	public String list() throws IOException{
		
		//从后台给前台请求
		HttpServletResponse respon=ServletActionContext.getResponse();
		respon.setCharacterEncoding("UTF-8");
		//再次
		PrintWriter out =respon.getWriter();
		ArrayList list =new ArrayList();
		//查询表，把查询结果存入list里面
		list =(ArrayList) dao.getObjects("from Zc");
		Gson gs=new Gson();
		String result =gs.toJson(list);
		System.out.println(result);
		//关闭流
		out.print(result);
		out.flush();
		out.close();
		return null;
	}
	
	//修改
	public String update()throws IOException{
		//进入修改方法
		System.out.println("进入修改方法");
		//调用daoimpl里面的修改方法
		Zc z=(Zc)dao.getObjectById(Zc.class, id);
		z.setName(name);
		z.setPassword(password);
		z.setSex(sex);
		z.setAge(age);
		z.setDh(dh);
		z.setDz(dz);
		//调用daoimpl里面的添加方法
		dao.update(z);
		
		return "to_list";
	}
	
		public String delect(){
			//进入删除方法
			System.out.println("进入删除方法");
			Zc z=(Zc)dao.getObjectById(Zc.class, id);
			dao.delete(z);
			
			return "to_list";
		}
	
	
	
	
	
	
	
	
	
	
	public BaseDaoimpl getDao() {
		return dao;
	}

	public void setDao(BaseDaoimpl dao) {
		this.dao = dao;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getDh() {
		return dh;
	}

	public void setDh(String dh) {
		this.dh = dh;
	}
	public String getDz() {
		return dz;
	}
	public void setDz(String dz) {
		this.dz = dz;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	









	
	
}
