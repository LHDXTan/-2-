package com.action;

/**
 * Zc entity. @author MyEclipse Persistence Tools
 */

public class Zc implements java.io.Serializable {

	// Fields

	private Integer id;
	private String name;
	private String password;
	private String sex;
	private Integer age;
	private String dh;
	private String dz;

	// Constructors

	/** default constructor */
	public Zc() {
	}

	/** minimal constructor */
	public Zc(Integer id) {
		this.id = id;
	}

	/** full constructor */
	public Zc(Integer id, String name, String password, String sex,
			Integer age, String dh, String dz) {
		this.id = id;
		this.name = name;
		this.password = password;
		this.sex = sex;
		this.age = age;
		this.dh = dh;
		this.dz = dz;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Integer getAge() {
		return this.age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getDh() {
		return this.dh;
	}

	public void setDh(String dh) {
		this.dh = dh;
	}

	public String getDz() {
		return this.dz;
	}

	public void setDz(String dz) {
		this.dz = dz;
	}

}