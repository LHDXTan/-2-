package com.daoimpl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.action.HibernateSessionFactory;
import com.dao.BaseDao;




public class BaseDaoimpl implements BaseDao {

	//添加
	public int add(Object obj) {
		// TODO Auto-generated method stub
		int flag=0;
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		
		try{
		    session.save(obj);
		    tx.commit();
		    flag = 1;
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			
		}
		
		HibernateSessionFactory.closeSession();
		return flag;
		
	}

	@Override
	public int update(Object obj) {
		// TODO Auto-generated method stub
		
		int flag=0;
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		
		try{
		    session.update(obj);
		    tx.commit();
		    flag = 1;
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			
		}
		HibernateSessionFactory.closeSession();
		return flag;
	}

	@Override
	public int delete(Object obj) {
		// TODO Auto-generated method stub
		
		int flag=0;
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		
		try{
		    session.delete(obj);
		    tx.commit();
		    flag=1;
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			
		}
		HibernateSessionFactory.closeSession();
		return flag;
	}

	@Override
	public Object getObjectById(Class clazz, Serializable id) {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		Object obj=null;
		try{
		    obj=session.get(clazz, id);
		    tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			
		}
		HibernateSessionFactory.closeSession();
		return obj;
	}

	@Override
	public List getObjects(String hql) {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List result =new ArrayList();
		try{
		    result=session.createQuery(hql).list();
		    tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			
		}
		HibernateSessionFactory.closeSession();
		return result;
	}
	
	
	
}


