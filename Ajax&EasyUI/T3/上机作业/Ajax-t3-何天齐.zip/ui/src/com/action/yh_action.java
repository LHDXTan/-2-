package com.action;

import com.opensymphony.xwork2.Action;

public class yh_action implements Action {

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
