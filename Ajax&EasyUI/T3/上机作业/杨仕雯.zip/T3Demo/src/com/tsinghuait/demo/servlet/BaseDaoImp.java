package com.tsinghuait.demo.servlet;

import java.util.List;

public class BaseDaoImp implements IBaseDao {

	public boolean checkuser(String uname) {
		// TODO Auto-generated method stub
		return false;
	}

	public List getAllCity(String proNo) {
		// TODO Auto-generated method stub
		return null;
	}

}
