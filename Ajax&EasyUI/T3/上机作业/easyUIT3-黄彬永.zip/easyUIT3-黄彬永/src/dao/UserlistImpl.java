package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import SessionFactory.HibernateSessionFactory;
import bean.Userinfo;

public class UserlistImpl implements IUserlistDao {

	@Override
	public List<Userinfo> listUser() {
		Session session = HibernateSessionFactory.getSession();
		Transaction ts = session.beginTransaction();
		Query query = session.createQuery("from Userinfo");
		List list = query.list();
		
		ts.commit();
		HibernateSessionFactory.closeSession();
		return list;
	}

	@Override
	public void useradd(Userinfo userinfo) {
		Session session=HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		
		session.save(userinfo);
		tx.commit();
		HibernateSessionFactory.closeSession();
	}

	@Override
	public Userinfo selectbyId(int id) {
		Session session=HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		
		Userinfo userinfo=(Userinfo)session.get(Userinfo.class, id);
		tx.commit();
		HibernateSessionFactory.closeSession();
		return userinfo;
	}

	@Override
	public void userupdate(Userinfo userinfo) {
		Session session=HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		session.update(userinfo);
		
		tx.commit();
		HibernateSessionFactory.closeSession();
		
	}

	@Override
	public void userdel(int id) {
		Session session=HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		
		Userinfo userinfo=(Userinfo)session.get(Userinfo.class, id);
		session.delete(userinfo);
		tx.commit();
		HibernateSessionFactory.closeSession();
	}

}
