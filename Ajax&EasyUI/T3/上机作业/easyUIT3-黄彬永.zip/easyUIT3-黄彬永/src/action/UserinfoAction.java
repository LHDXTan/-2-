package action;

import java.util.ArrayList;
import java.util.List;

import bean.Userinfo;

import com.opensymphony.xwork2.ActionSupport;

import dao.IUserlistDao;
import dao.UserlistImpl;

public class UserinfoAction extends ActionSupport{

	private List<Userinfo> userlist = new ArrayList<Userinfo>();
	private Userinfo userinfo = new Userinfo();
	IUserlistDao userlistdao = new UserlistImpl();
	private String name;
	private int age;
	private String sex;
	private String birthday;
	
	public List<Userinfo> getUserlist() {
		return userlist;
	}
	public void setUserlist(List<Userinfo> userlist) {
		this.userlist = userlist;
	}
	public Userinfo getUserinfo() {
		return userinfo;
	}
	public void setUserinfo(Userinfo userinfo) {
		this.userinfo = userinfo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String list(){
		userlist = userlistdao.listUser();
		System.out.println(userlist.size());
		return "list";
	}
	
	public String useradd(){
		
		userinfo.setName(name);
		userinfo.setAge(age);
		userinfo.setSex(sex);
		userinfo.setBirthday(birthday);
		userlistdao.useradd(userinfo);
		userlist = userlistdao.listUser();
		return "list";
	}
	
	public String selectById(){
		userlistdao.selectbyId(userinfo.getId());
		return "update";
	}
	
	public String userupdate(){
		userinfo.setName(name);
		userinfo.setAge(age);
		userinfo.setSex(sex);
		userinfo.setBirthday(birthday);
		userlistdao.userupdate(userinfo);
		userlist = userlistdao.listUser();
		return "list";
	}
	
	public String deptdel(){
		userlistdao.userdel(userinfo.getId());
		userlist = userlistdao.listUser();
		return "list";
	}
}
