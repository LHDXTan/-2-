package dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import sessionc.HibernateSessionFactory;
import util.JDBCConnection;
import bean.Paper;

public class ImpStudentDao implements InStudentService {

	//添加信息
	public void infoadd(Paper pp) {
		Session session=HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
							
	    session.save(pp);
						
		tx.commit();
		HibernateSessionFactory.closeSession();
		
		
	}

	//列表显示
	public List listPaper() {
		Session session=HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
							
	    Query query=session.createQuery("from Paper");
	    List papers=query.list();
			
		tx.commit();
		HibernateSessionFactory.closeSession();
		
		
		return papers;
	}

	//删除paper
	public int deletepaper(int pid) {
		
		Session session=HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		
		Paper paper=(Paper)session.get(Paper.class, pid);
		
	    if(paper.getPid()!=0){
	    	
	    	session.delete(paper);
	    	tx.commit();
			HibernateSessionFactory.closeSession();
	    	return 1;
	    	
	    }else{
	    	
	    	tx.commit();
			HibernateSessionFactory.closeSession();
	    	return 0;
	    }
		
	}

	//修改paper
	public int updatepaper(Paper paper) {
			
		Session session=HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		
		Paper pa=(Paper)session.get(Paper.class, paper.getPid());
    	
	    if(pa.getPid()!=0){
	    	pa.setPname(paper.getPname());
	    	pa.setPemail(paper.getPemail());
	    	pa.setPmessage(paper.getPmessage());
	    	pa.setPsubject(paper.getPsubject());
	    	pa.setPlanguage(paper.getPlanguage());
	    	session.update(pa);
	    	tx.commit();
			HibernateSessionFactory.closeSession();
	    	return 1;
	    	
	    }else{
	    	
	    	tx.commit();
			HibernateSessionFactory.closeSession();
	    	return 0;
	    }
	}

}
