package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCConnection {
	
	
	public static Connection conn;
	
	public static Connection getConnection(){
		
		
		String url="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=lianxi";
		String username="sa";
		String password="123456";
		
		try {
			conn=DriverManager.getConnection(url,username,password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
		
	}
	
	public static void main(String [] args){
		
		System.out.println(""+JDBCConnection.getConnection());
		
	}
	
	

}
