package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.omg.CORBA.Request;

import com.google.gson.Gson;
import com.sun.mail.iap.Response;

import dao.ImpStudentDao;
import dao.InStudentService;
import bean.Paper;

public class PaperAction {

	private InStudentService instudent =new ImpStudentDao();
	private Paper pp;
	private List paperlist;
	
	//修改属性
	private int pid;
	private String pname;
	private String pemail;
	private String psubject;
	private String pmessage;
	private String planguage;
	
	
	//列表显示
	public void listPaper() throws IOException{
		
		paperlist= instudent.listPaper();	

		//创建输出流
		HttpServletResponse response=ServletActionContext.getResponse();
		
		response.setCharacterEncoding("utf-8");
		
		PrintWriter out=response.getWriter();
		
		
		Gson gso=new Gson();
		
	    String papers=gso.toJson(paperlist);
		
		out.write(papers);//直接写值
		out.flush();
		out.close();
		
	}

	//添加信息
	public void infoadd() throws IOException{
		
		 instudent.infoadd(pp);		
		
		 paperlist= instudent.listPaper();	

			//创建输出流
			HttpServletResponse response=ServletActionContext.getResponse();
			response.setCharacterEncoding("utf-8");
			PrintWriter out=response.getWriter();
			
			
			Gson gso=new Gson();
			
		    String papers=gso.toJson(paperlist);
			
			out.write(papers);//直接写值
			out.flush();
			out.close();

		
	}
	
	//修改信息
	public void updatepaper() throws IOException{
		//创建输出流
		HttpServletResponse response=ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");
		PrintWriter out=response.getWriter();
		
	   Paper paper=new Paper();
	   
	   paper.setPid(pid);
	   paper.setPname(pname);
	   paper.setPemail(pemail);
	   paper.setPsubject(psubject);
	   paper.setPmessage(pmessage);
	   paper.setPlanguage(planguage);
       
	   
	   int a=instudent.updatepaper(paper);
		 
		  out.println(a);
				
	}
	
	//删除paper
	public void deletepaper() throws IOException{
	  //创建输出流
      HttpServletResponse response=ServletActionContext.getResponse();
	  response.setCharacterEncoding("utf-8");
	  PrintWriter out=response.getWriter();
	  	  
	  int a=instudent.deletepaper(pid);
	  if(a==1){
		  out.println(a);

	  }else{
		  out.println(a);

	  }
		
		
	}

	
	public List getPaperlist() {
		return paperlist;
	}


	public void setPaperlist(List paperlist) {
		this.paperlist = paperlist;
	}


	public Paper getPp() {
		return pp;
	}

	public void setPp(Paper pp) {
		this.pp = pp;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPemail() {
		return pemail;
	}

	public void setPemail(String pemail) {
		this.pemail = pemail;
	}

	public String getPsubject() {
		return psubject;
	}

	public void setPsubject(String psubject) {
		this.psubject = psubject;
	}

	public String getPmessage() {
		return pmessage;
	}

	public void setPmessage(String pmessage) {
		this.pmessage = pmessage;
	}

	public String getPlanguage() {
		return planguage;
	}

	public void setPlanguage(String planguage) {
		this.planguage = planguage;
	}
	
	

	
	
	
	

}
