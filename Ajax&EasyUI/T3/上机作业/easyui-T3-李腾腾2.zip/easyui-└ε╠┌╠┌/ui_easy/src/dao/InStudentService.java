package dao;

import java.util.List;

import bean.Paper;

public interface InStudentService {

	//添加
	void infoadd(Paper paper);

	//列表显示
	List listPaper(String sort, String order);

	//删除
	int deletepaper(int pid);

	//修改
	int updatepaper(Paper paper);
	
	

}
