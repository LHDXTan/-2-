package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import bean.Student;

public class StudentDao {
	
	public List<Student> stulist(){
		Session se = HibernateSessionFactory.getSession();
		Transaction tx = se.beginTransaction();
		Query qu = se.createQuery("from Student");
		List<Student> list =new  ArrayList<Student>();
		list =  qu.list();
		tx.commit();
		return list;
	}
	public void addStu(Student s){
		Session se = HibernateSessionFactory.getSession();
		Transaction tx = se.beginTransaction();
		se.save(s);
		tx.commit();
	}
	public void delStu(int sid){
		Session se = HibernateSessionFactory.getSession();
		Transaction tx = se.beginTransaction();
		Student s = (Student)se.get(Student.class, sid);
		System.out.println(sid);
		se.delete(s);
		tx.commit();
	}
	public void updStu(Student s){
		Session se = HibernateSessionFactory.getSession();
		Transaction tx = se.beginTransaction();
		System.out.println(s.getSid());
		Student s1 = (Student)se.get(Student.class, s.getSid());
		s1.setSaddr(s.getSaddr());
		s1.setSclass(s.getSclass());
		s1.setSex(s.getSex());
		s1.setSname(s.getSname());
		se.update(s1);
		tx.commit();
	}
}
