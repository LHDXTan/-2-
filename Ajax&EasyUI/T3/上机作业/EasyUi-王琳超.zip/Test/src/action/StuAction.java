package action;

import java.util.List;

import dao.StudentDao;
import bean.Student;

public class StuAction  {
	
	private StudentDao dao  = new StudentDao();
	private Student stu;
    private List<Student> stulist;
    
	public List<Student> getStulist() {
		return stulist;
	}

	public void setStulist(List<Student> stulist) {
		this.stulist = stulist;
	}

	public Student getStu() {
		return stu;
	}

	public void setStu(Student stu) {
		this.stu = stu;
	}
	public String stuList(){
		stulist = dao.stulist();
		return"index";
	}
	public String addStu(){
		dao.addStu(stu);
		return"toindex";
	}
	public String delStu(){
		dao.delStu(stu.getSid());
		return"toindex";
	}
	public String updStu(){
		dao.updStu(stu);
		return "toindex";
	}
}
