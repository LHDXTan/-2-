package com.test.dao;

import java.util.List;

import com.test.bean.Login;



public interface IBaseDao {

	public List getAllList(String name,String pwd);


}