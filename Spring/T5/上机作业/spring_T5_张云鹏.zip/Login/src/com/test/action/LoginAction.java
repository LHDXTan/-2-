package com.test.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.net.aso.r;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.test.bean.Login;
import com.test.dao.IBaseDao;

public class LoginAction extends AbstractController	{
private IBaseDao bdao;
private HashMap  map;
private HashMap  map1;
	
	
	
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		String  name=request.getParameter("name");
		String  pwd=request.getParameter("pwd");

		
		if(request.getSession().getAttribute("map")==null){
			 map =new HashMap();
			 map.put(name, 0);
		}else{
			map=(HashMap) request.getSession().getAttribute("map");
			if(map.get(name)==null){
				map.put(name, 0);
			}
		}
	    
		
	int  s=	(Integer) map.get(name);
		//1锁定 0未锁定
		if(s==1){

			
				 map1 =(HashMap) request.getSession().getAttribute("map1");
			 Date shijian =(Date) map1.get(name);
			 
			 
			 Date afterDate = new Date(shijian.getTime() + 300000);
			 SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			 
			 Date d=new Date();
			long l1= d.getTime();
			long l2= afterDate.getTime();
			
			if(l1>=l2){
				request.getSession().removeAttribute("time");
				request.getSession().removeAttribute("sj");
				map=(HashMap) request.getSession().getAttribute("map");
				map.put(name, 0);
				request.getSession().setAttribute("map",map);
				return new ModelAndView("erro","suo","你的账号已解锁，可重新登录");
			
			}
			 
			 
			return new ModelAndView("erro","suo","你的账号将于"+df.format(afterDate)+"解锁");
		}else{
			List list=bdao.getAllList(name, pwd);

		if(list.size()!=0){
		   
			request.getSession().setAttribute("cs", 0);

			
			return new ModelAndView("login","login","登录成功");
		}else{
			
			if(request.getSession().getAttribute("cs")==null){
				request.getSession().setAttribute("cs", 0);
			}
			 int str= (Integer) request.getSession().getAttribute("cs");
			
			if(str==0){
				request.getSession().setAttribute("cs", 1);
				return new ModelAndView("erro","erro","登录失败，失败三次将锁定账号五分钟");
			}else{
				int a=(Integer) request.getSession().getAttribute("cs");
				a=a+1;
			if(a<=3){
				request.getSession().setAttribute("cs", a);
				return new ModelAndView("erro","erro","登录失败，失败三次将锁定账号五分钟");
			}else{
				String sj="";
				
				if(request.getSession().getAttribute("sj")!=null){
					sj=(String) request.getSession().getAttribute("sj");
				}else{
				
			   SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			   sj=df.format(new Date());
			  request.getSession().setAttribute("sj", df.format(new Date()));
			  request.getSession().setAttribute("time", new Date());
			  }
				map=new HashMap();
				map.put(name, 1);
				
				request.getSession().setAttribute("map", map);
				request.getSession().setAttribute("time", new Date());
				Date day=(Date) request.getSession().getAttribute("time");
				map1=new HashMap();
				map1.put(name, day);
				request.getSession().setAttribute("map1", map1);
				return new ModelAndView("erro","suo","失败已经超过三次你的账号于"+sj+"起锁定五分钟");
			}
		}

		}
			
			
			
			
		}
		


	}




	public IBaseDao getBdao() {
		return bdao;
	}
	public void setBdao(IBaseDao bdao) {
		this.bdao = bdao;
	}




	public HashMap getMap() {
		return map;
	}




	public void setMap(HashMap map) {
		this.map = map;
	}




	public HashMap getMap1() {
		return map1;
	}




	public void setMap1(HashMap map1) {
		this.map1 = map1;
	}

}
