package com.test.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.test.bean.Login;




public class BaseDaoImp extends HibernateDaoSupport implements IBaseDao {

		public List getAllList(String name,String pwd){
			String hql="select l from Login l where l.name="+"'"+name+"'"+"  and l.pwd="+"'"+pwd+"'";
			return super.getHibernateTemplate().find(hql);
		}

		
		
		
		
		
		
		
}
