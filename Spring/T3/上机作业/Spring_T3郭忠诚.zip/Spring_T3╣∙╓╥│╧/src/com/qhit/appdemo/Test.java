package com.qhit.appdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext appContext=new ClassPathXmlApplicationContext("/applicationContext.xml");
		IBean bean1=(IBean) appContext.getBean("beanproxy");
		
		bean1.sayHello();

	}

}
