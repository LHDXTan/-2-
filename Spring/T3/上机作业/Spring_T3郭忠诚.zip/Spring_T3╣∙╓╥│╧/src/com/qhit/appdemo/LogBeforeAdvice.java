package com.qhit.appdemo;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.MethodBeforeAdvice;

public class LogBeforeAdvice implements MethodBeforeAdvice{
    
	
	Log log=LogFactory.getLog(this.getClass());
	@Override
	public void before(Method m, Object[] target, Object arg2)
			throws Throwable {
		log.info("拦截对象["+target.getClass().getName()+"]的方法的调用:"+m.getName());
		
	}

}
