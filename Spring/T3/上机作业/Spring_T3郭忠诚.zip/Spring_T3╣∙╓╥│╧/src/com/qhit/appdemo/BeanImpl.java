package com.qhit.appdemo;

public class BeanImpl implements IBean {

	
   private String hello;
	
   @Override
	public void sayHello() {
		System.out.println(hello);
    }

     public void sayHello(String hello){
	   this.hello=hello;
   }

    public String getHello() {
	return hello;
}

    public void setHello(String hello) {
	this.hello = hello;
}
}
