package com.qhit.appdemo;

public interface IBean {
	public void sayHello();

}
