package com.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.inter.IBean;
import com.inter.IBeanImpl;

public class Test  {
          public static void main(String[] args) {
//			IBeanImpl ibean=new IBeanImpl();
//			LogHan log=new LogHan();
//			IBean i=(IBean)log.bind(ibean);
//			i.songb();
//        	  ApplicationContext app=new ClassPathXmlApplicationContext("applicationContext.xml");
//        	  IBean i=(IBean) app.getBean("beanproxy");
//        	  i.say();
        	  Resource re=new ClassPathResource("applicationContext.xml");
        	  BeanFactory b=new XmlBeanFactory(re);
        	  IBean i=(IBean) b.getBean("beanproxy");
        	  i.say();
		}
}
