package com.test;
import java.lang.reflect.Method;

import net.sf.cglib.proxy.InvocationHandler;
import net.sf.cglib.proxy.Proxy;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class LogHan implements InvocationHandler {

	Log log=LogFactory.getLog(this.getClass());
	private Object target;
	public Object bind(Object target){
		
		this.target=target;
		
		return Proxy.newProxyInstance(target.getClass().getClassLoader(), target.getClass().getInterfaces(), this);	
	}
	@Override
	public Object invoke(Object proxy, Method method, Object[] args)
			throws Throwable {
		// TODO Auto-generated method stub
		Object result=null;
		log.info("日志记录开始了...");
		result=method.invoke(target, args);
		log.info("日志记录结束...");
		return result;
	}
	public Object getTarget() {
		return target;
	}
	public void setTarget(Object target) {
		this.target = target;
	}


}
