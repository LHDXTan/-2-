package com.inter;


public class IBeanImpl implements IBean {
 // Log log=LogFactory.getLog(this.getClass());
	@Override
	public void songb() {
		// TODO Auto-generated method stub
         //  log.info("开始日志记录...");
           System.out.println("实现.......");
         //  log.info("结束日志记录...");
	}
    private String song;
	public String getSong() {
		return song;
	}
	public void setSong(String song) {
		this.song = song;
	}
	@Override
	public void say() {
		// TODO Auto-generated method stub
		System.out.println(song);
	}
    
}
