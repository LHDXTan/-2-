package com.inter;

public interface IBean {
      
	public void songb();
	public void say();
//	public void sayHello()throws MyException;
}
