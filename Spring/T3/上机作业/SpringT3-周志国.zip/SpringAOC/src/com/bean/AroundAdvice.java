package com.bean;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class AroundAdvice implements MethodInterceptor{

	@Override
	public Object invoke(MethodInvocation n) throws Throwable {
		// TODO Auto-generated method stub
		System.out.println("之前");
		Object o=n.proceed();
		System.out.println("之后");
		return o;
	}

}
