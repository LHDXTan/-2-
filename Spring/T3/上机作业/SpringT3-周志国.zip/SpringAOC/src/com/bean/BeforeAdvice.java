package com.bean;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.MethodBeforeAdvice;

public class BeforeAdvice implements MethodBeforeAdvice {

	@Override
	public void before(Method m, Object[] arg1, Object target)
			throws Throwable {
		// TODO Auto-generated method stub
     Log log=LogFactory.getLog(this.getClass());
     log.info("拦截对象"+target.getClass().getName()+"所属的方法:"+m.getName());
	}

}
