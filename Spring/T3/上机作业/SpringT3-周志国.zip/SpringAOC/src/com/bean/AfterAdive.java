package com.bean;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.AfterReturningAdvice;

public class AfterAdive implements AfterReturningAdvice {

	@Override
	public void afterReturning(Object arg0, Method m, Object[] target,
			Object arg3) throws Throwable {
		// TODO Auto-generated method stub
       Log log=LogFactory.getLog(this.getClass());
       log.info("被拦截的对象"+target.getClass().getName()+"所属的方法"+m.getName());
	}

}
