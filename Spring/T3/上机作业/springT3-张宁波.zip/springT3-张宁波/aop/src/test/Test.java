package test;

import interfaces.IBean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext app=new ClassPathXmlApplicationContext("applicationContext.xml");
		IBean bean1=(IBean) app.getBean("beanproxy");
		bean1.sayHello();
	}

}
