package interfaces;

public class BeanImpl implements IBean {

	private String hello;
	
	
	public String getHello() {
		return hello;
	}


	public void setHello(String hello) {
		this.hello = hello;
	}


	@Override
	public void sayHello() {
		// TODO Auto-generated method stub
		System.out.println(hello);
	}

}
