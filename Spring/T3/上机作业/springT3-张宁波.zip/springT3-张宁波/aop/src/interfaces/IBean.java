package interfaces;

public interface IBean {
	public void sayHello();

}
