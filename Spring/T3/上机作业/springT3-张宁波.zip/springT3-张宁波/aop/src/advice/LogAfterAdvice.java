package advice;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.AfterReturningAdvice;

public class LogAfterAdvice implements AfterReturningAdvice {

	Log log=LogFactory.getLog(this.getClass());
	@Override
	public void afterReturning(Object object, Method m, Object[] target,
			Object arg3) throws Throwable {
		// TODO Auto-generated method stub
		log.info("在对象["+arg3.getClass().getName()+"]的方法"+m.getName()+"调用之后执行日志");
	}

}
