package dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class EmpDaoImpl extends HibernateDaoSupport implements IEmpDao {

	@Override
	public void add(Object obj) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().save(obj);
	}

	@Override
	public void delete(Object obj) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().delete(obj);
	}

	@Override
	public void update(Object obj) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().update(obj);
	}

	@Override
	public Object getObjectById(Class clazz, Serializable id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getObjects(String hql) {
		// TODO Auto-generated method stub
		
		return super.getHibernateTemplate().find(hql);
	}

}
