package com.text;

public class Beanlmpl  implements lBean{
    private String hello;

	@Override
	public void sayHello() {
		// TODO Auto-generated method stub
		System.out.println(hello);
	}

	public String getHello() {
		return hello;
	}

	public void setHello(String hello) {
		this.hello = hello;
	}
   
	
	
}
