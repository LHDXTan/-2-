package com.text;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ApplicationContext appContext = new ClassPathXmlApplicationContext("/applicationContext.xml");
		 lBean bean=   (lBean) appContext.getBean("beanproxy");
		  bean.sayHello();
	}

}
