package com.text;

public interface lBean {

	public void sayHello();
	
}
