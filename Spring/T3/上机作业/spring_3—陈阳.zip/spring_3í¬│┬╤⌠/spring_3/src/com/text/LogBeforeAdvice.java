package com.text;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.MethodBeforeAdvice;

public class LogBeforeAdvice implements MethodBeforeAdvice {
      
	  Log log = LogFactory.getLog(this.getClass());
	
	@Override
	public void before(Method m, Object[] args, Object target)
			throws Throwable {
		// TODO Auto-generated method stub
		log.info("拦截对象["+target.getClass().getName()+"]的方法调用"+m.getName());
	}

}
