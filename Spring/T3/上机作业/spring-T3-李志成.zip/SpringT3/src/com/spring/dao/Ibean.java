package com.spring.dao;

import org.springframework.mail.MailException;

public interface Ibean {
	 public void sayhello();
}
