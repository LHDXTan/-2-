package com.spring.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.dao.Ibean;
import com.spring.daoImpl.Ibeamimpl;

public class test {
   public static void main(String[] args) {
	  ApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
	  Ibean ibean=(Ibean) context.getBean("beanproxy");
	  ibean.sayhello();	  
}
}
