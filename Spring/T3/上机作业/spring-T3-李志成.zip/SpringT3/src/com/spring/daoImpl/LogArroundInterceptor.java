package com.spring.daoImpl;

import java.lang.reflect.Method;

import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

public class LogArroundInterceptor implements MethodInterceptor {
  Log log=LogFactory.getLog(this.getClass());

     
	public Object invoke(MethodInvocation methodInvocation) throws Throwable{
		log.info("开始执行方法:"+methodInvocation.getMethod());
		
		Object result=null;
		try{
			result=methodInvocation.proceed();
		}finally{
			log.info("方法执行结束:"+methodInvocation.getMethod());
			
		}
		return result;
		
	}


	@Override
	public Object intercept(Object arg0, Method arg1, Object[] arg2,
			MethodProxy arg3) throws Throwable {
		// TODO Auto-generated method stub
		return null;
	}


}
