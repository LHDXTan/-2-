package com.spring.daoImpl;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.MethodBeforeAdvice;

public class LogBeforeAdvice implements MethodBeforeAdvice {
    
	 Log log=LogFactory.getLog(this.getClass());
	@Override
	public void before(Method arg0, Object[] arg1, Object arg2)
			throws Throwable {
		// TODO Auto-generated method stub
	 System.out.println("拦截对象["+arg2.getClass().getName()+"]的方法调用"+arg0.getName());
     log.info("拦截对象["+arg2.getClass().getName()+"]的方法调用"+arg0.getName());
	}

}
