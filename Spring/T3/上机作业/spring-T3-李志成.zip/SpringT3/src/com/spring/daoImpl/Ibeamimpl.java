package com.spring.daoImpl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.mail.MailAuthenticationException;
import org.springframework.mail.MailException;

import com.spring.dao.Ibean;

public class Ibeamimpl implements Ibean {
	Log log=LogFactory.getLog(this.getClass());
	private String hello;
    
	@Override
	public void sayhello() {
		// TODO Auto-generated method stub
		
		System.out.println(hello);
		
		
	}
  


	public String getHello() {
		
		return hello;
	}

	public void setHello(String hello) {
		this.hello = hello;
		
	}

}
