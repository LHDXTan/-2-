package com.test.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.test.dao.IBaseDao;

public class Test {

	public static void main(String[] args) {

		Resource r = new ClassPathResource("/applicationContext.xml");
		BeanFactory factory = new XmlBeanFactory(r);
		
		IBaseDao dao = (IBaseDao) factory.getBean("beanproxy");
		
		dao.song();
		
	}
}
