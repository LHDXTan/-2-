package com.test.dao;

import java.text.SimpleDateFormat;
import java.util.Date;

public class BaseDaoImp implements IBaseDao {

	
	/* (non-Javadoc)
	 * @see com.tsinghuait.demo.dao.IBaseDao#song()
	 */
	public void song(){
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println("Dao"+"\t"+"-----"+"\t"+df.format(new Date()));
		
		System.out.println("好，很好 你被录用了"+"\t"+"-----"+"\t"+df.format(new Date()));
	}
}
