package com.test.advice;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.aop.MethodBeforeAdvice;

public class LogBeaforAdvice implements MethodBeforeAdvice {

	public void before(Method arg0, Object[] arg1, Object arg2)
			throws Throwable {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println("前加强"+"\t"+"-----"+"\t"+df.format(new Date()));
		
		
		System.out.println("老子要干活了"+"\t"+"-----"+"\t"+df.format(new Date()));
	}

}
