package com.test.dao;

public interface IBaseDao {

	public void song();

}