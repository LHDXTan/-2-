package com.test.advice;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class LogAroundAdvice implements MethodInterceptor {

	public Object invoke(MethodInvocation arg0) throws Throwable {
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println("前后加强"+"\t"+"-----"+"\t"+df.format(new Date()));
		
		System.out.println("准备干活־"  +"\t"+"-------"+"\t"+df.format(new Date()));
		Object obj = arg0.proceed();
		System.out.println("老子干完了"+"\t"+"-------"+"\t"+df.format(new Date()));
		
		
		return obj;
	}

}
