package com.test.advice;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.aop.AfterReturningAdvice;


public class LogAfterAdvice  implements AfterReturningAdvice {

	public void afterReturning(Object arg0, Method arg1, Object[] arg2,
			Object arg3) throws Throwable {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println("后加强"+"\t"+"-----"+"\t"+df.format(new Date()));
		
		
		System.out.println("活没干好"+"\t"+"-----"+"\t"+df.format(new Date()));
	}

}
