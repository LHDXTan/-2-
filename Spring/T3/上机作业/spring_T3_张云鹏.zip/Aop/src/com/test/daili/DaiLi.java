package com.test.daili;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.AfterReturningAdvice;


public class DaiLi implements AfterReturningAdvice{
	
	private Object target;

	

	@Override
	public void afterReturning(Object arg0, Method arg1, Object[] arg2,
			Object arg3) throws Throwable {
		// TODO Auto-generated method stub
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println("开始代理"+"\t"+"-----"+"\t"+df.format(new Date()));	
		System.out.println("小伙子，开始工作，记录日志"+"\t"+"-----"+"\t"+df.format(new Date()));
	System.out.println("所执行的方法"+"----"+arg1.getName());	
		System.out.println("工作结束没有工资，日志记录完毕"+"\t"+"-----"+"\t"+df.format(new Date()));
	}

}
