package com.test.basedao;

import java.io.Serializable;
import java.util.List;

public interface BaseDao {
	public void add(Object obj);
	public void update(Object obj);
	public void delete(Object obj);
	
	public Object getObjectByid(Class clazz,Serializable id);
	public List getObjects(String hql);
}
