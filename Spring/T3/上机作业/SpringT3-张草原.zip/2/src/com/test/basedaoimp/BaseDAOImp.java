package com.test.basedaoimp;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.test.basedao.BaseDao;

public class BaseDAOImp extends HibernateDaoSupport implements BaseDao {

	@Override
	public void add(Object obj) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().save(obj);
	}

	@Override
	public void update(Object obj) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().update(obj);
	}

	@Override
	public void delete(Object obj) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().delete(obj);
	}

	@Override
	public Object getObjectByid(Class clazz, Serializable id) {
		// TODO Auto-generated method stub
		return super.getHibernateTemplate().get(clazz, id);
	}

	@Override
	public List getObjects(String hql) {
		// TODO Auto-generated method stub
		return super.getHibernateTemplate().find(hql);
	}

}
