package com.test.aopdemo;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.AfterReturningAdvice;

public class LogAfterAdvice implements AfterReturningAdvice {
	Log log=LogFactory.getLog(this.getClass());
	@Override
	public void afterReturning(Object arg0, Method arg1, Object[] arg2,
			Object arg3) throws Throwable {
		// TODO Auto-generated method stub
		log.info("在对象["+arg2.getClass().getName()+"]的方法"+arg1.getName()+"调用之后执行日志");
	}

}
