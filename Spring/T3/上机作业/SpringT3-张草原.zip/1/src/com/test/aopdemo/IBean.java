package com.test.aopdemo;

public interface IBean {
	public void sayHello();
}
