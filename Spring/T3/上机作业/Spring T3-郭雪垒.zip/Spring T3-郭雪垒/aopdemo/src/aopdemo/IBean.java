package aopdemo;

public interface IBean {
	
	public void sayHello();

}
