package aopdemo;

public class BeanImpl implements IBean {

	private String hello;
	
	@Override
	public void sayHello() {
		System.out.println(hello);

	}


	public void setHello(String hello) {
		this.hello = hello;
	}
	


}
