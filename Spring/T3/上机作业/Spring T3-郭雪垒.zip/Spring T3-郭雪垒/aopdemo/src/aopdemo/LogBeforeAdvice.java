package aopdemo;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.MethodBeforeAdvice;

public class LogBeforeAdvice implements MethodBeforeAdvice {
	
	Log log=LogFactory.getLog(this.getClass());

	@Override
	public void before(Method arg0, Object[] arg1, Object arg2)
			throws Throwable {
		log.info("���ض���["+arg2.getClass().getName()+"]�ķ�������:"+arg0.getName());

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
