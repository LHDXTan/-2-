package action;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Student;
import dao.BaseDao;

public class StuAction {
	private Student stu;
	private List<Student> list;
	private BaseDao basedao;
	
	public String list(){
		list=basedao.getObjects("from Student");
		return "list";
	}
	
	public String add(){
		basedao.add(stu);
		return "tolist";
		
	}

//	public static void main(String[] args) {
//		ApplicationContext appContext=new ClassPathXmlApplicationContext("/applicationContext.xml");
//		BaseDao basedao=(BaseDao) appContext.getBean("basedao");
		
		//��ѯ
//		for(Object o:basedao.getObjects("from Student")){
//		System.out.println(o);
//	}
		
		
		//����
//		Student stu=new Student();
//		stu.setSname("����");
//		stu.setSage(20);
//	    stu.setSex("��");
//		stu.setSno("1002");
		
//		basedao.add(stu);
	
		
		//�޸�
//		Student stu=(Student) basedao.getObjectById(Student.class, 5);
//		stu.setSname("����");
//		
//		basedao.update(stu);
		
		
		//ɾ��
//		basedao.delete(stu);
		
//	}

	public BaseDao getBasedao() {
		return basedao;
	}

	public void setBasedao(BaseDao basedao) {
		this.basedao = basedao;
	}

	public List<Student> getList() {
		return list;
	}

	public void setList(List<Student> list) {
		this.list = list;
	}

	public Student getStu() {
		return stu;
	}

	public void setStu(Student stu) {
		this.stu = stu;
	}
	
	

}
