package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Student;
import dao.BaseDao;

public class demotest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext appContext = new ClassPathXmlApplicationContext("/applicationContext.xml");
		BaseDao basedao=(BaseDao) appContext.getBean("basedao");
		
//		Student stu=new Student();
//		stu.setSname("����");
//		stu.setSsex("M");
//		stu.setSage(new Integer(20));
//		
//		basedao.add(stu);
		
		for(Object o:basedao.getObjects("from Student")){
			System.out.println(o);
		}

	}

}
