package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import aopdemo.IBean;

public class TestAOP {

	public static void main(String[] args) {
		ApplicationContext appContext=new ClassPathXmlApplicationContext("/applicationContext.xml");
		IBean ibean=(IBean)appContext.getBean("beanproxy");
		
		ibean.sayHello();
		
	}

}
