package aopdemo;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.MethodBeforeAdvice;//3.1版本spring才可引入

//目标对象方法执行之前注入的Advice
public class LogBeforAdvice  implements MethodBeforeAdvice{


	Log log=LogFactory.getLog(this.getClass());
	
	public void before(Method method, Object[] ob1, Object target)
			throws Throwable {

		log.info("拦截对象【"+target.getClass().getName()+"]的方法调用："+method.getName());
		
	}

}
