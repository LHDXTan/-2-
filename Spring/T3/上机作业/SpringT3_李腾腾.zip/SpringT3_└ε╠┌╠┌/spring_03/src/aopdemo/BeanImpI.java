package aopdemo;

//目标类接口实现
public class BeanImpI implements IBean {

    private String hello;
    
    
	public void sayHello() {
    
	  System.out.println(hello);	
	}
	
	public void setHello(String hello){
		this.hello=hello;
	}

}
