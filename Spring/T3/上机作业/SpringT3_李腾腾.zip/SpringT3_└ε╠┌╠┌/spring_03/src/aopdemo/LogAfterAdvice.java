package aopdemo;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.AfterReturningAdvice;

//目标对象方法执行之后注入的Adrice
public class LogAfterAdvice implements  AfterReturningAdvice{

	Log log=LogFactory.getLog(this.getClass());
	
	@Override
	public void afterReturning(Object target, Method method, Object[] ob,Object arg3) 
			throws Throwable {
		
		log.info("在对象"+arg3.getClass().getName()+"]的方法"+method.getName()+"调用之后执行！");
		
	}

}
