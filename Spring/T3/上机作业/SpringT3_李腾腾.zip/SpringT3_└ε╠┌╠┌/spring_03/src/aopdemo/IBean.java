package aopdemo;

//目标类接口
public interface IBean {
	
	public void sayHello();

}
