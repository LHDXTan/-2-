package BeanDaoImpl;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.AfterReturningAdvice;

public class LogAfterAdvice implements AfterReturningAdvice{
	
	//ʵ������־
	Log log = LogFactory.getLog(this.getClass());

	@Override
	public void afterReturning(Object arg0, Method arg1, Object[] arg2,
			Object target) throws Throwable {
		// TODO Auto-generated method stub
		log.info("�ڶ���["+target.getClass().getName()+"]�ķ���"+
				arg1.getName()+"����֮��ִ����־�ļ�");
	}

}
