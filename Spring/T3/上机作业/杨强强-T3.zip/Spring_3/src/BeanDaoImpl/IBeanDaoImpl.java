package BeanDaoImpl;

import BeanDao.IBeanDao;

public class IBeanDaoImpl implements IBeanDao{
	
	public String hello;

	@Override
	public void SayHello() {
		// TODO Auto-generated method stub
		System.out.println(hello);
	}
	
	
	
//get set ����
	public String getHello() {
		return hello;
	}

	public void setHello(String hello) {
		this.hello = hello;
	}
	
	
	

}
