package BeanDaoImpl;

import java.lang.annotation.Target;
import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.MethodBeforeAdvice;

public class LogBeforeAdvice implements MethodBeforeAdvice{
	
	//ʵ������־
	Log log = LogFactory.getLog(this.getClass());

	@Override
	public void before(Method arg0, Object[] args, Object target)
			throws Throwable {
		// TODO Auto-generated method stub
		//��������
		log.info("���ض���:["+target.getClass().getName()+"]�ķ������ã�"+
				arg0.getName());
	}

}
