package BeanDao;

public interface IBeanDao {
	
	public void SayHello();

}
