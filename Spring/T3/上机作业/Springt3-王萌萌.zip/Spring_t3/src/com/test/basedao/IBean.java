package com.test.basedao;

public interface IBean {

	public void sayHello();
}
