package com.qhit.Action;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.opensymphony.xwork2.ActionSupport;
import com.qhit.Bean.Student;
import com.qhit.Dao.BaseDao;
import com.qhit.DaoImpl.baseDaoImpl;

public class LoginAction extends ActionSupport {
	
	 private BaseDao bdao;
	 Student stu=new Student();

	 public String Add(){
		 stu.setId("11");
		 stu.setName("忘冰");
		 stu.setTel("1234r56");
		 stu.setDress("日本");
		 bdao.add(stu);
		 Select();
		 return "add";
	 }
	 
	 public void Delete(){
		 stu.setId("2");
		 bdao.del(stu);
	 }
	 
	 public void Update(){
		 stu.setId("2");
		 stu.setName("微凉");
		 stu.setTel("1234r56");
		 stu.setDress("中国");
		 bdao.upd(stu);
	 }
	 
	 public void Select(){
		 List list =bdao.sel(Student.class, "1");
		 int size = list.size();
		for(int i=0;i<size;i++){
			Student object = (Student)list.get(i);
			System.out.println(object.getId()+object.getName());
		}
	 }

	public LoginAction(BaseDao bdao) {
		super();
		this.bdao = bdao;
	}
	 	 

}
