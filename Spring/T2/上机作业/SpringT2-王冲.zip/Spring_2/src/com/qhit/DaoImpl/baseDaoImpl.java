package com.qhit.DaoImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.qhit.Dao.BaseDao;

public class baseDaoImpl extends HibernateDaoSupport implements BaseDao {

	@Override
	public List sel(Class clazz,String str) {
		List list=new ArrayList();
		Object object = super.getHibernateTemplate().get(clazz, str);
		list.add(object);
		return list;
	}

	@Override
	public void add(Object obj) {
		super.getHibernateTemplate().save(obj);

	}

	@Override
	public void del(Object obj) {
		super.getHibernateTemplate().delete(obj);		
	}

	@Override
	public void upd(Object obj) {
		super.getHibernateTemplate().update(obj);
	}

}
