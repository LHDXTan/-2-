package com.qhit.Dao;

import java.util.List;

public interface BaseDao {

	public void add(Object obj); 
	
	public void del(Object obj);
	
	public void upd(Object obj); 
	
	public List sel(Class clazz,String str);
}
