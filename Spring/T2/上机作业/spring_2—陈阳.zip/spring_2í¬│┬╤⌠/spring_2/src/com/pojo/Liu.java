package com.pojo;

import java.math.BigDecimal;

/**
 * Liu entity. @author MyEclipse Persistence Tools
 */

public class Liu implements java.io.Serializable {

	// Fields

	private Integer id;
	private String name;
	private String sex;
	private Integer age;

	public String toString (){
		
		return id +name+sex+age;
	}
	// Constructors

	/** default constructor */
	public Liu() {
	}

	/** full constructor */
	public Liu(String name, String sex, Integer age) {
		this.name = name;
		this.sex = sex;
		this.age = age;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Integer getAge() {
		return this.age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

}