package com.action;

import java.util.List;

import com.dao.IBaseDao;
import com.opensymphony.xwork2.Action;
import com.pojo.Liu;

public class LoginAction implements Action {

	private Liu liu;
	
	private List liulist;
	private IBaseDao dao;
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	//查询所有数据
	public String selList (){
		
		liulist = dao.getObjects("from Liu");
		System.out.println("查询所有数据");
		return "list";
		
	}
	//添加数据
	public String addliu(){
		
		dao.add(liu);
		System.out.println("添加数据");
		return "tolist";
	}
	//进入修改页面
	public String touqdateliu(){
		
		liu = (Liu) dao.getObjectById(Liu.class, liu.getId());
		System.out.println("进入修改页面");
		 return "totian";
	}
	
	//修改数据
	public String updateliu(){
		 Liu id = (Liu) dao.getObjectById(Liu.class, liu.getId());
		 id.setName(liu.getName());
		 id.setSex(liu.getSex());
		 id.setAge(liu.getAge());
		 dao.update(id);
		 System.out.println("修改数据");
		return "tolist";
	}
  //删除数据
	 public String delliu(){
		Liu id =  (Liu) dao.getObjectById(Liu.class,liu.getId());
		 dao.delete(id);
		 System.out.println("删除数据");
		 return  "tolist";
		 
	 }

	public Liu getLiu() {
		return liu;
	}


	public void setLiu(Liu liu) {
		this.liu = liu;
	}


	public List getLiulist() {
		return liulist;
	}


	public void setLiulist(List liulist) {
		this.liulist = liulist;
	}


	public IBaseDao getDao() {
		return dao;
	}


	public void setDao(IBaseDao dao) {
		this.dao = dao;
	}
	
	
	

}
