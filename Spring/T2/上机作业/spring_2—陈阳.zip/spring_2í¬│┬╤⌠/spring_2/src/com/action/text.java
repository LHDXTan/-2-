package com.action;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.IBaseDao;
import com.pojo.Liu;


public class text {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
		 ApplicationContext appContext = new ClassPathXmlApplicationContext("/applicationContext.xml");
		 IBaseDao dao =  (IBaseDao) appContext.getBean("dao");
		 Liu l = new Liu();
         
		 l.setName("ss3");
		 l.setSex("男");
		 l.setAge(15);
		 dao.add(l);
		 
		 
		 for(Object o :dao.getObjects("from Liu")){
			 System.out.println(o);
		 }
		 
	}

}
