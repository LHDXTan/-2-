package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.*;

import com.google.gson.Gson;

import dao.IBeandao;

public class StudentAction {

	ApplicationContext appContext=new ClassPathXmlApplicationContext("/applicationContext.xml");
	IBeandao beandao=(IBeandao)appContext.getBean("ibeandao");
	
	private List studentlist;//paper集合信息
	
	//属性
	private String sno;
	private String sname;
	private Integer sage;
	private String ssex;
	
	//列表显示
	public void studentList() throws IOException{
		String hql="select s from Student s";
		studentlist=beandao.studentlist(hql);
		//创建输出流
	    HttpServletResponse response=ServletActionContext.getResponse();
	    response.setCharacterEncoding("utf-8");
		PrintWriter out=response.getWriter();

		Gson gson=new Gson();
		String papers=gson.toJson(studentlist);
		out.write(papers);
		out.flush();
		out.close();
		
		
	}
	
	//人员添加和修改(为什么添加不上?答案：应该指定序列suqence)
	public void studentAdd() throws IOException{
		
	System.out.println(sno);
		if(sno.equals("")){
			//添加
			Student student1=new Student();
			student1.setSage(sage);
			student1.setSname(sname);
			student1.setSsex(ssex);
			beandao.addstudent(student1);;	
		}else{
			//修改
			Student student=new Student();
			student.setSno(sno);
			student.setSage(sage);
			student.setSname(sname);
			student.setSsex(ssex);
		    
			beandao.updatestudent(student);
		}
		
		
		//创建输出流
	    HttpServletResponse response=ServletActionContext.getResponse();
	    response.setCharacterEncoding("utf-8");
		PrintWriter out=response.getWriter();
		out.write("ok");
		out.flush();
		out.close();
		
	}
	
	//删除
	public void deletestudent() throws IOException{

		Student student=new Student();
		student.setSno(sno);
		beandao.deletestudent(student);
		
		//创建输出流
	    HttpServletResponse response=ServletActionContext.getResponse();
	    response.setCharacterEncoding("utf-8");
		PrintWriter out=response.getWriter();
		int a=1;
		out.println(a);
		out.flush();
		out.close();
		
	}

	
	//get和set方法
	public List getStudentlist() {
		return studentlist;
	}

	public void setStudentlist(List studentlist) {
		this.studentlist = studentlist;
	}

	public String getSno() {
		return sno;
	}

	public void setSno(String sno) {
		this.sno = sno;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Integer getSage() {
		return sage;
	}

	public void setSage(Integer sage) {
		this.sage = sage;
	}

	public String getSsex() {
		return ssex;
	}

	public void setSsex(String ssex) {
		this.ssex = ssex;
	}

	
    
}


