package dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;



public class ImpBeandao  extends HibernateDaoSupport implements IBeandao {

    //列表显示
	public List studentlist(String hql) {
		return super.getHibernateTemplate().find(hql);
	}
    //人员添加
	public void addstudent(Object ob) {	
        super.getHibernateTemplate().save(ob);

		
	}
	//人员删除
	public void deletestudent(Object ob) {
        super.getHibernateTemplate().delete(ob);		
	}
	//人员修改
	public void updatestudent(Object ob) {
        super.getHibernateTemplate().update(ob);
		
	}

}
