package dao;

import java.util.List;

public interface IBeandao {
	
	//信息显示
	public List studentlist(String hql);
	//添加
	public void addstudent(Object ob);
    //删除
	public void deletestudent(Object ob);
	//修改
	public void updatestudent(Object ob);
	
}
