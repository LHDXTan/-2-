package com.test.action;

import java.util.List;

import com.opensymphony.xwork2.ActionSupport;
import com.test.basedao.BaseDao;
import com.test.pojo.Student;

public class Action1 extends ActionSupport {
	private BaseDao basedao;
	private List li;
	private Student stu;
	
	//����
	public String zs(){
		basedao.add(stu);
		return "zhuce";
	}
	//��ѯ
	public String cx(){
		li=basedao.getObjects("from Student");
		return "chaxun";
	}
	//ɾ��
	public String sc(){
		Student s=(Student) basedao.getObjectByid(Student.class, stu.getSno());
		basedao.delete(s);
		return "zhuce";
	}
	//��ȡ�޸�id�����޸�ҳ��
	public String xg(){
		stu=(Student) basedao.getObjectByid(Student.class,stu.getSno());
		return "xiugai";
	}
	//�޸�
	public String xg2(){
		basedao.update(stu);
		return "zhuce";
	}

	
	
	
	public List getLi() {
		return li;
	}
	public void setLi(List li) {
		this.li = li;
	}
	public BaseDao getBasedao() {
		return basedao;
	}
	public void setBasedao(BaseDao basedao) {
		this.basedao = basedao;
	}
	public Student getStu() {
		return stu;
	}
	public void setStu(Student stu) {
		this.stu = stu;
	}
	
}
