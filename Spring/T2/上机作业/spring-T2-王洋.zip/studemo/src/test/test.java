package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Student;
import dao.IBaseDao;

public class test {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("/applicationContext.xml");
	    IBaseDao baseDao=(IBaseDao) applicationContext.getBean("basedao");
	    
	    Student student=new Student();
	    student.setStuname("����");
	    student.setStusex("M");
	    student.setStuage(20);
	    
	    baseDao.add(student);
	    
	    for(Object o:baseDao.getObjects("from Student")){
	    	student=(Student)o;
	    	System.out.println(student.getStuname());
	    }
	}

}
