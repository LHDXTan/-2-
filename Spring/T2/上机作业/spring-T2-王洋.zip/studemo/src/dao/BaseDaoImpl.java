package dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class BaseDaoImpl  extends HibernateDaoSupport implements IBaseDao  {

	@Override
	public void add(Object object) {
		super.getHibernateTemplate().save(object);

	}

	@Override
	public void update(Object object) {
		super.getHibernateTemplate().update(object);
	}

	@Override
	public void delete(Object object) {
		super.getHibernateTemplate().delete(object);
	}

	@Override
	public Object getObjectById(Class clazz, Serializable id) {
		return super.getHibernateTemplate().get(clazz, id);
	}

	@Override
	public List getObjects(String hql) {
		return super.getHibernateTemplate().find(hql);
	}

}
