package action;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Student;
import dao.IBaseDao;

public class StudentAction {
	//ApplicationContext applicationContext=new ClassPathXmlApplicationContext("/applicationContext.xml");
    //IBaseDao baseDao=(IBaseDao) applicationContext.getBean("baseDao");
    
    private Student student;
	private List list;
    private IBaseDao baseDao;
    

	public IBaseDao getBaseDao() {
		return baseDao;
	}


	public void setBaseDao(IBaseDao baseDao) {
		this.baseDao = baseDao;
	}


	public List getList() {
		return list;
	}


	public void setList(List list) {
		this.list = list;
	}


	public Student getStudent() {
		return student;
	}


	public void setStudent(Student student) {
		this.student = student;
	}



	public String list(){
	  list=baseDao.getObjects("from Student");
		
	  return "list";
	}


	public String add(){
		baseDao.add(student);
		
		 return "tolist";
		
	}
	
	public String toupdate(){
	   student=(Student) baseDao.getObjectById(Student.class, student.getStuid());
		
		
		return "toupdate";
	}
	
	public String update(){
		Student student1=(Student) baseDao.getObjectById(Student.class, student.getStuid());
		student1.setStuname(student.getStuname());
		student1.setStusex(student.getStusex());
		student1.setStuage(student.getStuage());
		baseDao.update(student1);
		
		return "tolist";
	}

	public String delete(){
		student=(Student) baseDao.getObjectById(Student.class, student.getStuid());
		baseDao.delete(student);
		
		return "tolist";
	}
}
