package com.sp;



//import org.jboss.weld.context.ApplicationContext;
//import org.springframework.beans.factory.BeanFactory;
//import org.springframework.beans.factory.xml.XmlBeanFactory;
//import org.springframework.core.io.ClassPathResource;
//import org.springframework.core.io.Resource;

import javax.xml.crypto.dsig.TransformService;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.HelloAppEvent;
import com.dao.HelloBean;
import com.dao.Party;







public class test {
	
	
      public static void main(String[] args) {
    	  
//    	  Resource resourxe= new ClassPathResource("/applicationContext.xml");
//	         BeanFactory beanFactory   = new XmlBeanFactory(resourxe);
//	         
//	         
//	         HelloBean hello=(HelloBean) beanFactory.getBean("hellobean");
//	         String a=hello.saysp();
//	         System.out.println(a);
	
	         
    	  ApplicationContext appContext = new ClassPathXmlApplicationContext("/applicationContext.xml");
    	  appContext.publishEvent(new HelloAppEvent(TransformService.class));
    	  Party party=(Party) appContext.getBean("party");
	         party.printlnfo();
     }
	     
	         
	         
	         
	         
}
