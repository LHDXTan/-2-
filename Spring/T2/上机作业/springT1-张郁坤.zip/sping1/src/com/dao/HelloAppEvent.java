package com.dao;

import org.springframework.context.ApplicationEvent;

public class HelloAppEvent extends ApplicationEvent {
	public  HelloAppEvent(Object source){
		super(source);
	}

}
