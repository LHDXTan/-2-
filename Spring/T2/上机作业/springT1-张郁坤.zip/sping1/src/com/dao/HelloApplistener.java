package com.dao;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;

public class HelloApplistener implements ApplicationListener {
	
    public void onApplicationEvent(ApplicationEvent event){
    	if (event instanceof HelloAppEvent){//监听自定义事件
    		System.out.println("监听到自定义事件"+event.getSource());
    	}
    	
    } 
	  
}
