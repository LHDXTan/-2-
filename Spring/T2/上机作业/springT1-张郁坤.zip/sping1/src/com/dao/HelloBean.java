package com.dao;

import java.util.Date;

public class HelloBean {

	 private String hello;
	 private Date date;
	
	 
	 public HelloBean(String hello,Date date){
		 this.hello=hello;
		 this.date=date;
		
		 
		 
	 }
	 public String saysp(){
		return hello+"!"+date;
		}


	
	 
}
