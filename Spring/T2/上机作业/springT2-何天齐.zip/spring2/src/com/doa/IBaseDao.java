package com.doa;

import java.io.Serializable;
import java.util.List;

//���巽���ӿ�
public interface IBaseDao {
public  void add(Object obj);
public void update(Object obj);
public void delect(Object obj);
public Object getObjectById(Class clazz,Serializable id);
public List getObjects(String hql);

	
	
}
