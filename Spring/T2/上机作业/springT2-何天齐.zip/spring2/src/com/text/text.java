package com.text;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.doa.IBaseDao;

public class text {
//����
	public static void main(String[] args) {
	ApplicationContext appContext=new ClassPathXmlApplicationContext("applicationContext.xml");
	IBaseDao basedao=(IBaseDao) appContext.getBean("basedao");
	Student stu=new Student();
//	//����
//	stu.setId(2);
	stu.setName("��˹");
	basedao.add(stu);
//	//ѭ�����������
	for(Object o:basedao.getObjects("from Student")){
		System.out.println(o);
	}
	
	
	
	}

}
