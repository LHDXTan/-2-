package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.google.gson.Gson;
import com.opensymphony.xwork2.ActionSupport;

import bean.Emp;
import dao.IEmpDao;

public class EmpAction{
	
	private List list=new ArrayList();
	
	private IEmpDao idao;
	private Emp emp;
	private int eid;
	private String ename;
	private String pwd;
	private String birthday;
	private int did;


	
	
	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public Emp getEmp() {
		return emp;
	}

	public void setEmp(Emp emp) {
		this.emp = emp;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

	public IEmpDao getIdao() {
		return idao;
	}

	public void setIdao(IEmpDao idao) {
		this.idao = idao;
	}
	
	public String add(){
		Emp e=new Emp();
		e.setEname(ename);
		e.setPwd(pwd);
		e.setBirthday(birthday);
		e.setDid(did);
		if(eid!=0){
			e.setEid(eid);
			idao.update(e);
		}else{
			idao.add(e);
		}
		return "list";
		
	}

	
	public String getEmpList(){
		String hql="select e from Emp e";
		list=idao.getObjects(hql);
		Gson gs=new Gson();
		String s=gs.toJson(list);
		HttpServletResponse response=ServletActionContext.getResponse();
		response.setCharacterEncoding("UTF-8");
		try {
			PrintWriter out=response.getWriter();
			out.write(s);
			out.flush();
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return "list";
		
	}
	
	
	public String delete(){
		Emp e=new Emp();
		e.setEid(eid);
		idao.delete(e);
		return birthday;
		
	}
}
