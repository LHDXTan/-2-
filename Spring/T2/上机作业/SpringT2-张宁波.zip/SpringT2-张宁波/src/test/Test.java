package test;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Emp;
import dao.IEmpDao;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext app=new ClassPathXmlApplicationContext("/applicationContext.xml");
		IEmpDao idao=(IEmpDao) app.getBean("idao");
		
		//添加信息
		/*Emp emp=new Emp();
		emp.setEname("jacks");
		emp.setPwd("111");
		emp.setBirthday("2011-01-01");
		emp.setDid(12);
		idao.add(emp);*/
		
		/*//列表查询
		List<Emp> list=new ArrayList<Emp>();
		String hql="select e from Emp e";
		list=idao.getObjects(hql);
		for(int i=0;i<list.size();i++){
			System.out.println(list.get(i).getEname());
		}
		*/
		
		
		/*//删除用户
		Emp emp=new Emp();
		emp.setEid(1);
		idao.delete(emp);
		*/
		
		//修改信息
		
		Emp emp=new Emp();
		emp.setEid(2);
		emp.setEname("marks");
		emp.setPwd("12121");
		emp.setBirthday("2013-02-04");
		emp.setDid(2);
		idao.update(emp);

	}

}
