package Action;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.env.PropertySource.StubPropertySource;

import BaseDao.IBaseDao;
import bean.Student;

import com.opensymphony.xwork2.Action;

public class StudentAction implements Action {
	
	private Student stu;
	private List<Student> stulist;
	
	ClassPathXmlApplicationContext app = new  ClassPathXmlApplicationContext("/applicationContext.xml");
    private IBaseDao base = (IBaseDao) app.getBean("basedao");
    
	
	/************************ִ�з���*****************************/
	//��ѯѧ��������Ϣ
	public String list(){
		System.out.println("��ѯ��Ϣ");
		stulist = base.getObjects("from Student");
		
		for(int i=0;i<stulist.size();i++){
		Student s=	stulist.get(i);
			System.out.println(s.getSname());
			
		}
		return "list";
		}
	
	//����ѧ����Ϣ
	public String add(){
		System.out.println("������Ϣ");
		base.add(stu);
		return "tolist";
		}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
    
	
	/************************get set����*****************************/
	public Student getStu() {
		return stu;
	}

	public void setStu(Student stu) {
		this.stu = stu;
	}

	public List getStulist() {
		return stulist;
	}

	public void setStulist(List stulist) {
		this.stulist = stulist;
	}

	public IBaseDao getBase() {
		return base;
	}

	public void setBase(IBaseDao base) {
		this.base = base;
	}
	
	

}
