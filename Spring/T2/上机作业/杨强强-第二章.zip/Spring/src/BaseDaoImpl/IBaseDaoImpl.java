package BaseDaoImpl;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import BaseDao.IBaseDao;

public class IBaseDaoImpl extends HibernateDaoSupport implements IBaseDao{

	@Override
	public void add(Object odj) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().save(odj);
	}

	@Override
	public void updatde(Object odj) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().update(odj);
	}

	@Override
	public void delete(Object odj) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().delete(odj);
	}

	@Override
	public Object getObjectByld(Class clazz, Serializable id) {
		// TODO Auto-generated method stub
		return super.getHibernateTemplate().get(clazz, id);
	}

	@Override
	public List getObjects(String hql) {
		// TODO Auto-generated method stub
		String sql="select s from Student s";
		return super.getHibernateTemplate().find(sql);
	}

}
