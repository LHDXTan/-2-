package bean;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import BaseDao.IBaseDao;

public class cs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        ClassPathXmlApplicationContext app = new  ClassPathXmlApplicationContext("/applicationContext.xml");
        IBaseDao base = (IBaseDao) app.getBean("basedao");
        for(Object o:base.getObjects("from Student")){
        	System.out.println(o);
        }
	}

}
