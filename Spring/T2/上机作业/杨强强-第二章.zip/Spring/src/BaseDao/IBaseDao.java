package BaseDao;

import java.io.Serializable;
import java.util.List;

public interface IBaseDao {
    public void add(Object odj);
    public void updatde(Object odj);
    public void delete(Object odj);
    
    public Object getObjectByld(Class clazz,Serializable id);
    public List getObjects(String hql);
}
