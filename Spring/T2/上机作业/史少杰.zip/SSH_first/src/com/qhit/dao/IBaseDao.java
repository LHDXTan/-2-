package com.qhit.dao;

import java.util.List;


public interface IBaseDao {
	public List getStudent();
}
