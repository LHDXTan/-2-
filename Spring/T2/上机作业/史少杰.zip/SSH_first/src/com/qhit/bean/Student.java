package com.qhit.bean;

public class Student {
	private String sno;
	private String sname;
	private Byte sage;
	private String ssex;
	public String getSno() {
		return sno;
	}
	public void setSno(String sno) {
		this.sno = sno;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public Byte getSage() {
		return sage;
	}
	public void setSage(Byte sage) {
		this.sage = sage;
	}
	public String getSsex() {
		return ssex;
	}
	public void setSsex(String ssex) {
		this.ssex = ssex;
	}
	

}
