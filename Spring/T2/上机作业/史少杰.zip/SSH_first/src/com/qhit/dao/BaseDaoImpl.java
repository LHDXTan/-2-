package com.qhit.dao;

import java.util.List;





import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.qhit.bean.Student;
public class BaseDaoImpl extends HibernateDaoSupport implements IBaseDao {

	@Override
	public List getStudent() {
		String hql = "from Student";
		return super.getHibernateTemplate().find(hql);
	}
	
	public static void main(String[] args) {
		ApplicationContext applica = new ClassPathXmlApplicationContext("/applicationContext.xml");
		IBaseDao b = (IBaseDao) applica.getBean("basedao");
		System.out.println(b.getStudent().size());
	}

}
