package com.qhit.action;

import java.util.List;

import com.opensymphony.xwork2.ActionSupport;
import com.qhit.bean.Student;
import com.qhit.dao.BaseDaoImpl;
import com.qhit.dao.IBaseDao;

public class BaseAction extends ActionSupport{
	private IBaseDao basedao;
	private List<Student> liststudent;
	
	
	public String getlist(){
		System.out.println(basedao.getStudent().size());
		return "ss";
	}
	public String sss(){
		return "ss";
	}
	
	public IBaseDao getBasedao() {
		return basedao;
	}
	public void setBasedao(IBaseDao basedao) {
		this.basedao = basedao;
	}
	public List<Student> getListstudent() {
		return liststudent;
	}
	public void setListstudent(List<Student> liststudent) {
		this.liststudent = liststudent;
	}
	
}
