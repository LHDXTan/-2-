package com.spr.dao;

import java.io.Serializable;
import java.util.List;

public interface Userdao {
	public void add(Object obj);
	public void update(Object obj);
	public void del(Object obj);
	public Object getObjectById(Class clazz,Serializable id);
	public List getObject(String hql);

}
