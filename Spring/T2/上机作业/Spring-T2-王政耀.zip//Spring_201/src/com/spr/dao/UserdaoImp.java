package com.spr.dao;

import java.io.Serializable;
import java.util.List;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class UserdaoImp extends HibernateDaoSupport implements Userdao {

	public void add(Object obj) {
		  super.getHibernateTemplate().save(obj);
	}

	public void update(Object obj) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().update(obj);
	
		 
	}

	public void del(Object obj) {
		// TODO Auto-generated method stub
		 super.getHibernateTemplate().delete(obj);
	
	}

	public Object getObjectById(Class clazz, Serializable id) {
		// TODO Auto-generated method stub
		return  super.getHibernateTemplate().get(clazz, id);
	}

	public List getObject(String hql) {
		// TODO Auto-generated method stub
		return super.getHibernateTemplate().find(hql);
	}

}
