package com.spr.action;

import java.io.Serializable;
import java.util.List;

import com.opensymphony.xwork2.ActionSupport;
import com.spr.dao.Userdao;
import com.spr.vo.Usermassage;

public class UserAction extends ActionSupport{
	
	private Usermassage user;
	private List userlist;
	private Userdao ud;
	

	//����
	public String userAdd(){
		System.out.println("�������ӷ���");
		ud.add(user);
		return "tolist";
	}
	//�����޸�
	public String touserupd(){
		System.out.println("UserAction.touserupd()");
		user=(Usermassage) ud.getObjectById( Usermassage.class,user.getId());
		return "toupd";
	}
	//�޸�
	public String userupd(){
		System.out.println("�޸ķ���");
		ud.update(user);
		return "tolist";
	}
	//ɾ��
	public String userdel(){
		System.out.println("����ɾ������");
		user=(Usermassage) ud.getObjectById( Usermassage.class,user.getId());
		ud.del(user);
		return "tolist";
	}
	//��ѯ
	public String usersel(){
		System.out.println("�����ѯ����");
		userlist= ud.getObject("from Usermassage");
		return "list";
	}
	

	
	public Usermassage getUser() {
		return user;
	}
	public void setUser(Usermassage user) {
		this.user = user;
	}
	public List getUserlist() {
		return userlist;
	}
	public void setUserlist(List userlist) {
		this.userlist = userlist;
	}
	public Userdao getUd() {
		return ud;
	}
	public void setUd(Userdao ud) {
		this.ud = ud;
	}

}
