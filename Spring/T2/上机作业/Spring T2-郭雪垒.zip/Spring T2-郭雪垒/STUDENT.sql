/*
Navicat Oracle Data Transfer
Oracle Client Version : 11.2.0.1.0

Source Server         : Oracle
Source Server Version : 110200
Source Host           : localhost:1521
Source Schema         : SCOTT

Target Server Type    : ORACLE
Target Server Version : 110200
File Encoding         : 65001

Date: 2018-04-10 17:52:02
*/


-- ----------------------------
-- Table structure for STUDENT
-- ----------------------------
DROP TABLE "SCOTT"."STUDENT";
CREATE TABLE "SCOTT"."STUDENT" (
"SID" NUMBER NOT NULL ,
"SNO" VARCHAR2(50 BYTE) NULL ,
"SNAME" VARCHAR2(50 BYTE) NULL ,
"SSEX" VARCHAR2(50 BYTE) NULL ,
"SAGE" NUMBER NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Indexes structure for table STUDENT
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table STUDENT
-- ----------------------------
ALTER TABLE "SCOTT"."STUDENT" ADD PRIMARY KEY ("SID");
