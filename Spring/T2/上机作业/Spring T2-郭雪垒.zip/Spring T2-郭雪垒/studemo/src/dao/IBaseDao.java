package dao;

import java.io.Serializable;
import java.util.List;

public interface IBaseDao {
	
	public void add(Object object);
	public void update(Object object);
	public void delete(Object object);
	
	public Object getObjectById(Class clazz,Serializable id);
	public List getObjects(String hql);

}
