package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Student;

import dao.IBaseDao;

public class demotest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext appContext = new ClassPathXmlApplicationContext("/applicationContext.xml");
		IBaseDao basedao=(IBaseDao) appContext.getBean("basedao");
		
		Student stu=new Student();
		stu.setStuname("����");
		stu.setStusex("M");
		stu.setStuage(new Integer(20));
		
		basedao.add(stu);
		
		for(Object o:basedao.getObjects("from Student")){
			System.out.println(o);
		}

	}

}
