package com.dao;

import java.io.Serializable;
import java.util.List;

public interface BaseDao {
	//添加
	public void add(Object obj);
	//修改
	public void update(Object obj);
	//删除
	public void delete(Object obj);
	
	public Object  getObjectById(Class  clazz, Serializable  id);
	
	public List getObjects(String hql);
//	public List getObjectSQL(String sql);
	public int createSQL(String hql);
}
