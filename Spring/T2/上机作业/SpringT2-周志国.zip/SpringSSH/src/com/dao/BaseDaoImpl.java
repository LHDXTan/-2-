package com.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class BaseDaoImpl extends HibernateDaoSupport implements BaseDao {

	@Override
	public void add(Object obj) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().save(obj);
	}

	@Override
	public void update(Object obj) {
		// TODO Auto-generated method stub
        super.getHibernateTemplate().update(obj);
	}

	@Override
	public void delete(Object obj) {
		// TODO Auto-generated method stub
        super.getHibernateTemplate().delete(obj);
	}

	@Override
	public Object getObjectById(Class clazz, Serializable id) {
		// TODO Auto-generated method stub
		return super.getHibernateTemplate().get(clazz, id);
	}

	@Override
	public List getObjects(String hql) {
		// TODO Auto-generated method stub
		return super.getHibernateTemplate().find(hql);
	}
	
//	@Override
//	public List getObjectSQL(String sql) {
//		// TODO Auto-generated method stub
//		return super.getHibernateTemplate().get;
//	}
	
	//执行Sql语句
	public int createSQL(String hql) {
		Session  session = super.getSession();
		Transaction tx = session.beginTransaction();
		int  i=0;
		try{
		    i=session.createSQLQuery(hql).executeUpdate();
			tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		
		session.clear();
		
		return i;
	}

}
