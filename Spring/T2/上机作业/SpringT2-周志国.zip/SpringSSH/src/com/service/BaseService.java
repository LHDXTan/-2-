package com.service;

public interface BaseService {

}
