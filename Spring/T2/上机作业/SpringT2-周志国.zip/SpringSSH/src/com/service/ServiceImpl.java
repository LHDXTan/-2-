package com.service;

public class ServiceImpl implements BaseService {

}
