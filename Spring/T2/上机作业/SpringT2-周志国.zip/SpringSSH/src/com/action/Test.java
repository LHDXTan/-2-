package com.action;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.BaseDaoImpl;
import com.vo.Dept;


public class Test {
   
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext app=new ClassPathXmlApplicationContext("applicationContext.xml");
		BaseDaoImpl base=(BaseDaoImpl)app.getBean("basedao");
		Dept d=(Dept) base.getObjectById(Dept.class, 2);
//		for(Dept d:list){
			System.out.println(d.getDname());
//		}
	}
	

}
