package com.action;

import java.util.List;
import com.dao.BaseDao;
import com.opensymphony.xwork2.ActionSupport;
import com.vo.Dept;

public class TestSpring extends ActionSupport{
    private BaseDao basedao;
    private Dept dept;
    public String add(){
		System.out.println("TestSpring.add()");
		Dept dept=new Dept();
//		String hql="From DEPT t Where Rownum=1 Order By t.DID DESC";
//		List<Dept> list=basedao.getObjects(hql);
//		for(Dept d:list){
//			dept.setDid(d.getDid()+1);
//		}
//		dept.setDname("勇士部");
//		dept.setManager(6);
//		dept.setTel("1231654");
//		dept.setMaster(3);
		String hql="Insert Into Dept(Did,Dname,Manager,Tel,Master)VALUES(SEQ_T1.nextval,'woshishui',8,'164544566',2)";
        int i=basedao.createSQL(hql);
        System.out.println(i);
		return null;
	}
	public String update(){
		Dept dept1=new Dept();
		dept1=(Dept) basedao.getObjectById(Dept.class, 1);
		dept1.setDname("天下部");
		basedao.update(dept1);
		return null;
		}
	public String delete(){
		Dept dept1=new Dept();
		dept1=(Dept) basedao.getObjectById(Dept.class, 1);
		basedao.delete(dept1);
		return null;
	}
	public String all(){
//		ApplicationContext app=new ClassPathXmlApplicationContext("applicationContext.xml");
//		BaseDaoImpl base=(BaseDaoImpl)app.getBean("basedao");
		List<Dept> list=basedao.getObjects("from Dept");
		for(Dept d:list){
			System.out.println(d.getDid()+"\t"+d.getDname()+"\t"+d.getManager()+"\t"+d.getTel()+"\t"+d.getMaster());
		}
		return null;
	}

	public Dept getDept() {
		return dept;
	}
	public void setDept(Dept dept) {
		this.dept = dept;
	}
	public BaseDao getBasedao() {
		return basedao;
	}
	public void setBasedao(BaseDao basedao) {
		this.basedao = basedao;
	}
	

}
