package com.test.action;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.test.dao.BaseDao;
import com.test.pojo.Student;

public class test {
	public static void main(String[] args) {
		 ApplicationContext ss= new ClassPathXmlApplicationContext("applicationContext.xml");
		BaseDao dao = (BaseDao)ss.getBean("BaseDao");
		

		
		for(Object o:dao.getObjects("from Student")){
			System.out.println(o);
		}
		
		}
}
