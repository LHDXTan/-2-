package com.test.action;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.opensymphony.xwork2.Action;
import com.test.dao.BaseDao;
import com.test.pojo.Student;


public class action implements Action {
private Student stu;
 private List stulist;
 private BaseDao basedao;
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String cx(){
		//������ѯȫ������
		System.out.println("������ѯȫ��");
		stulist=basedao.getObjects("from Student");
		return "cx";
		
		
	}

public String tj(){
	basedao.add(stu);
	return "tj";
	
	
}
public String toxg(){
	
	stu=(Student) basedao.getObjectByid(Student.class,stu.getId() );
	return "toxg";
	
	
}
public String xg(){
	System.out.println("�����޸�");
	Student l=(Student) basedao.getObjectByid(Student.class,stu.getId() );
     l.setId(stu.getId());
     l.setName(stu.getName());
     l.setSex(stu.getSex());
     l.setAge(stu.getAge());
     basedao.update(l);
	return "xg";
	
	
}
public String sc(){
	System.out.println("jin��ɾ��");
	  Student t=(Student) basedao.getObjectByid(Student.class, stu.getId());
	basedao.delete(t);
	return "tj";
	
}

	public List getStulist() {
		return stulist;
	}

	public void setStulist(List stulist) {
		this.stulist = stulist;
	}

	public BaseDao getBasedao() {
		return basedao;
	}

	public void setBasedao(BaseDao basedao) {
		this.basedao = basedao;
	}

	public Student getStu() {
		return stu;
	}

	public void setStu(Student stu) {
		this.stu = stu;
	}




	
}
