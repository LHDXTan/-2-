package com.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.dao.IBaseDao;
import com.google.gson.Gson;
import com.opensymphony.xwork2.Action;
import com.pojo.Student;

public class UserAction implements Action {
	private Student stu;
	private int sid;
	private String sname;
	private List list;
	private IBaseDao basedao;
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpServletResponse response = ServletActionContext.getResponse();
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String delUser(){
		PrintWriter out = null;
		response.setContentType("text;charset=UTF-8");
		try {		
			stu = (Student)basedao.getObjectById(Student.class, sid);
			basedao.delete(stu);
			out = response.getWriter();
			out.print(1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			out.close();
		}
		return null;
	}
	
	public String updUser(){
		PrintWriter out = null;
		response.setContentType("text;charset=UTF-8");
		try {		
			stu = (Student)basedao.getObjectById(Student.class, sid);
			stu.setSid(sid);
			stu.setSname(sname);
			basedao.update(stu);
			out = response.getWriter();
			out.print(1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			out.close();
		}
		return null;
	}
	
	public String addUser(){
		PrintWriter out = null;
		response.setContentType("text;charset=UTF-8");
		try {		
			stu = new Student();
			stu.setSid(sid);
			stu.setSname(sname);
			int flag = basedao.add(stu);
			out = response.getWriter();
			out.print(flag);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			out.close();
		}
		return null;
	}
	
	public String selUsers(){
		PrintWriter out = null;
		try {
			response.setContentType("text;charset=UTF-8");
			out = response.getWriter();
			list = basedao.getObject("from Student");
			out.print(new Gson().toJson(list));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			out.close();
		}
		
		return null;
	}

	public Student getStu() {
		return stu;
	}

	public void setStu(Student stu) {
		this.stu = stu;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}





	public IBaseDao getBasedao() {
		return basedao;
	}

	public void setBasedao(IBaseDao basedao) {
		this.basedao = basedao;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}
	
	

}
