package com.dao;

import java.io.Serializable;
import java.util.List;

public interface IBaseDao {
	
	public int add(Object obj);
	
	public void delete(Object obj);
	
	public Object getObjectById(Class clazz,Serializable id);
	
	public List getObject(String hql);
	
	public void update(Object obj);

}
