package com.qhit.action;



import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.qhit.dao.IBaseDao;
import com.qhit.pojo.Student;

public class StuAction {
     
	private Student student;
	private List stulist;
	
	
	ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");//读取xml中的内容
    IBaseDao basedao = (IBaseDao) ctx.getBean("basedao");//创建bean的引用对象
	
	public String list(){
		
		stulist=basedao.getObjects("from Student");
		return "list";
	}
	
	public String li(){
		student = (Student) basedao.getObjectById(Student.class, 1);
		return "li";
		
	}
	
	public String add(){
		basedao.add(student);
		return "tolist";
		
	}

	
	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public IBaseDao getBasedao() {
		return basedao;
	}

	public void setBasedao(IBaseDao basedao) {
		this.basedao = basedao;
	}

	public List getStulist() {
		return stulist;
	}

	public void setStulist(List stulist) {
		this.stulist = stulist;
	}

	


	
}
