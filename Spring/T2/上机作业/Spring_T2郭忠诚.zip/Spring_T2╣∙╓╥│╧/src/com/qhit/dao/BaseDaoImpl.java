package com.qhit.dao;
import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;


public class BaseDaoImpl extends HibernateDaoSupport implements IBaseDao{
	public void add(Object obj){
		super.getHibernateTemplate().save(obj);
	}
	
	public void delete(Object obj){
		super.getHibernateTemplate().delete(obj);;
	}
	
	public Object getObjectById(Class clazz,Serializable id){
		return super.getHibernateTemplate().get(clazz, id);
	}
	
	public List getObjects(String hql){
		return super.getHibernateTemplate().find(hql);
	}
	
	public void update(Object obj){
		super.getHibernateTemplate().update(obj);
	}
	

}
