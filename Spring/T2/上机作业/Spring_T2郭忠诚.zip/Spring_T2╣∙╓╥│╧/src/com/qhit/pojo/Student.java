package com.qhit.pojo;

/**
 * Student entity. @author MyEclipse Persistence Tools
 */

public class Student implements java.io.Serializable {

	// Fields

	private Integer studi;
	private String stuname;
	private String stusex;
	private Integer stuage;

	// Constructors

	/** default constructor */
	public Student() {
	}

	/** full constructor */
	public Student(String stuname, String stusex, Integer stuage) {
		this.stuname = stuname;
		this.stusex = stusex;
		this.stuage = stuage;
	}

	// Property accessors

	public Integer getStudi() {
		return this.studi;
	}

	public void setStudi(Integer studi) {
		this.studi = studi;
	}

	public String getStuname() {
		return this.stuname;
	}

	public void setStuname(String stuname) {
		this.stuname = stuname;
	}

	public String getStusex() {
		return this.stusex;
	}

	public void setStusex(String stusex) {
		this.stusex = stusex;
	}

	public Integer getStuage() {
		return this.stuage;
	}

	public void setStuage(Integer stuage) {
		this.stuage = stuage;
	}

}