package com.qhit.action;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.qhit.dao.IBaseDao;
import com.qhit.pojo.Student;

public class Test {

	public static void main(String[] args) {
		
		ApplicationContext appContext=new ClassPathXmlApplicationContext();
	    IBaseDao baseDao=(IBaseDao) appContext.getBean("basedao");
	    
	    Student stu=new Student();
	    stu.setStuname("张三");
	    stu.setStusex("M");
	    stu.setStuage(new Integer(20));
	    
	    baseDao.add(stu);
	    
	    for(Object o:baseDao.getObjects("from Student")){
	    	System.out.println(o);
	    }
	}

}
