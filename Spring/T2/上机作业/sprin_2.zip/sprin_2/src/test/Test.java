package test;




import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Student;

import dao.IDaoStudent;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext application=new ClassPathXmlApplicationContext("/applicationContext.xml");
		IDaoStudent id=(IDaoStudent) application.getBean("dao");
        for(Object o:id.listStudnet("from Student")){
        	Student student=(Student)o;
        	System.out.println(student.getSname());
        }
	}

}
