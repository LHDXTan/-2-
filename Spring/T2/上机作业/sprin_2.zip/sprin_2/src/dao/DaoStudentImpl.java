package dao;


import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import bean.Student;

public class DaoStudentImpl extends HibernateDaoSupport implements IDaoStudent {

	@Override
	public List listStudnet(String hql) {
		
		return super.getHibernateTemplate().find(hql);
	}

	@Override
	public void addStudent(Student stu) {
		
		super.getHibernateTemplate().save(stu);
	}

	@Override
	public void deleteStudent(Student stu) {
		
		super.getHibernateTemplate().delete(stu);
	}

	@Override
	public Object getStudentId(Class clazz, Serializable id) {
		
		return super.getHibernateTemplate().get(Student.class, id);
	}

	@Override
	public void updateStudent(Student stu) {
		
		super.getHibernateTemplate().update(stu);
	}

}
