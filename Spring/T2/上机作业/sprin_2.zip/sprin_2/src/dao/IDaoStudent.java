package dao;

import java.io.Serializable;
import java.util.List;

import bean.Student;

public interface IDaoStudent {
	
	public List listStudnet(String hql);
	
	public void addStudent(Student stu);
	
	public void deleteStudent(Student stu);
	
	public Object getStudentId(Class clazz,Serializable id);
	
	public void updateStudent(Student stu);
}
