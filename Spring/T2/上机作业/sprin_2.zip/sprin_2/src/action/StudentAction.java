package action;

import java.util.List;

import bean.Student;

import com.opensymphony.xwork2.ActionSupport;

import dao.IDaoStudent;

public class StudentAction extends ActionSupport {

	private Student stu;
	private List<Student> stulist;
	private IDaoStudent dao;
	
	public Student getStu() {
		return stu;
	}
	public void setStu(Student stu) {
		this.stu = stu;
	}
    public List<Student> getStulist() {
		return stulist;
	}
	public void setStulist(List<Student> stulist) {
		this.stulist = stulist;
	}
	public IDaoStudent getDao() {
		return dao;
	}
	public void setDao(IDaoStudent dao) {
		this.dao = dao;
	}
	public String listStudent(){
    	
    	stulist=dao.listStudnet("from Student");
    	return "list";
    }
	
	public String addStudent(){
		
		dao.addStudent(stu);
		return "tolist";
	}
	
	
	public String toupdateStudent(){
		
		stu=(Student)dao.getStudentId(Student.class, stu.getSno());
	    return "toupdate";	
	}
	
	public String updateStudent(){
		Student	stu1=(Student)dao.getStudentId(Student.class, stu.getSno());
	    stu1.setSname(stu.getSname());
	    stu1.setSage(stu.getSage());
	    stu1.setSsex(stu.getSsex());
	    dao.updateStudent(stu1);
		return "tolist";
	}
	
	public String deleteStudent(){
		
		dao.deleteStudent(stu);
		return "tolist";
	}
}
