package com.spring.basedao;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class BaseDaoImp extends HibernateDaoSupport implements IBaseDao {

	@Override
	public void add(Object obj) {
     super.getHibernateTemplate().save(obj);
		
	}

	@Override
	public void update(Object obj) {
	 super.getHibernateTemplate().update(obj);	
		
	}

	@Override
	public void delete(Object obj) {
	 super.getHibernateTemplate().delete(obj);
		
	}

	@Override
	public Object getObjectById(Class clazz, Serializable id) {
	 super.getHibernateTemplate().get(clazz, id);	
		return null;
	}

	@Override
	public List getObjects(String hql) {
	 super.getHibernateTemplate().find(hql);
		return null;
	}

		
		
		
		
		
}
