package com.spring.beans;

import java.math.BigDecimal;

/**
 * Depts entity. @author MyEclipse Persistence Tools
 */

public class Depts implements java.io.Serializable {

	// Fields

	private BigDecimal did;
	private String dname;
	private String tel;
	private String ress;

	// Constructors

	/** default constructor */
	public Depts() {
	}

	/** minimal constructor */
	public Depts(BigDecimal did) {
		this.did = did;
	}

	/** full constructor */
	public Depts(BigDecimal did, String dname, String tel, String ress) {
		this.did = did;
		this.dname = dname;
		this.tel = tel;
		this.ress = ress;
	}

	// Property accessors

	public BigDecimal getDid() {
		return this.did;
	}

	public void setDid(BigDecimal did) {
		this.did = did;
	}

	public String getDname() {
		return this.dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getTel() {
		return this.tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getRess() {
		return this.ress;
	}

	public void setRess(String ress) {
		this.ress = ress;
	}

}