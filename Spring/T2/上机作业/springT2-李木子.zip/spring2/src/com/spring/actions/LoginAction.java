package com.spring.actions;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.basedao.BaseDaoImp;
import com.spring.basedao.IBaseDao;
import com.spring.beans.Depts;

public class LoginAction {
    private BaseDaoImp bd;
    private Depts depts;
	private List list;
	
	ApplicationContext appContext =new ClassPathXmlApplicationContext("/applicationContext.xml");
	IBaseDao basedao=(IBaseDao)appContext.getBean("basedao");
	
	 public String select(){
	  String hql="select depts from Depts depts";
	  list= bd.getObjects(hql);
		 
		 
		 return "index";
		 
	 }

	public Depts getDepts() {
		return depts;
	}

	public void setDepts(Depts depts) {
		this.depts = depts;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}
	 
	 
}
