package controller;


import org.springframework.context.ApplicationEvent;

public class jiantingqi extends ApplicationEvent {

	public jiantingqi(Object source) {
		super(source);
		
	}
           
}
