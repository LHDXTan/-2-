package controller;

import java.util.Date;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import fz.juese;
import fz.jvhui;

public class a {
     public static void main(String[] args) {
		
    	 
    	 ClassPathXmlApplicationContext app= new ClassPathXmlApplicationContext("applicationContext.xml");
	        Date bean =(Date) app.getBean("jvhui_time");
	        app.publishEvent(new jiantingqi(a.class));
     }
}
