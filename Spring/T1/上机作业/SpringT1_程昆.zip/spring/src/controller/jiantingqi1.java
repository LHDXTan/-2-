package controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import fz.jvhui;

public class jiantingqi1 implements ApplicationListener{

	@Override
	public void onApplicationEvent(ApplicationEvent arg0) {
		if(arg0 instanceof ContextRefreshedEvent){
			ContextRefreshedEvent cse= (ContextRefreshedEvent) arg0;
			ApplicationContext app = cse.getApplicationContext();
			System.out.println("������");
			jvhui bean2 =(jvhui) app.getBean("l");
			if(bean2!=null){
				 bean2.printIfo();
			}
	       
		}
	}

}
