package fz;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class jvhui {
    private Date time;
    private String didian;
    private List jh;
    
    public List getJh() {
		return jh;
	}
	public void setJh(List jh) {
		this.jh = jh;
	}
	
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public String getDidian() {
		return didian;
	}
	public void setDidian(String didian) {
		this.didian = didian;
	}
	
	public void printIfo() {
	      Date bean = new Date();
	      SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	      String dateString = formatter.format(bean);
		if(jh!=null){
			System.out.println("\t"+"��������:"+jh.size()+"\n"+"ʱ�䣺"+dateString);
			for(Object o:jh){
				System.out.println("\t"+o);
			}
		}else {
			System.out.println("\t"+bean+"��������:���ޣ�");
		}
	}
    
}
