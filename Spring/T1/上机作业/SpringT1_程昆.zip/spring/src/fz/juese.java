package fz;

public class juese {
    private String name;
    private String sex;
    private String dianhua;
    
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getDianhua() {
		return dianhua;
	}
	public void setDianhua(String dianhua) {
		this.dianhua = dianhua;
	}
	public String  toString() {
		return "����:"+name+",�Ա�:"+sex+",�绰��"+dianhua;
	}
}
