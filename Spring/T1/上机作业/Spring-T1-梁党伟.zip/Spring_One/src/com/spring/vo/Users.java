package com.spring.vo;

import java.util.Date;

public class Users {

	private String name;
	private Date date;
	

	public String sayhello(){
		return name+"-------"+date;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	 
	 
}
