package com.spring.tests;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.spring.vo.HelloAppEvent;
import com.spring.vo.Jihelx;
import com.spring.vo.Party;
import com.spring.vo.Users;

public class Test {
	public static void main(String[] args) {
//		Resource res =new ClassPathResource("/applicationContext.xml");
//		
//		BeanFactory factory=new XmlBeanFactory(res);
//		
////		Users aa =(Users) factory.getBean("users");
////		
////		System.out.println(aa.sayhello());
//		
//		Jihelx jh = (Jihelx)factory.getBean("jihelx");
//		jh.printInfo();
		
		ApplicationContext appct = new ClassPathXmlApplicationContext("/applicationContext.xml");
//		Party party=(Party) appct.getBean("party");
//		party.printInfo();
		appct.publishEvent(new HelloAppEvent(Party.class));
	}

}
