package com.test.bean;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Jhdd {
	private String topic;//主题
	private String sj;//时间
	private List members;//参与人数
	
	public Jhdd(String topic,Date sj){
		SimpleDateFormat ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		this.topic=topic;
		this.sj= ss.format(sj.getTime());
       
       
	}
	public void j1(){
		if(members!=null){
			System.out.println(topic+",参与人数："+members.size()+",时间:"+sj);
			for(Object o:members){
				System.out.println("\t"+o);
			}
		}else{
			System.out.println(topic+",参与人数：暂无"+",时间:"+sj);
		}
	}

	public List getMembers() {
		return members;
	}

	public void setMembers(List members) {
		this.members = members;
	}
	
}
