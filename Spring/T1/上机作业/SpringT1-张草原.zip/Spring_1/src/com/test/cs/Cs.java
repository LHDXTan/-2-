package com.test.cs;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Cs {
	public static void main(String[] args) {
		ApplicationContext ss=new ClassPathXmlApplicationContext("applicationContext.xml");
		ss.publishEvent(new Shij(Cs.class));
	}
}
