package com.test.bean;

public class XiaoYou {
	private String uname;//姓名
	private String usex;//性别
	private String uphone;//电话
	
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUsex() {
		return usex;
	}
	public void setUsex(String usex) {
		this.usex = usex;
	}
	public String getUphone() {
		return uphone;
	}
	public void setUphone(String uphone) {
		this.uphone = uphone;
	}
	
	public String toString(){
		return "姓名:"+uname+",性别:"+usex+",电话:"+uphone;
	}
}
