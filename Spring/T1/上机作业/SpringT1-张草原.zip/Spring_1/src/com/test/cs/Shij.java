package com.test.cs;

import org.springframework.context.ApplicationEvent;

public class Shij extends ApplicationEvent {

	public Shij(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
