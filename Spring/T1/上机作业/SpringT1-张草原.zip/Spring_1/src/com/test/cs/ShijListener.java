package com.test.cs;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import com.test.bean.Jhdd;

public class ShijListener implements ApplicationListener {

	@Override
	public void onApplicationEvent(ApplicationEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0 instanceof ContextRefreshedEvent){
			ContextRefreshedEvent cse=(ContextRefreshedEvent) arg0;
			ApplicationContext app=cse.getApplicationContext();
			System.out.println("监听器");
			Jhdd bean = (Jhdd) app.getBean("jh");
			if(bean!=null){
				bean.j1();
			}
		}
	}

}
