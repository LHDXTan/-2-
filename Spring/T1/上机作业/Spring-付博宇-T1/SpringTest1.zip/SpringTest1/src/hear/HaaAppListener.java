package hear;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;

public class HaaAppListener implements ApplicationListener<ApplicationEvent> {

	@Override
	public void onApplicationEvent(ApplicationEvent arg0) {
		
		if(arg0 instanceof HaaAppEvent){
			System.out.println("haaa!��������"+arg0.getSource());
		}
	}

}
