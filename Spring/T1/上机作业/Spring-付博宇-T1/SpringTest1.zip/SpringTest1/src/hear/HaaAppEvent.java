package hear;

import org.springframework.context.ApplicationEvent;

public class HaaAppEvent extends ApplicationEvent {

	public HaaAppEvent(Object source) {
		super(source);
	}

}
