package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Party;
import hear.HaaAppEvent;

public abstract class test implements ApplicationContext {

	public static void main(String[] args) {
        ApplicationContext appContext=new ClassPathXmlApplicationContext("/applicationContext.xml");
        appContext.publishEvent(new HaaAppEvent("aaaaaaaaaa"));
        Party party = (Party)appContext.getBean("party");
        party.printInfo();
	}

}
