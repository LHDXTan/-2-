package com.qhit.Bean;

import java.util.List;

public class StudentBean {

	private String name;
	private String sex;
	private String photo;
	
	private List list;
	
	public StudentBean(String name,String sex,String photo){
		this.name=name;
		this.sex=sex;
		this.photo=photo;
		
	}
	
	public void info(){
	 System.out.println("姓名:"+name+",性别:"+sex+",联系方式:"+photo);
	}
	public void info2(){
	for(Object o:list){
		 System.out.println(o);
		}
	} 

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

}
