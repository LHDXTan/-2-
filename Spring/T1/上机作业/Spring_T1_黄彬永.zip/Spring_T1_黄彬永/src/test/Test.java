package test;

import listener.PartyEvent;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Party;

public class Test {

	public static void main(String[] args) {

		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("/applicationContext.xml");
		applicationContext.publishEvent(new PartyEvent(applicationContext));
		Party party =(Party) applicationContext.getBean("party");
		party.printInfo();
	}

}
