package listener;

import org.springframework.context.ApplicationEvent;

public class PartyEvent extends ApplicationEvent{

	public PartyEvent(Object source) {
		super(source);
	}

	
}
