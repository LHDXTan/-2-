package listener;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;

public class PartyListener implements ApplicationListener{

	@Override
	public void onApplicationEvent(ApplicationEvent event) {

		if(event instanceof PartyEvent){
			System.out.println("监听到自定义事件："+event.getSource());
		}
	}

	
}
