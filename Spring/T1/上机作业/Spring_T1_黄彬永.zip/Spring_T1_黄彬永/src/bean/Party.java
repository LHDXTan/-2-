package bean;

import java.util.List;

public class Party {
	
	private String topic;
	private List member;
	
	public Party(String topic) {
		this.topic = topic;
	}

	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}

	public List getMember() {
		return member;
	}
	public void setMember(List member) {
		this.member = member;
	}
	
	public void printInfo(){
		if(member!=null){
			System.out.println(topic+"\t"+"参与人数："+member.size());
			for(Object o : member){
				System.out.println("\t"+o);
			}
		}else{
			System.out.println(topic+"参与人数：暂无");
		}
	}
}
