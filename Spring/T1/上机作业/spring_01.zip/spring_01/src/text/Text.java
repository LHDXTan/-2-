package text;

import java.util.Date;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;


import bean.HelloSpring;
import bean.HelloSpring2;
import bean.HelloSpring3;
import bean.Party;

public class Text {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 
      ApplicationContext application=new ClassPathXmlApplicationContext("/applicationContext.xml");
      Date now=(Date)application.getBean("now");
      System.out.println(now);
      
//      Resource resource=new ClassPathResource("/applicationContext.xml");
//      BeanFactory bean=new XmlBeanFactory(resource);
      HelloSpring hello=(HelloSpring)application.getBean("hello");
      System.out.println(hello.sayhello());
      
      HelloSpring2 hello2=(HelloSpring2)application.getBean("helloBean2");
      System.out.println(hello2.sayHello());
      
      
      HelloSpring3 hello3=(HelloSpring3)application.getBean("helloBean3");
      hello3.printlnfo();
      
      Party party=(Party)application.getBean("party");
      party.printlnfo();
	}

}
