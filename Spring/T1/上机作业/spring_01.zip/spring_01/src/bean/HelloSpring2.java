package bean;

import java.util.Date;

public class HelloSpring2 {

	
	private String hello;
	private Date date;
	public String getHello() {
		return hello;
	}
	public void setHello(String hello) {
		this.hello = hello;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	public String sayHello(){
		
		return hello+"!"+date;
	}
	
}
