package bean;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class HelloSpring3 {

	
	private String[] bookNames;
	private List booklist;
	private Map bookMap;
	
	
	
	public String[] getBookNames() {
		return bookNames;
	}



	public void setBookNames(String[] bookNames) {
		this.bookNames = bookNames;
	}



	public List getBooklist() {
		return booklist;
	}



	public void setBooklist(List booklist) {
		this.booklist = booklist;
	}



	public Map getBookMap() {
		return bookMap;
	}



	public void setBookMap(Map bookMap) {
		this.bookMap = bookMap;
	}



	public void printlnfo(){
		
		System.out.println("array:");
		for(String s:bookNames){
			
			System.out.println("\t"+s);
		}

		System.out.println("list:");
		for(Object s1:booklist){
			System.out.println("\t"+s1);
			
	    System.out.println("map:");
	    Iterator it=bookMap.keySet().iterator();
		while(it.hasNext()){
			Object o=it.next();
			System.out.println("\t"+o+"="+bookMap.get(o));
		}
	}
}
}