package bean;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Party {

	
	private String topic;
	private Date date;
	private List members;
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Party(String topic,Date date){
		
		this.date=date;
		this.topic=topic;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
		
	}
	public List getMembers() {
		return members;
	}
	public void setMembers(List members) {
		this.members = members;
	}
	public void printlnfo(){	
		
		if(members!=null){
			SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd");
			String sdf=sd.format(date);
			System.out.println("时间:"+sdf+" "+topic+"参加人数："+members.size());
			for(Object o:members){
				System.out.println("\t"+o);
			}
		}else {
			
			System.out.println("参加人数无："+members);
		}
	}
}
