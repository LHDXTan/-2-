package bean;

import java.util.Date;

public class HelloSpring {

	
	private String hello;
	private Date date;
	
	public HelloSpring(String hello,Date date){
		
		this.hello=hello;
		this.date=date;
	}
	public String sayhello(){
		
		return hello+"!"+date;
	}
}
