package bean;

public class Book {

	
	private String book;
	private float price;
	public String getBook() {
		return book;
	}
	public void setBook(String book) {
		this.book = book;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	public String toString(){
		
		return "书名："+book+"\t"+"价格："+price;
	}
}
