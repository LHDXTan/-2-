package comm.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import com.vo.Party;

public class HelloAppListener implements ApplicationListener {
	public void onApplicationEvent(ApplicationEvent event){
		if(event instanceof ContextRefreshedEvent){
			ContextRefreshedEvent cse=(ContextRefreshedEvent)event;
			ApplicationContext ac=cse.getApplicationContext();
			System.out.println("������...........");
			Party p=(Party) ac.getBean("party");
			if(p!=null){
				p.printInfo();
			}
		}
	}



}
