package com.qhit;

import org.springframework.context.ApplicationContext;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	
	public static void main(String[] args){
//		Resource resource = new ClassPathResource("/applicationContext.xml");
//		BeanFactory beanFactory = new XmlBeanFactory(resource);
		ApplicationContext appContext = new ClassPathXmlApplicationContext("/applicationContext.xml");
		JuHui j = (JuHui)appContext.getBean("juhui");
		j.printInfo();
		
//		XiaoYouBean3 xy = (XiaoYouBean3)beanFactory.getBean("XiaoYouBean3");
//		xy.printInfo();
		
//		XiaoYou x = (XiaoYou)beanFactory.getBean("x1");
//		String msg = x.run();
//		System.out.println(msg);
//		JuHui j = (JuHui)beanFactory.getBean("j");
//		msg = j.run();
//		System.out.println(msg);
	}

}
