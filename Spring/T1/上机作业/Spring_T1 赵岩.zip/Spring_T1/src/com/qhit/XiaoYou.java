package com.qhit;

public class XiaoYou {
	private String name;
	private char sex;
	private String phone;
	
	public void XiaoYou(String name, char sex, String phone){
		this.name = name;
		this.sex = sex;
		this.phone = phone;
	}
	
	public String toString(){
		return "������"+name +"\t�Ա�"+ sex +"\t�绰��"+ phone;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public char getSex() {
		return sex;
	}
	public void setSex(char sex) {
		this.sex = sex;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
