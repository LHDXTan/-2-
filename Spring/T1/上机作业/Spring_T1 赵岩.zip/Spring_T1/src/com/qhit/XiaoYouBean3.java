package com.qhit;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class XiaoYouBean3 {
	private String[] xiaoyou;
	private List xiaoyoulist;
	private Map xiaoyoumap;
	
	public void printInfo(){
		System.out.println("Array:");
		for(String str:xiaoyou){
			System.out.println("\t"+str);
		}
		
		System.out.println("List:");
		for(Object o:xiaoyoulist){
			System.out.println("\t"+o);
		}
		
		System.out.println("Map:");
		Iterator it = xiaoyoumap.keySet().iterator();
		while(it.hasNext()){
			Object key = it.next();
			System.out.println("\t"+key+"="+xiaoyoumap.get(key));
		}
	}

	public String[] getXiaoyou() {
		return xiaoyou;
	}

	public void setXiaoyou(String[] xiaoyou) {
		this.xiaoyou = xiaoyou;
	}

	public List getXiaoyoulist() {
		return xiaoyoulist;
	}

	public void setXiaoyoulist(List xiaoyoulist) {
		this.xiaoyoulist = xiaoyoulist;
	}

	public Map getXiaoyoumap() {
		return xiaoyoumap;
	}

	public void setXiaoyoumap(Map xiaoyoumap) {
		this.xiaoyoumap = xiaoyoumap;
	}
	
	

}
