package com.qhit;

import java.util.Date;
import java.util.List;


public class JuHui {
	private String topic;
	private Date day;
	private String didian;
	private List members;

	
	public void JuHui(String topic,Date day,String didian){
		this.topic = topic;
		this.day = day;
		this.didian = didian;
	}
	
	public void printInfo(){
		if(members!=null){
			System.out.println(topic+"������������"+members.size());
			for(Object o:members){
				System.out.println(o);
			}
		} else {
			System.out.println(topic+"������������0");
		}
	}
	
	public Date getDay() {
		return day;
	}
	public void setDay(Date day) {
		this.day = day;
	}
	public String getDidian() {
		return didian;
	}
	public void setDidian(String didian) {
		this.didian = didian;
	}

	public List getMembers() {
		return members;
	}

	public void setMembers(List members) {
		this.members = members;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}
	
	

}
