package bean;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class HelloBean {
	
	private String[]bookNames;
	private List bookList;
	private Map bookMap;
	
	public void printInfo(){
		System.out.println("array");
		for(String s:bookNames){
			System.out.println("\t"+s);
		}
		
		System.out.println("List");
		for(Object o:bookList){
			System.out.println("\t"+o);
		}
		
		System.out.println("Map");
		Iterator it=bookMap.keySet().iterator();
		while(it.hasNext()){
			Object key=it.next();
			System.out.println("\t"+key+"="+bookMap.get(key));
		}
	}
	public String[] getBookNames() {
		return bookNames;
	}
	public void setBookNames(String[] bookNames) {
		this.bookNames = bookNames;
	}
	public List getBookList() {
		return bookList;
	}
	public void setBookList(List bookList) {
		this.bookList = bookList;
	}
	public Map getBookMap() {
		return bookMap;
	}
	public void setBookMap(Map bookMap) {
		this.bookMap = bookMap;
	}
	
	

}
