package bean;

import java.util.List;

public class Party {
	private String topic;
	private List members;
	
	
	
	
	public Party(String topic) {
		this.topic = topic;
	}
	
	
	
	public void printInfo(){
		if(members!=null){
			System.out.println("参与人数"+members.size());
			for(Object o:members){
				System.out.println("\t"+o);
			}
		}else{
			System.out.println("暂无参与人数");
		}
	}
	
	
	public Party(String topic, List members) {
		super();
		this.topic = topic;
		this.members = members;
	}


	public Party() {
		super();
	}


	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public List getMembers() {
		return members;
	}
	public void setMembers(List members) {
		this.members = members;
	}
	
	

}
