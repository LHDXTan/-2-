package com.ly.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import com.ly.pojo.Party;

public class HelloAppListener  implements ApplicationListener{

	@Override
	public void onApplicationEvent(ApplicationEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0 instanceof ContextRefreshedEvent){
			ContextRefreshedEvent cse = (ContextRefreshedEvent) arg0;
			ApplicationContext appContext = cse.getApplicationContext();
			System.out.println("���������Ѿ����Ҽ����ˣ�����"+appContext);
			Party party = (Party) appContext.getBean("party");
			if(party!=null){
				party.ppinfo();
			}
		}

	}

}
