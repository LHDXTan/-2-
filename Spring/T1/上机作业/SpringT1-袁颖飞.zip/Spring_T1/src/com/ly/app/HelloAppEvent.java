package com.ly.app;

import org.springframework.context.ApplicationEvent;

public class HelloAppEvent extends ApplicationEvent{

	public HelloAppEvent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
