package com.spring1.beans;

import java.util.List;

public class Party {
	private String topic;
	private List members;
	
	public Party(String topic){
		this.topic=topic;
	}
	
	public void test(){
	    if(members.size()==0){
	    	System.out.println("�ܱ�Ǹ��û��ͬѧ");
	    }else{
	    	System.out.println("����"+members.size()+"λͬѧ�μ�"+topic);
	    	for(Object o:members){
	    		System.out.println("\t"+o);
	    	}
	    }	
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public List getMembers() {
		return members;
	}
	public void setMembers(List members) {
		this.members = members;
	}
	

}
