package com.spring1.beans;

public class AlumniInformation {

	private String name;
	private String sex;
	private String phone;
	
	
	public String toString(){
		String t="�ҽ�"+name+",�Ա�"+sex+",�绰��"+phone;
		return t;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
