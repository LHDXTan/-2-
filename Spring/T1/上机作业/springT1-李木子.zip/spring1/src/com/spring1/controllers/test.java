package com.spring1.controllers;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.spring1.beans.Party;

public class test {

	

	public static void main(String[] args) {
		Resource res= new ClassPathResource("/applicationContext.xml");
		BeanFactory bf=new XmlBeanFactory(res);
		
		Party p=(Party) bf.getBean("party");
		p.test();
		
	}
}
