package demo.test;

import java.util.Date;

import javax.swing.Spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import demo.bean.Party;
import demo.util.SpringPartyEvent;
import demo.util.SpringPartyListener;


public class test {

	/**
	 * ������
	 */
	public static void main(String[] args) {
		
		//4.1 4.2��ϰ
		ApplicationContext appContext = new ClassPathXmlApplicationContext("/applicationContext.xml");
		Date now=(Date) appContext.getBean("now");
		System.out.println(now);
		
		//5.1��ϰ
		Party party=(Party) appContext.getBean("party");
		party.printInfo();
		
		//5.2��ϰ
		appContext.publishEvent(new SpringPartyEvent(Party.class));
	}

}
