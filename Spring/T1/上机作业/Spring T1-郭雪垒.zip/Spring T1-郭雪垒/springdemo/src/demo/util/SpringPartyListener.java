package demo.util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import demo.bean.Party;

public class SpringPartyListener implements ApplicationListener{

	@Override
	public void onApplicationEvent(ApplicationEvent event) {
		if(event instanceof ContextRefreshedEvent){
			ContextRefreshedEvent cse=(ContextRefreshedEvent)event;
			ApplicationContext appContext=cse.getApplicationContext();
			System.out.println("ִ�м�����......");
			Party party=(Party) appContext.getBean("party");
			if(party!=null){
				party.printInfo();
			}
		}
		
	}

}
