package demo.util;

import org.springframework.context.ApplicationEvent;

public class SpringPartyEvent extends ApplicationEvent{

	public SpringPartyEvent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}
	

}
