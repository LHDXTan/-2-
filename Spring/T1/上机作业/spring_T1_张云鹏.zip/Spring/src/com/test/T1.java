package com.test;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class T1 {
public static void main(String[] args) {
	Resource r=  new ClassPathResource("/applicationContext.xml");
	BeanFactory  bean= new XmlBeanFactory(r);
	
	Test t1= (Test) bean.getBean("test");
	String str1 = t1.toTest();
	
	System.out.println(str1);
	
	
	Test1 t2= (Test1) bean.getBean("test1");
	String str2 = t2.toTest();
	
	System.out.println(str2);
	
	

	B t3=  (B) bean.getBean("book");
      t3.P();
	
}
}
