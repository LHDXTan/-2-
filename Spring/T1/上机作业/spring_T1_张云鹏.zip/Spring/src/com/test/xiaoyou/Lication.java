package com.test.xiaoyou;

import org.springframework.context.ApplicationEvent;

public class Lication extends ApplicationEvent{

	public Lication(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}
	
	

}
