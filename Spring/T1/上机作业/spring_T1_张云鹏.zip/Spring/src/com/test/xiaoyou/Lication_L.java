package com.test.xiaoyou;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;

public class Lication_L implements ApplicationListener {

	@Override
	public void onApplicationEvent(ApplicationEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0 instanceof Lication){
			Lication l= (Lication) arg0;
			
			
			System.out.println("监听到了"+"--"+arg0.getSource());
		}
	}

}
