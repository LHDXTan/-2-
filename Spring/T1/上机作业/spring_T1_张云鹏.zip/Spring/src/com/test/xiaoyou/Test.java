package com.test.xiaoyou;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;


public class Test {
	public static void main(String[] args) {
		ApplicationContext  app =new ClassPathXmlApplicationContext("/applicationContext.xml");
		app.publishEvent(new Lication(XiaoYou.class));

		Resource r=  new ClassPathResource("/applicationContext.xml");
		BeanFactory  bean= new XmlBeanFactory(r);
		JuHui j= (JuHui) bean.getBean("j");
		j.p();


	}

}
