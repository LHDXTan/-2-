package com.test;

public class Book {
private String name;
private float qian;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getQian() {
	return qian;
}
public void setQian(float qian) {
	this.qian = qian;
}


}
