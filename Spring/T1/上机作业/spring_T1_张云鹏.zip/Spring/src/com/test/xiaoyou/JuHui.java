package com.test.xiaoyou;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class JuHui {
	private XiaoYou[] name;
	private Date date;
	private String add;

	public Date getDate() {

		return date;
	}

	public void setDate(Date date) throws ParseException {
		System.out.println(date);
		this.date = date;
	}

	public String getAdd() {

		return add;
	}

	public void setAdd(String add) {
		System.out.println(add);
		this.add = add;
	}

	public XiaoYou[] getName() {

		return name;
	}

	public void setName(XiaoYou[] name) {
		System.out.println(name);
		this.name = name;
	}

	public void p() {
		System.out.println("参加人员有：");
		for (int i = 0; i < name.length; i++) {
			XiaoYou x = name[i];
			System.out.println("姓名：" + x.getName() + "\t" + "电话：" + x.getTel()
					+ "\t" + "居住地：" + x.getAdd());

		}
		

		SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		     String day = f.format(date);
		
		System.out.println("时间：" + day + "\t" + "地点：" + add);
	}

}
