package com.test;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class B {
private String[] name;
private List list;
private Map  map;
public String[] getName() {
	return name;
}
public void setName(String[] name) {
	this.name = name;
}
public List getList() {
	return list;
}
public void setList(List list) {
	this.list = list;
}
public Map getMap() {
	return map;
}
public void setMap(Map map) {
	this.map = map;
}



public void P(){
	
	for(String s:name){
		
		System.out.println(s);
	}
	
	
	for(int i=0;i<list.size();i++){
		
		System.out.println(list.get(i));
	}
	
//	for(Object o:list){
//	String str=	o.toString();
//		System.out.println(str);
//	}
//	
	Iterator i= map.keySet().iterator();
	while(i.hasNext()){
		Object key =i.next();
	for(int j=0;j<map.size();j++){
		System.out.println(map.get(key)+"--"+key);
	}
	
	
	}
	
//	Iterator i= map.keySet().iterator();
//	while(i.hasNext()){
//		Object key =i.next();
//	String str=	map.get(key).toString();
//		System.out.println(key+"="+str);
//	}
}
}
