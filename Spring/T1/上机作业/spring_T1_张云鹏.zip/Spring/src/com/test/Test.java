package com.test;
import java.util.Date;


public class Test {
private Date date;
private String name;


public Test(String name,Date date){
	this.name=name;
	this.date=date;
	
}

public String toTest(){
	
	return name+"!"+date;
}



public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}


}
