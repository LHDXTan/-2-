package com.dao;

import java.util.Date;
import java.util.List;


public class juhui {
 

   private String didian;
   private List mem;
   private Date date;
   
   public juhui(String didian,Date date){
	   this.didian=didian;
	   this.date=date;
   }
   
   
   public String jinfo(){
	   if(mem!=null){
		   System.out.println(didian+"参与人数"+mem.size()+date);
		 for(Object o:mem){
			 System.out.println("\t"+o);
			 
		 }
	   }else{
		   System.out.println(didian+"参与人数：暂无");
	   }
	return "";
	   
   }


public List getMem() {
	return mem;
}


public void setMem(List mem) {
	this.mem = mem;
}


public String getDidian() {
	return didian;
}


public void setDidian(String didian) {
	this.didian = didian;
}


public Date getDate() {
	return date;
}


public void setDate(Date date) {
	this.date = date;
}
   
}
