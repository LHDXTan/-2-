package com.test;

import org.springframework.context.ApplicationEvent;

public class helloapp extends ApplicationEvent{

	public helloapp(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
