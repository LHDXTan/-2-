package com.test;

import javax.ejb.TimerService;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.dao.juhui;




public class Test {
 public static void main(String[] args) {
	

	 ApplicationContext source =new ClassPathXmlApplicationContext("/applicationContext.xml");
	 source.publishEvent(new helloapp(TimerService.class));
	 juhui jh=(juhui)source.getBean("juhui1");
	 
	 String ss= jh.jinfo();
	 System.out.println(ss);
}
}