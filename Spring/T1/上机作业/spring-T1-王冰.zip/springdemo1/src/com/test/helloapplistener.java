package com.test;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;

public class helloapplistener implements ApplicationListener<ApplicationEvent>{

	@Override
	public void onApplicationEvent(ApplicationEvent event) {
		// TODO Auto-generated method stub
		if(event instanceof helloapp){
			System.out.println("呵呵！已经监听到你"+event.getSource());
		}
	}

}
