package com.spring.test;

import javax.annotation.Resource;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class test {
     
	 public static void main(String[] args) {
		//��ȡapplicationContext
		 Resource resource = (Resource) new ClassPathResource("/applicationContext.xml");
		 BeanFactory beanFactory = new XmlBeanFactory((org.springframework.core.io.Resource) resource);
		 
		 HelloBean hello = (HelloBean)beanFactory.getBean("HelloBean");
		 String msg=hello.sayHello();
		 System.out.println(msg);
	}
}
