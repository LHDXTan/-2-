package com.spring.test;

import java.util.Date;

public class HelloBean {

	private String hello;
	private Date date;
	
	private HelloBean(String hello,Date date){
		this.hello=hello;
		this.date=date;
		
	}
	
	public String sayHello(){
		return hello+"!"+date;
		
	}
}
