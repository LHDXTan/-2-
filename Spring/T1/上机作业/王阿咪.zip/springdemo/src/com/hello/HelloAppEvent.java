package com.hello;

import org.springframework.context.ApplicationEvent;


/*
 * �Զ����¼���
 */
public class HelloAppEvent extends ApplicationEvent {

	public HelloAppEvent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
