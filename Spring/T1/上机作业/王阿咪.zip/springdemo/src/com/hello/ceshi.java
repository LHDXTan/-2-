package com.hello;

import javax.xml.crypto.dsig.TransformService;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ceshi {

	public static void main(String[] args) {
		
		ApplicationContext appContext=new ClassPathXmlApplicationContext("/applicationContext.xml");
		appContext.publishEvent(new HelloAppEvent(TransformService.class));
	}
}
