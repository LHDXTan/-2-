package com.qhit.test;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.qhit.pojo.party;
import com.qhit.pojo.user;
import com.qhit.pojo.users;

public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//��������
Resource rs = new ClassPathResource("applicationContext.xml");
          //��ȡ�����Ĺ��̶��� 
		BeanFactory factory = new XmlBeanFactory(rs);
	//���ݹ������󣬻�ȥIOC�����е�һ��bean�齨
		user user = (user) factory.getBean("user");
		//���ö����еķ���
		user.say();
		System.out.println(user);
		
		party pt=(party) factory.getBean("party");
		pt.tea();
		System.out.println(pt);
	
       users us=(users)factory.getBean("users");
       String as[]=us.getAss();
       List list=us.getList();
       System.out.println(as[0]);
       System.out.println(as[1]);
}
}