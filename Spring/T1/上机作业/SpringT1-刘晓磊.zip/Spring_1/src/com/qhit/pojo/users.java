package com.qhit.pojo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class users {
	private String ass[];
	private List  list = new ArrayList();
	private Map map = new HashMap();
	
	
	
	public String[] getAss() {
		return ass;
	}
	public void setAss(String[] ass) {
		this.ass = ass;
	}
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	public Map getMap() {
		return map;
	}
	public void setMap(Map map) {
		this.map = map;
	}
}
	


