package com.qhit.pojo;



public class user {
   private  String uname;
   private  String telephone;
   private  String  sex;
   
    public user(String uname,String telephone,String sex ){  	
       this.uname=uname;
       this.telephone=telephone;
       this.sex=sex;
    }
   public void say(){
	   System.out.println(uname+telephone+sex);
   } 
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getTelephone() {
	return telephone;
}
public void setTelephone(String telephone) {
	this.telephone = telephone;
}
public String getSex() {
	return sex;
}
public void setSex(String sex) {
	this.sex = sex;
}
}
