package com.qhit.pojo;

import java.util.Date;

public class party {
  private String adress;
  private Date riqi;
  
  public party(String adress, Date riqi){
	  this.adress=adress;
	  this.riqi=riqi;
  }
  public void tea(){
	  System.out.println(adress+riqi);
  }
  
public String getAdress() {
	return adress;
}
public void setAdress(String adress) {
	this.adress = adress;
}
public Date getRiqi() {
	return riqi;
}
public void setRiqi(Date riqi) {
	this.riqi = riqi;
}

}
