package text;

import hello.HelloAppEvent;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Party;

public class Text {

	public static void main(String[] arge){
		ApplicationContext appContext= new ClassPathXmlApplicationContext("/applicationContext.xml");
		appContext.publishEvent(new HelloAppEvent("aaaa"));
		Party party = (Party) appContext.getBean("party");
		party.printInfo();
	}
}
