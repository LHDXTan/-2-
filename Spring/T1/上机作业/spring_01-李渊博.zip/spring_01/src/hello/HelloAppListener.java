package hello;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;

public class HelloAppListener implements ApplicationListener{

	@Override
	public void onApplicationEvent(ApplicationEvent event) {
		// TODO Auto-generated method stub
		
		if(event instanceof HelloAppEvent){//监听在自定义事件
			System.out.println("klasd!监听到："+event.getSource());
		}
		
	}

}
