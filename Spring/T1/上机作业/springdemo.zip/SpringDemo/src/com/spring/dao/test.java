package com.spring.dao;

import javax.annotation.Resource;










import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.spring.listener.listener;
import com.spring.listener.listeners;
import com.spring.vo.jihe;
import com.spring.vo.jvhui;
import com.spring.vo.xinxi;

public class test {
	
	public static void main(String[] args) {
		ClassPathResource rs= new ClassPathResource("applicationContext.xml");
		ApplicationContext app= new ClassPathXmlApplicationContext("applicationContext.xml");
		app.publishEvent(new listener(test.class));
		
		
//		BeanFactory beanfactory= new XmlBeanFactory(rs);
//		xinxi xx=(xinxi) beanfactory.getBean("xinxi1");
//		xinxi xx1=(xinxi) beanfactory.getBean("xinxi2");
//		xx.sayxinxi();
//		xx1.sayxinxi();
//		jihe jh=(jihe) beanfactory.getBean("jihe");		
//		jh.jihe();
		
		
//		xinxi xx=(xinxi) beanfactory.getBean("now");
//		xx.sayxinxi();
	}

}
