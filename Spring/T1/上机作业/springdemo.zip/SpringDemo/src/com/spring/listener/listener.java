package com.spring.listener;

import org.springframework.context.ApplicationEvent;

public class listener extends ApplicationEvent {

	public listener(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}
	

}
