package com.spring.vo;

import java.util.List;

public class jihe {
  private List<jvhui> jvhui;
  
    public void jihe(){
    	
    	for(jvhui o:jvhui){
    		System.out.println("地址:"+o.getAddress()+"\t"+"时间:"+o.getTime()+"\t");
    		System.out.println("参加人数:"+o.getXinxi().size());
    		for(xinxi xx:o.getXinxi()){
    			System.out.println("姓名:"+xx.getName()+"\t"+"性别:"+xx.getSex()+"\t"+"电话:"+xx.getTelephone());
    		}
    	}
    }
  

public List<jvhui> getJvhui() {
	return jvhui;
}

public void setJvhui(List<jvhui> jvhui) {
	this.jvhui = jvhui;
}
  
  
  
}
