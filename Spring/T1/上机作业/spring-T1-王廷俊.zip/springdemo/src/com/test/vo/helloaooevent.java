package com.test.vo;

import org.springframework.context.ApplicationEvent;

public class helloaooevent  extends ApplicationEvent{

	public helloaooevent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
