package com.test.vo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

public class helloAppListener implements ApplicationListener {

	@Override
	public void onApplicationEvent(ApplicationEvent event) {
		// TODO Auto-generated method stub
		if(event instanceof ContextRefreshedEvent){
			ContextRefreshedEvent cse=(ContextRefreshedEvent) event;
			ApplicationContext app=cse.getApplicationContext();
			System.out.println("�Ǻǣ������¼�"+event.getSource());
			 party party = (party)app.getBean("party");
			 if(party!=null){
				 party.printInfo();
					
			 }
		
			
		}
	}

}
