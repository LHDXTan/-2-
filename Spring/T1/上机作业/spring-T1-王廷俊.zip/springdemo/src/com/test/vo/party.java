package com.test.vo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class party {

	
	private String sj;
	private List members;

	public  party(Date sj){
		SimpleDateFormat ss=   new SimpleDateFormat("yyyy-mm-dd");
		this.sj=ss.format(sj.getTime());
	}

	public void printInfo(){
		
		if(members!=null){
		
			System.out.println("ʱ��"+sj+"��������"+members.size());
			for(Object o:members){
				
				System.out.println("\t"+o);
			}
		}else{
			System.out.println(sj+"��������:����");
		}
	}
	

	public List getMembers() {
		return members;
	}
	public void setMembers(List members) {
		this.members = members;
	}
	
}
