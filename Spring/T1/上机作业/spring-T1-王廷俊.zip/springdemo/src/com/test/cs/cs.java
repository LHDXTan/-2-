package com.test.cs;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.test.vo.helloaooevent;
import com.test.vo.party;
import com.test.vo.xy;

public class cs {

	
	public static void main(String[] args) {
	 ApplicationContext ss= new ClassPathXmlApplicationContext("applicationContext.xml");
	 ss.publishEvent(new helloaooevent(cs.class));

	}
}
