package com.text;

import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;



public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   ApplicationContext app = new ClassPathXmlApplicationContext("/applicationContext.xml");
		Party s=  (Party) app.getBean("par");
		s.sel();
		
		ApplicationContext app1 = new ClassPathXmlApplicationContext("/applicationContext.xml");
		app1.publishEvent(new helloevent(Party.class));
		
	}

}
