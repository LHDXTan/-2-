package com.text;

import org.springframework.context.ApplicationEvent;

public class helloevent extends ApplicationEvent {

	public helloevent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}
     
}
