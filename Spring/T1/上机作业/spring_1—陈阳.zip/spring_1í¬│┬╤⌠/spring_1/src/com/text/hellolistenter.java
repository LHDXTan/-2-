package com.text;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;

public class hellolistenter implements ApplicationListener{

	@Override
	public void onApplicationEvent(ApplicationEvent event) {
	
		// TODO Auto-generated method stub
		if(event instanceof helloevent){
			System.out.println("监听事件" +event.getSource());
		}
	}
   
	 
	
}
