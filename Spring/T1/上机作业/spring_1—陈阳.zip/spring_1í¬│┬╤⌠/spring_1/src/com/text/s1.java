package com.text;

import java.util.Date;

public class s1 {

	private String name;
	private Date date;
	
	public s1 (String name,Date date){
		this.name=name;
		this.date=date;
		
	}
	
	public String sayhello(){
		
		
		return name+"=="+date;
	}
}
