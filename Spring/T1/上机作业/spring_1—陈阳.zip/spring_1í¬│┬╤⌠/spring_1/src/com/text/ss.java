package com.text;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class ss {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         
		Resource res = new ClassPathResource("/applicationContext.xml");
		 BeanFactory bf = new XmlBeanFactory(res);
		s1 s=  (s1) bf.getBean("s");
         String st =  s.sayhello();
	    System.out.println(st);
		
	    s1 s1=  (s1) bf.getBean("s");
		 System.out.println(s1);
		
		 s1 s2=  (s1) bf.getBean("s");
		 System.out.println(s2);
	}

}
