package com.text;

import java.util.List;

public class Party{

    private String topic;
    private List num;
    
    
    public Party(String topic){
    	
    	this.topic=topic;
    }
    
    
    public void sel(){
    	if(num!=null){
    		System.out.println(topic+"  "+"人数:"+num.size());
    		for(Object o:num){
    			System.out.println("\t"+o);
    		}
    	}else{
    		
    		System.out.println(topic+"人数:无");
    	}
    	
    }
    

	public List getNum() {
		return num;
	}
	public void setNum(List num) {
		this.num = num;
	}
    
    

}
