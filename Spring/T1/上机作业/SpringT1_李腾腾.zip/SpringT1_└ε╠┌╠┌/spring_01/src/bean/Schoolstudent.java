package bean;

import java.util.Date;

public class Schoolstudent {
	
	private String sname;
	private String ssex;
	private String sphone;
	
	
	public void tests(){
		System.out.println("--sname:"+sname+"--ssex:"+ssex+"--sphone:"+sphone);
		
	}
	
	public String toString(){
		return "--姓名:"+sname+"--性别:"+ssex+"--电话:"+sphone;
		
	}
	
	public Schoolstudent(String sname, String ssex, String sphone) {
		super();
		this.sname = sname;
		this.ssex = ssex;
		this.sphone = sphone;
	}
	
	public Schoolstudent() {
		super();
	}


	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSsex() {
		return ssex;
	}
	public void setSsex(String ssex) {
		this.ssex = ssex;
	}
	public String getSphone() {
		return sphone;
	}
	public void setSphone(String sphone) {
		this.sphone = sphone;
	}
	
	

}
