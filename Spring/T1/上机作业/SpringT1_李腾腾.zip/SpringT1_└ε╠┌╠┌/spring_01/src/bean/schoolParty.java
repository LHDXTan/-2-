package bean;

import java.util.Date;
import java.util.List;

public  class schoolParty {
	
	private Date date;//时间
	private String topic;//主题
	private List members;//成员
	
	
	
	
	//方法
	public void printInfo(){
		if(members!=null){
			System.out.println("        --主题："+topic+"--参与人数："+members.size());
			for(Object o : members){
				System.out.println("\t"+o.toString());
			}
			
		}else{
			
			System.out.println(topic+"参与人数：暂无");
		}
		
	}
	
	//构造函数
	
	
	public schoolParty(Date date, String topic, List members) {
		super();
		this.date = date;
		this.topic = topic;
		this.members = members;
	}
	public schoolParty(Date date, String topic) {
		super();
		this.date = date;
		this.topic = topic;
	}

	public schoolParty() {

	}

	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public List getMembers() {
		return members;
	}
	public void setMembers(List members) {
		this.members = members;
	}
	
	
	

}
