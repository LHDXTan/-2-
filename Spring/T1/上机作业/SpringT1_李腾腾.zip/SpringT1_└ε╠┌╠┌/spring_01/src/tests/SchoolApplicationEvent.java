package tests;

import org.springframework.context.ApplicationEvent;

public class SchoolApplicationEvent extends  ApplicationEvent {

	public SchoolApplicationEvent(Object source) {
		
		super(source);
		
	}
	
	
		
		


	
}
