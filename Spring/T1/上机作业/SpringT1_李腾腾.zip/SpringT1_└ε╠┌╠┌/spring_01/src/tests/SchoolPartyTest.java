package tests;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import bean.schoolParty;

public class SchoolPartyTest {

	public static void main(String[] args) {

		/*Resource resource=new ClassPathResource("/applicationContext.xml");			
		BeanFactory beanfactory=new XmlBeanFactory(resource);
		schoolParty sp=(schoolParty) beanfactory.getBean("partys");*/
		
		ApplicationContext appContext=new ClassPathXmlApplicationContext("/applicationContext.xml");
		schoolParty sp=(schoolParty)appContext.getBean("partys");	
		
		sp.printInfo();
		appContext.publishEvent(new SchoolApplicationEvent(SchoolApplicationEvent.class));
		
	}

}
