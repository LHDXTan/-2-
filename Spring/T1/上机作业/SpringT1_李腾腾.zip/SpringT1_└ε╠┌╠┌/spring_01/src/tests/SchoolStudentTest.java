package tests;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import bean.Schoolstudent;

public class SchoolStudentTest {

	public static void main(String[] args) {

		//获取spring
		Resource resource=new ClassPathResource("/applicationContext.xml");
		//
		BeanFactory beanFactory=new XmlBeanFactory(resource);
		//
	    Schoolstudent ss=(Schoolstudent)beanFactory.getBean("schoolstudent");
	    
	    //
	    ss.tests();
	}

}
