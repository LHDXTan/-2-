package tests;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;

public class SchoolApplicationListener implements ApplicationListener{

	public void onApplicationEvent(ApplicationEvent event) {

	if(event instanceof SchoolApplicationEvent ){//监听自定义事件
			
			System.out.println("呵呵 ！ 监听到自定义事件："+event.getSource());
			
		}
		
	}

}
