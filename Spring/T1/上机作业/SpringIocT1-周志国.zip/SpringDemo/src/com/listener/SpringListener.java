package com.listener;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import com.vo.ListVo;

public class SpringListener implements ApplicationListener{

	@Override
	public void onApplicationEvent(ApplicationEvent event) {
		// TODO Auto-generated method stub
		if(event instanceof ContextRefreshedEvent){
//			System.out.println("监听到:"+event.getSource());
			ContextRefreshedEvent cs=(ContextRefreshedEvent)event;
			ApplicationContext app=cs.getApplicationContext();
			ListVo ll=(ListVo)app.getBean("list");
			ll.messVo();
		}
	}

}
