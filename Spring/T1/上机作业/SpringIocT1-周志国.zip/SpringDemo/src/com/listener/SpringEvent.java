package com.listener;

import org.springframework.context.ApplicationEvent;

/*
 * 自定义事件类
 * */
public class SpringEvent extends ApplicationEvent{

	public SpringEvent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
