package com.vo;

import java.util.List;

public class ListVo {
    private List<SchoolPaty> list;

    
    public void messVo(){
    	for(SchoolPaty ss:list){
    		System.out.println("地址:"+ss.getAdress()+",时间:"+ss.getTime());
    		System.out.println("参加聚会共:"+ss.getList().size()+"人");
    		for(PerpsonMess me:ss.getList()){
    			System.out.println("姓名:"+me.getName()+",联系方式:"+me.getIphone());
    		}
    		System.out.println("");
    	}
    }
	public List<SchoolPaty> getList() {
		return list;
	}

	public void setList(List<SchoolPaty> list) {
		this.list = list;
	}
    
}
