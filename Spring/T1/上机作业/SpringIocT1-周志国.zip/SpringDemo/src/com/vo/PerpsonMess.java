package com.vo;

public class PerpsonMess {
   private String name;
   private String sex;
   private String iphone;
   
//    public void mess(String name,String sex,String iphone){
//    	this.name=name;
//    	this.sex=sex;
//    	this.iphone=iphone;
//    }
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getIphone() {
		return iphone;
	}
	public void setIphone(String iphone) {
		this.iphone = iphone;
	}
}
