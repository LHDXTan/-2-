package com.vo;

import java.util.Date;
import java.util.List;

public class SchoolPaty {

	private String adress;
	private Date time;
	private List<PerpsonMess> list;
	
	
//	public void paty(String adress,Date time,List list){
//		this.adress=adress;
//		this.time=time;
//		this.list=list;
//	}
	public void test(){
		System.out.println("地址:"+adress+",时间:"+time);
		for(PerpsonMess o:list){
			System.out.println("姓名:"+o.getName()+",联系方式:"+o.getIphone());
		}
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public List<PerpsonMess> getList() {
		return list;
	}
	public void setList(List<PerpsonMess> list) {
		this.list = list;
	}
	
}
