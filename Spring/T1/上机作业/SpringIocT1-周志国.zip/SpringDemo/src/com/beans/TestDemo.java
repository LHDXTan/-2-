package com.beans;

import java.util.List;

import javax.ws.rs.core.Application;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.listener.SpringEvent;
import com.listener.SpringListener;
import com.vo.ListVo;
import com.vo.PerpsonMess;
import com.vo.SchoolPaty;

public class TestDemo {

	
	//测试
	public static void main(String[] args) {
		//获取配置地址
//		Resource resource=new ClassPathResource("applicationContext.xml");
//		//转换bean工厂
//		BeanFactory fac=new XmlBeanFactory(resource);
//		SchoolPaty ss=(SchoolPaty)fac.getBean("paty1");
//		ss.test();
//		List<PerpsonMess> list=ss.getList();
//		for(int i=0;i<list.size();i++){
//			System.out.println(list.get(i));
//		}
//		ListVo ll=(ListVo)fac.getBean("list");
//		ll.messVo();
		ApplicationContext app=new ClassPathXmlApplicationContext("applicationContext.xml");
		app.publishEvent(new SpringEvent(TestDemo.class));//发布自定义监听事件
//		ListVo ll=(ListVo)app.getBean("list");
//		ll.messVo();
	}
}
