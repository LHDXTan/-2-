package com.test.vo;

import java.util.List;

public class Party {

	private String address;
	private List members;
	
	public Party(String address){
		this.address=address;
	}
	
	public void PrintInfo(){
		if(members!=null){
			System.out.println(address+"参与人数："+members.size());
			for(Object o:members){
				System.out.println("\t"+o);
			}
		}else{
			System.out.println(address+"参与人数：暂无");
		}
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public List getMembers() {
		return members;
	}
	public void setMembers(List members) {
		this.members = members;
	}
	
	
	
}
