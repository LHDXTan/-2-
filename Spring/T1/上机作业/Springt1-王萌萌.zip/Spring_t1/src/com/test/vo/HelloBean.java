package com.test.vo;

import java.util.Date;

public class HelloBean {

	private String hello;
	private Date birthday;
	
	public HelloBean(String hello,Date birthday){
		this.hello=hello;
		this.birthday=birthday;
		
	}
	
	public void sayHello(){
		System.out.println(hello+"  "+birthday+"  sayhello");
	}
	
	public String getHello() {
		return hello;
	}
	public void setHello(String hello) {
		this.hello = hello;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	
	
	
}
