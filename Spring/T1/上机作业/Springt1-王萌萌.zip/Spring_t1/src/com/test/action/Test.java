package com.test.action;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.test.vo.Hello2;
import com.test.vo.HelloBean;
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource resource= new ClassPathResource("applicationContext.xml");
		BeanFactory beanFactory=new XmlBeanFactory(resource);
		
		HelloBean hellobean=(HelloBean)beanFactory.getBean("hellobean");
		hellobean.sayHello();
		
		Hello2 hello =(Hello2)beanFactory.getBean("hello2");
		String hello2=hello.sayHello();
		System.out.println(hello2);

	}

}
