package com.test.action;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import com.test.vo.Party;


public class HelloAppListener implements ApplicationListener{

	@Override
	public void onApplicationEvent(ApplicationEvent event) {
		// TODO Auto-generated method stub
		if(event instanceof ContextRefreshedEvent){
			ContextRefreshedEvent cse=(ContextRefreshedEvent)event;
			ApplicationContext appContext=cse.getApplicationContext();
			System.out.println("监听器！！！");
			Party party=(Party)appContext.getBean("party");
			if(party!=null){
				party.PrintInfo();
			}
		}
	}


}
