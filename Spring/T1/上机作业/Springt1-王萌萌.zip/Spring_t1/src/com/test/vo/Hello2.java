package com.test.vo;

import java.util.Date;

public class Hello2 {
	
	private String hello;
	private Date birthday;
	
	
	
	public String sayHello(){
		return hello+"!"+birthday;
	}
	
	public String getHello() {
		return hello;
	}
	public void setHello(String hello) {
		this.hello = hello;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	
	
	

}
