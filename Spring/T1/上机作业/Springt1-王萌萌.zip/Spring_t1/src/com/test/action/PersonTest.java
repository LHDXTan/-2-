package com.test.action;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PersonTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext appContext=new ClassPathXmlApplicationContext("applicationContext.xml");
		appContext.publishEvent(new HelloAppEvent(PersonTest.class));
//		Party party=(Party)appContext.getBean("party");
//		party.PrintInfo();

	}

}
