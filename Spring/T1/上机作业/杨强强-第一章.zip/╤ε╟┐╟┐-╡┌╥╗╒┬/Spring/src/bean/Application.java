package bean;



import java.util.Date;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext("/applicationContext.xml");
		Date day = (Date) appContext.getBean("day");
		jtq jtq = (bean.jtq) appContext.getBean("jtq");
		System.out.println(day);
	}

}
