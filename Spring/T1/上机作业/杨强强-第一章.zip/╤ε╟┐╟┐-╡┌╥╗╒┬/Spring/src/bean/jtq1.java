package bean;

import org.springframework.context.ApplicationEvent;

public class jtq1 extends ApplicationEvent{

	public jtq1(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
