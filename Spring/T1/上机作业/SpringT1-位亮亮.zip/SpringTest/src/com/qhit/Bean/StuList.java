package com.qhit.Bean;

import java.util.List;
import java.util.Map;

public class StuList {
	
	private String[] Stunam;
	private List Stulis;
	private Map Stumap;
	
	public void info(){
		int length = Stunam.length;
		for(int i=0;i<length;i++){
		System.out.println(Stunam[i]);
		}
	}
	
	public String[] getStunam() {
		return Stunam;
	}

	public void setStunam(String[] stunam) {
		Stunam = stunam;
	}

	public List getStulis() {
		return Stulis;
	}

	public void setStulis(List stulis) {
		Stulis = stulis;
	}

	public Map getStumap() {
		return Stumap;
	}

	public void setStumap(Map stumap) {
		Stumap = stumap;
	}

}
