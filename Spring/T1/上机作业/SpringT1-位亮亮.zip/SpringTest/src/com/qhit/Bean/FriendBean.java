package com.qhit.Bean;

import java.util.Date;

public class FriendBean {

	private String adress;
	private Date time;
	
	public void info(){
		System.out.println("聚会时间:"+time+",聚会地点:"+adress);
	}
	
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	
	
	
}
