package com.qhit.Action;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;

public class listenter implements ApplicationListener {

	@Override
	public void onApplicationEvent(ApplicationEvent arg0) {
		if(arg0 instanceof test){
			System.out.println("已被监听到位");
		}
		
	}

}
