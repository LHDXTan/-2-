package com.qhit.Action;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import com.qhit.Bean.FriendBean;
import com.qhit.Bean.StuList;
import com.qhit.Bean.StudentBean;

public class LoginAction {
	
	// ApplicationContext xmlBeanFactory=new ClassPathXmlApplicationContext("applicationContext.xml");
	
	ClassPathResource classPathResource = new ClassPathResource("applicationContext.xml");
	XmlBeanFactory xmlBeanFactory = new XmlBeanFactory(classPathResource);
 
	//聚会名单
	public void stu(){
		StudentBean sbean = (StudentBean)xmlBeanFactory.getBean("student");
		sbean.info();
		StudentBean sbean1 = (StudentBean)xmlBeanFactory.getBean("student1");
		sbean1.info();
		 }
	//聚会时间及地点
	public void fri(){
		FriendBean fbean=(FriendBean)xmlBeanFactory.getBean("friend");
		fbean.info();
	}
	//集合
	public void lis(){
		StuList stu=(StuList)xmlBeanFactory.getBean("Stulist");
		stu.info();
		
	}
	//测试类
	public static void main(String[] args) {
		//监听
		ApplicationContext app = new ClassPathXmlApplicationContext("applicationContext.xml");
		app.publishEvent(new test(StudentBean.class));
		LoginAction lg=new LoginAction();
		lg.fri();
	}

	
}
