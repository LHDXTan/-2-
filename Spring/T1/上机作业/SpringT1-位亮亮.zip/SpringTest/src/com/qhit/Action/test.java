package com.qhit.Action;

import org.springframework.context.ApplicationEvent;

public class test extends ApplicationEvent{

	public test(Object source) {
		super(source);
	}
}
