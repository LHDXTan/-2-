package com.qhit.bean;

public class Person {
	private String name;
	private String sex;
	private String phone;
		
	public void setName(String name) {
		this.name = name;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String toString(){
		return "Name:"+name+",Sex:"+sex+",Phone:"+phone;
		
	}
	

}
