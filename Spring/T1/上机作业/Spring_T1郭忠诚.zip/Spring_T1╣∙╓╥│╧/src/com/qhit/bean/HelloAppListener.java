package com.qhit.bean;

import java.awt.Event;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

public class HelloAppListener implements ApplicationListener{

	@Override
	public void onApplicationEvent(ApplicationEvent event) {
		if(event instanceof ContextRefreshedEvent){//监听自定义事件
			ContextRefreshedEvent cse=(ContextRefreshedEvent)event;
			ApplicationContext appContext=cse.getApplicationContext();
			System.out.println("监听器。。。");
			Party p=(Party) appContext.getBean("party");
			if(p!=null){
				p.info();
			}
		}
		
	}

}
