package com.qhit.bean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");//读取xml中的内容
        ctx.publishEvent(new HelloAppEvent(Test.class));
		Party p = ctx.getBean("party",Party.class);//创建bean的引用对象
        p.info();

	}

}
