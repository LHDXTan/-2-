package com.spring.dao;

import javax.ejb.TimerService;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.listener.listener;

public class test2 {
	
	public static void main(String[] args) {
		ApplicationContext app= new ClassPathXmlApplicationContext("applicationContext.xml");
		app.publishEvent(new listener(TimerService.class));
	}

}
