package com.spring.vo;

import java.util.Date;
import java.util.List;

/*
 * 
 * 聚会类
 * 
 */

public class jvhui {
      private String address;
      private Date  time;
      private List<xinxi> xinxi;
      
//      public void jvhui(String address,Date time,List ryxx){
//    	  this.address=address;
//    	  this.time=time;
//    	  this.ryxx=ryxx;
//      }
      public void saytime(){
//    	  System.out.println("地址"+address+"\t"+"时间"+time);
    	  for(xinxi o:xinxi){
    		 System.out.println("地址"+address+"\t"+"时间"+time+""+o.getName()+""+o.getSex()+""+o.getTelephone());
    	  }
    	  
      }
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public List<xinxi> getXinxi() {
		return xinxi;
	}
	public void setXinxi(List<xinxi> xinxi) {
		this.xinxi = xinxi;
	}

	 
	 
  
}
