package com.vo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import com.student.Party;



	public class HelloAppListener implements ApplicationListener{
		
	
	public void onApplicationEvent(ApplicationEvent event){
   
   if(event instanceof ContextRefreshedEvent){
	   ContextRefreshedEvent cse = (ContextRefreshedEvent)event;
	   ApplicationContext appContext = cse.getApplicationContext();
	   System.out.println("监听器");
	   Party Xx=(Party)appContext.getBean("Party");
	   if(Xx!=null){
		   Xx.printlnfo();
	   }
   }
	}
	}
