package com.student;

import java.util.List;

public class Party {
	private String topic;//主题
	private List<Xx> members;//成员
	
//	public void Party(String topic,List members){
//		this.topic=topic;
//		this.members=members;
//	}
//	
//	
//	public Party(String topic){
//		this.topic=topic;
//	}//计算人数的方法
	public void printlnfo(){
		if(members!=null){
			System.out.println(topic+"参与人数:"+members.size());
			for(Object o : members){
				System.out.println("/t"+ o);
			}
		}else{
			System.out.println(topic+"参与人数:暂无");
		}
			}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public List<Xx> getMembers() {
		return members;
	}
	public void setMembers(List<Xx> members) {
		this.members = members;
	}

        
}
