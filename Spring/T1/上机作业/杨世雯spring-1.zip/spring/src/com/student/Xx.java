package com.student;

import java.util.Date;

public class Xx {
	private String name;
	private String sex;
	private String phone;
	private Date bir;
	   public String toString(){
			 return "Name:"+name+",Sex:"+sex+"Phone:"+phone+"Bir:"+bir;

		 }
	
	public Date getBir() {
		return bir;
	}

	public void setBir(Date bir) {
		this.bir = bir;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	


}
