package com.student;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.vo.HelloAppEvent;

public class Text {
public static void main(String[] args) {
	
	// Resource resource = new ClassPathResource ("/applicationContext.xml");
	// BeanFactory beanFactory =new XmlBeanFactory(resource);
	 
	// Party Xx=(Party)beanFactory.getBean("Party");
	// Xx.printlnfo();
     ApplicationContext appContext = new ClassPathXmlApplicationContext("/applicationContext.xml");
     appContext.publishEvent(new HelloAppEvent(Text.class));
	 
//	

}
}
