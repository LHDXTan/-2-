package bean;

public class SchoolFriend {
	private String sfname;
	private String sfsex;
	private String sfphone;
	
	public SchoolFriend() {
	}
	
	public String getSfname() {
		return sfname;
	}
	public void setSfname(String sfname) {
		this.sfname = sfname;
	}
	public String getSfsex() {
		return sfsex;
	}
	public void setSfsex(String sfsex) {
		this.sfsex = sfsex;
	}
	public String getSfphone() {
		return sfphone;
	}
	public void setSfphone(String sfphone) {
		this.sfphone = sfphone;
	}
	
	
}
