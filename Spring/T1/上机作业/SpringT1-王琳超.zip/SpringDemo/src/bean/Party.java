package bean;

import java.util.List;

public class Party {
	private String topic;
	private List members;
	
	public Party(String topic) {
		this.topic = topic;
	}
	public String printinfo(){
		String str = "";
		if(members!=null){
			System.out.println(topic+"  参与人数  "+members.size());
			for(Object o:members){
				SchoolFriend sf = (SchoolFriend)o;
				str +="姓名  "+sf.getSfname()+"  性别  "+sf.getSfsex()+"  电话  "+sf.getSfphone()+"\n";
			}
		}
		return str;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public List getMembers() {
		return members;
	}
	public void setMembers(List members) {
		this.members = members;
	}
	
	
}
