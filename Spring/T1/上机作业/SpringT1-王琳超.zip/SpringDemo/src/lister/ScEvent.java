package lister;

import org.springframework.context.ApplicationEvent;

public class ScEvent extends ApplicationEvent{
	

	private String msg;
	public ScEvent(Object source) {
		super(source);
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
    
	
}
