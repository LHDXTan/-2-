package lister;

import org.springframework.context.ApplicationListener;

public class ScListener implements ApplicationListener<ScEvent> {

	@Override
	public void onApplicationEvent(ScEvent e) {
		 System.out.println("监听器：" + e.getSource());
	}

}
