package bean;

import java.util.List;

public class Party {
	private String topic;
	private List members;
	
	public List getMembers() {
		return members;
	}


	public void setMembers(List members) {
		this.members = members;
	}


	public Party(String topic){
		this.topic=topic;
	}
	
	
	public void printInfo(){
		if(members!=null){
			System.out.println(topic+"��������:"+members.size());
			for(Object o:members){
				System.out.println("\t"+o);
			}
			
		}else{
			System.out.println(topic+"��������: ����");
			
		}
		
		
		
	}

}
