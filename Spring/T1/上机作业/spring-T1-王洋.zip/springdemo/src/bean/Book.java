package bean;

public class Book {
	private String bname;
	private String zuoze;
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getZuoze() {
		return zuoze;
	}
	public void setZuoze(String zuoze) {
		this.zuoze = zuoze;
	}
	
	

}
