package bean;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class hellobean {
	private String[] booknames;
	private List list;
	private Map map;
	
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	public Map getMap() {
		return map;
	}
	public void setMap(Map map) {
		this.map = map;
	}
	public String[] getBooknames() {
		return booknames;
	}
	public void setBooknames(String[] booknames) {
		this.booknames = booknames;
	}

	public void sayhello(){
	 for(String s:booknames){
		 System.out.println("��ŵ������е�ֵ:"+s);
	 }
	 for(Object object:list){
		 Book book=(Book)object;
		 System.out.println("��ŵ�list�����е�ֵ:"+book.getBname()+" "+book.getZuoze());
	 }
	 Iterator iterator=map.keySet().iterator();
	 while(iterator.hasNext()){
		 Object object=iterator.next();
		 Book book=(Book) map.get(object);
		 System.out.println("��ŵ�map�е�ֵΪ:"+book.getBname()+" "+book.getZuoze());
	 }
	}
}
