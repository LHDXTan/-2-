package util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import bean.Party;

public class AppListener implements ApplicationListener {
	public void onApplicationEvent(ApplicationEvent arg0) {
		 if (arg0 instanceof ContextRefreshedEvent) {
			ContextRefreshedEvent new_name = (ContextRefreshedEvent) arg0;
			ApplicationContext new_nam=new_name.getApplicationContext();
			System.out.println("�������������¼���....");
			Party party=(Party) new_nam.getBean("party");
			if(party!=null){
				party.printInfo();
			}
		}
	}

}
