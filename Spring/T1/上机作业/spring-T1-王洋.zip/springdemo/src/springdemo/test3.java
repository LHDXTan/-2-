package springdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.hellobean;

public class test3 {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("/applicationContext.xml");
		hellobean hellobean=(bean.hellobean) applicationContext.getBean("hellobean");
		hellobean.sayhello();
	}

}
