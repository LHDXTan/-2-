package springdemo;

import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Party;

public class test1 {
	
	public static void main(String[] args){
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("/applicationContext.xml");
		Party party=(Party) applicationContext.getBean("party");
		party.printInfo();
	}
	
}