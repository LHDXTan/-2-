package spring_1;

import java.util.Date;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class text {
public static void main(String[] args) {
	  Resource   resource=new ClassPathResource("/applicationContext.xml");
BeanFactory	beanFactory= new XmlBeanFactory(resource);
HelloBean3 he= (HelloBean3)  beanFactory.getBean("helloBean3");
	he.prin();

	  
	  
}
	
	
	
	
}
