package spring_1;

import java.util.Date;

public class spring {
private String name;
private Date date;
//���캯��ע��
//public spring(String name,Date date){
//	this.name=name;
//	this.date=date;
//}




public String sayHello(){
	
	
	return name+"!"+date;
}
	//setget����
public String getName() {
	return name;
}
//����ע��
public void setName(String name) {
	this.name = name;
}
public Date getDate() {
	return date;
}
//����ע��
public void setDate(Date date) {
	this.date = date;
}



	
	
}
