package demo.bean;

import java.util.List;

public class Party {

	private String topic;//����
	private List members;//��Ա
//���캯��
	public Party(String topic){
		this.topic=topic;
	}
	
	public void printlnfo(){
		if(members!=null){
			System.out.println(topic+"��������:"+members.size());
			for(Object o:members){
				System.out.println("\t"+o);
			}
		}else{
			System.out.println(topic+"��������������");
		}
		
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public List getMembers() {
		return members;
	}

	public void setMembers(List members) {
		this.members = members;
	}
	
	
	
	
	
}
