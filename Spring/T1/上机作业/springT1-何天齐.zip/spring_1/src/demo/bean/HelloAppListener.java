package demo.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

public class HelloAppListener implements ApplicationListener{

	@Override
	public void onApplicationEvent(ApplicationEvent event) {
		// TODO Auto-generated method stub
		if(event instanceof ContextRefreshedEvent){
			ContextRefreshedEvent cse=(ContextRefreshedEvent) event;
			ApplicationContext appContext=cse.getApplicationContext();
			System.out.println("������,����������");
			  Party	party= (Party)appContext.getBean("party");
			
			
		}
		
	}

}
