package demo.bean;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.event.ContextRefreshedEvent;

public class HelloAppEvent extends ApplicationEvent{
	//�Զ����¼���
	public HelloAppEvent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}


	
		
	
}
