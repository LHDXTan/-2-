package demo.bean;

import java.util.List;

public class Party {
    private String topic;//主题
    private List members;//成员
    
    public Party(String topic){
    	this.topic=topic;
    }
    public void printlnfo(){
    	if(members!=null){
    		System.out.println(topic+"参与人数:"+members.size());
    		for(Object o:members){
    			System.out.println("\t"+o);
    		}
    	}else{
    		System.out.println(topic+"参与人数:"+"暂无");
    	}
    }
	public List getMembers() {
		return members;
	}
	public void setMembers(List members) {
		this.members = members;
	}
}
