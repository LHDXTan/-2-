package demo.bean;

import org.springframework.context.ApplicationEvent;

public class Ev extends ApplicationEvent {

	public Ev(Object source) {
		super(source);
	}

}
