package demo.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.event.ContextRefreshedEvent;

public class gathe{
	public static void main(String[] args) {
		if(event instanceof ContextRefreshedEvent){
			ContextRefreshedEvent cse = (ContextRefreshedEvent)event;
			ApplicationContext appContext = cse.getApplicationContext();
			
			Party party = (Party) appContext.getBean("party");
			if(party!=null){
				party.printlnfo();
			}
		}

	}

}
