package demo.bean;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

public class Li implements ApplicationListener<ApplicationEvent> {

	@Override
	public void onApplicationEvent(ApplicationEvent arg0) {
        if(arg0 instanceof  Ev){
        	Ev ev = (Ev)arg0;
        	   System.out.println(ev);
        	   System.out.println("成功监听！！！");
        }
//		arg0.getApplicationContext();
	}

}
