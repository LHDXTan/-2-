package demo.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class gath {
	public static void main(String[] args) {
//		ApplicationContext context = new ClassPathXmlApplicationContext("/applicationContext.xml");
//		HelloBean hello = (HelloBean) context.getBean("hello");
//		hello.sayHello();
		ApplicationContext context = new ClassPathXmlApplicationContext("/applicationContext.xml");
        Party party =(Party)context.getBean("party");
        party.printlnfo();
        context.publishEvent(new Ev("111"));
	}

}
