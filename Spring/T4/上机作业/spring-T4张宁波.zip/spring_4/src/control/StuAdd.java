package control;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import bean.Student;
import dao.IBaseDao;

public class StuAdd extends AbstractController {
	private IBaseDao basedao;
	
	
	
	public IBaseDao getBasedao() {
		return basedao;
	}



	public void setBasedao(IBaseDao basedao) {
		this.basedao = basedao;
	}



	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest arg0,
			HttpServletResponse arg1) throws Exception {
		// TODO Auto-generated method stub
		if(arg0.getMethod().equalsIgnoreCase("GET")){
			List deptlist=basedao.getObjList("from Dept");
			return new ModelAndView("stuadd","deptlist",deptlist);
		}else{
			Student stu=new Student();
			stu.setSname(arg0.getParameter("sname"));
			stu.setSsex(arg0.getParameter("ssex"));
			stu.setSbirthday(arg0.getParameter("sbirthday"));
			stu.setDid(Integer.parseInt(arg0.getParameter("did")));
			basedao.add(stu);
			arg1.sendRedirect(arg0.getContextPath()+"/stulist.sw");
			return null;
		}
		
	}

}
