package dao;

import java.io.Serializable;
import java.util.List;

import bean.Student;

public interface IBaseDao {

	public void add(Object obj);
	
	public void update(Object obj);
	
	public void delete(Object obj);
	
	public Object getList(Class clazz,Serializable id);
	
	public List getObjList(String sql);
	
	public Student selectByName(String uname,String pwd);
	
	public Object getObj(String sql);
	
}
