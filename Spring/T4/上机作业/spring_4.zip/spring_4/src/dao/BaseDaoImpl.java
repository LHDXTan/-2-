package dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import bean.Student;

public class BaseDaoImpl extends HibernateDaoSupport implements IBaseDao {

	@Override
	public void add(Object obj) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().save(obj);
	}

	@Override
	public void update(Object obj) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().update(obj);
	}

	@Override
	public void delete(Object obj) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().delete(obj);
	}

	@Override
	public Object getList(Class clazz, Serializable id) {
		// TODO Auto-generated method stub
		return super.getHibernateTemplate().get(clazz, id);
	}

	@Override
	public List getObjList(String sql) {
		// TODO Auto-generated method stub
		return super.getHibernateTemplate().find(sql);
	}

	@Override
	public Student selectByName(String uname, String pwd) {
		// TODO Auto-generated method stub
		return (Student) super.getHibernateTemplate().findByNamedQuery("from Student", uname);
	}

	@Override
	public Object getObj(String sql) {
		// TODO Auto-generated method stub
		return super.getHibernateTemplate().find(sql);
	}

	
	
}
