package bean;

import java.util.HashSet;
import java.util.Set;


public class Dept {

	private int did;
	private String dname;
	private Set<Student> emps=new HashSet<Student>();
	
	public Dept() {
	}
	
	
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}


	public Set<Student> getEmps() {
		return emps;
	}


	public void setEmps(Set<Student> emps) {
		this.emps = emps;
	}
	
	
}
