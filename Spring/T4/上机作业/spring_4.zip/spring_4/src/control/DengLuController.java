package control;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import bean.Student;
import dao.IBaseDao;

public class DengLuController extends AbstractController {

	private IBaseDao basedao;
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		List stulist=basedao.getObjList("from Student");
		String uname=request.getParameter("username");
		String pwd=request.getParameter("pwd");
		String sql="select s from Student s where sname="+"'"+uname+"'";
		List<Student>  stu=(List<Student>) basedao.getObj(sql);
		int i=0;
		request.getSession().setAttribute("i",i);
		i=(Integer) request.getSession().getAttribute("count");
		request.getSession().setAttribute("i", i);
		Date date=new Date();
		date.getTime();
		request.getSession().setAttribute("date", date.getTime());
		if(i<3){
			if(i==2){
				SimpleDateFormat sdf=new SimpleDateFormat("mm:ss");
				String dat=sdf.format(new Date());
				System.out.println(dat+"当前时间");
				request.getSession().setAttribute("dat",dat);
			}
			if(stu.size()!=0){
				if(uname.equals(stu.get(0).getSname())&&pwd.equals(stu.get(0).getPwd())){
					return new ModelAndView("stulist","stulist",stulist);
				}else{
					if(i<3){
						System.out.println(i+"错误次数");
						return new ModelAndView("index","error","用户名或密码错误");
					}
					
				}
			}else{
				return new ModelAndView("index","",null);
			}
		}else{
			SimpleDateFormat sdf=new SimpleDateFormat("mm:ss");
			String dat1=sdf.format(new Date());
			request.getSession().setAttribute("dat1", dat1);
			String d1=request.getSession().getAttribute("dat").toString();
			int date1=Integer.parseInt(dat1);
			int date2=Integer.parseInt(d1);
				return new ModelAndView("index","error1","该用户被锁定请2分钟后再登陆");
				/*if(dat1-d1){
					return new ModelAndView("index","error1","该用户被锁定请2分钟后再登陆");
				}else{
					i=0;
					return new ModelAndView("index","",null);
				}*/
				
		}
		
		return null;
			
			
		
	}
	
	
	public IBaseDao getBasedao() {
		return basedao;
	}
	public void setBasedao(IBaseDao basedao) {
		this.basedao = basedao;
	}

	
	
}
