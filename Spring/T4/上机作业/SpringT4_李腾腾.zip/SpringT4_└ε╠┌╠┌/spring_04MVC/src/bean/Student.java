package bean;

import javax.persistence.Table;


/**
 * Student entity. @author MyEclipse Persistence Tools
 */

@SuppressWarnings("serial")
@Table(name="STUDENT")
public class Student implements java.io.Serializable {

	// Fields

	private String sno;
	private String sname;
	private Integer sage;
	private String ssex;

	// Constructors

	/** default constructor */
	public Student() {
	}

	/** full constructor */
	public Student(String sname, Integer sage, String ssex) {
		this.sname = sname;
		this.sage = sage;
		this.ssex = ssex;
	}

	// Property accessors

	public String getSno() {
		return this.sno;
	}

	public void setSno(String sno) {
		this.sno = sno;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	

	public Integer getSage() {
		return sage;
	}

	public void setSage(Integer sage) {
		this.sage = sage;
	}

	public String getSsex() {
		return this.ssex;
	}

	public void setSsex(String ssex) {
		this.ssex = ssex;
	}

}