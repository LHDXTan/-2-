package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import bean.Student;
import dao.IBeandao;

public class StudentAddController extends AbstractController{

	private IBeandao deandao;
	
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest arg0,
			HttpServletResponse arg1) throws Exception {
        
		Student stu=new Student();
		
		String sage=arg0.getParameter("sage");
		int age=Integer.parseInt(sage);
		
		stu.setSname(arg0.getParameter("sname"));
	    stu.setSage(age);
	    stu.setSsex(arg0.getParameter("ssex"));
	    
		deandao.addstudent(stu);
		arg1.sendRedirect(arg0.getContextPath()+"/studentlist.sw");
		return null;
	}
	public IBeandao getDeandao() {
		return deandao;
	}
	public void setDeandao(IBeandao deandao) {
		this.deandao = deandao;
	}

	
}
