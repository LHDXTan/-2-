package controller;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.google.gson.Gson;

import dao.IBeandao;

public class StudentController extends AbstractController{

	private IBeandao basedao;
	
	@Override
    @ResponseBody 
	protected ModelAndView handleRequestInternal(HttpServletRequest arg0,
			HttpServletResponse arg1) throws Exception {

		List studentlist=basedao.studentlist("from Student");
		//创建输出流
	    HttpServletResponse response=ServletActionContext.getResponse();
	    response.setCharacterEncoding("utf-8");
		PrintWriter out=response.getWriter();

		Gson gson=new Gson();
		String papers=gson.toJson(studentlist);
		out.write(papers);
		out.flush();out.close();//好像没有用到ModelAndView？？？
		ModelAndView stu=new ModelAndView("student");
		stu.addObject(papers);
		
		return stu;
	}

	public IBeandao getBasedao() {
		return basedao;
	}

	public void setBasedao(IBeandao basedao) {
		this.basedao = basedao;
	}
	

	
}
