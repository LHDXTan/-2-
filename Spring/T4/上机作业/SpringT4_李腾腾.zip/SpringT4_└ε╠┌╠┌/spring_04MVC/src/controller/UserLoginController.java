package controller;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import bean.UserInfo;

public class UserLoginController  extends  AbstractController{

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String name=request.getParameter("name");
		String password=request.getParameter("password");
		
		/*UserInfo user=new UserInfo();
		
		user.setName(name);
		user.setPassword(password);*/
		
		if(name.equals("ttl") && password.equals("ttl")){
			 request.getSession().setAttribute("login", name);
			 return new ModelAndView("main");
		}else{

			return new ModelAndView("login","errorMsg","用户名或密码错误");
			
		}
		
		
		
	}

}
