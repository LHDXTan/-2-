package com.Ibatis.dao;

import java.util.List;

import com.Ibatis.pojo.EMP;
import com.Ibatis.pojo.Student;

public interface EMPDAO {
	
    public List findAllEmployee();
	
	public void updateEmployee(EMP emp);
	
	public void deleteEmployee(EMP emp);
	
	public Student findEmpById(Integer eid);
	
	public void saveEmployee(EMP emp);
}
