package com.Ibatis.daoImpl;

import java.sql.SQLException;
import java.util.List;

import com.Ibatis.Factory.SqlMapClientFactory;
import com.Ibatis.dao.EmployeeDAO;
import com.Ibatis.pojo.Student;
import com.ibatis.sqlmap.client.SqlMapClient;


public class EmployeeDAOImpl implements EmployeeDAO {

	public void deleteEmployee(Student student) {
		// TODO Auto-generated method stub
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		try {
			client.startTransaction();
			client.delete("deletestudent",student.getSno());
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
		
		
	}

	public List findAllEmployee() {
		// TODO Auto-generated method stub
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		List list= null;
		try {
			client.startTransaction();
			list=client.queryForList("querystudent");
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}	
		
		return list;
	}

	public void saveEmployee(Student student) {
		// TODO Auto-generated method stub
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		try {
			client.startTransaction();
			client.insert("insertstudent",student);
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
		
		
	}
	public void updateEmployee(Student student) {
		// TODO Auto-generated method stub
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		try {
			client.startTransaction();
			client.update("updatestudent",student);
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
		
		

	}

	@Override
	public Student findEmpById(Integer eid) {
		// TODO Auto-generated method stub
		return null;
	}





}
