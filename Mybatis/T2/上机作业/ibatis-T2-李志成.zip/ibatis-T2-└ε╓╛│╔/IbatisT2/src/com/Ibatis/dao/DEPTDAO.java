package com.Ibatis.dao;

import java.util.List;

import com.Ibatis.pojo.DEPT;
import com.Ibatis.pojo.EMP;
import com.Ibatis.pojo.Student;

public interface DEPTDAO {
	
	    public List findAllEmployee();
		
		public void updateEmployee(DEPT dept);
		
		public void deleteEmployee(DEPT dept);
		
		public Student findEmpById(Integer eid);
		
		public void saveEmployee(DEPT dept);

}
