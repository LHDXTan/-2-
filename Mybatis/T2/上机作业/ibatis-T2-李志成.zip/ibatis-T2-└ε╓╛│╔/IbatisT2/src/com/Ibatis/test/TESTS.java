package com.Ibatis.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.io.Reader;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import org.junit.Test;

import com.Ibatis.pojo.Student;
import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

public class TESTS extends TestCase{
	private  SqlMapClient sqlMapClient = null;
	@Test
	public void test() throws IOException {
		Reader reader = Resources.getResourceAsReader("SqlMapConfig.xml");
		sqlMapClient = SqlMapClientBuilder.buildSqlMapClient(reader);
		if(sqlMapClient!=null){
    		try{
    			List list=sqlMapClient.queryForList("querystudent");
    			for(Iterator iterator=list.iterator(); iterator.hasNext();){
    				Student student=(Student) iterator.next();
    				System.out.println(student.getSname());
    			}
    		}catch(Exception e){
    			e.printStackTrace();
    		}
    		
    	}
	}
}
