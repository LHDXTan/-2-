package com.Ibatis.pojo;

import java.util.HashSet;
import java.util.Set;

public class EMP {
	private Integer eid;
	private String ename;
	private String sex;
	private String hire;
	private String sar;
	private Integer did;
	private DEPT dept;
	
	
	public EMP(){
		
	}
	public EMP(Integer eid,String ename,String sex,String hire,String sar,Integer did){
		this.eid=eid;
		this.ename=ename;
		this.sex=sex;
		this.hire=hire;
		this.sar=sar;
		this.did=did;	
	}

	public Integer getEid() {
		return eid;
	}

	public void setEid(Integer eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getHire() {
		return hire;
	}

	public void setHire(String hire) {
		this.hire = hire;
	}

	public String getSar() {
		return sar;
	}

	public void setSar(String sar) {
		this.sar = sar;
	}

	public Integer getDid() {
		return did;
	}

	public void setDid(Integer did) {
		this.did = did;
	}
	public DEPT getDept() {
		return dept;
	}
	public void setDept(DEPT dept) {
		this.dept = dept;
	}



	
	

}
