package com.Ibatis.daoImpl;

import java.sql.SQLException;
import java.util.List;

import com.Ibatis.Factory.SqlMapClientFactory;
import com.Ibatis.dao.EMPDAO;
import com.Ibatis.pojo.EMP;
import com.Ibatis.pojo.Student;
import com.ibatis.sqlmap.client.SqlMapClient;

public class EMPDAOIMPL implements EMPDAO {

	public void deleteEmployee(EMP emp) {
		// TODO Auto-generated method stub
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		try {
			client.startTransaction();
			client.delete("ns_emp.deleteemp",emp.getEid());
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
		
		
	}

	public List findAllEmployee() {
		// TODO Auto-generated method stub
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		List list= null;
		try {
			client.startTransaction();
			list=client.queryForList("ns_emp.queryemp");
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}	
		
		return list;
	}

	public void saveEmployee(EMP emp) {
		// TODO Auto-generated method stub
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		try {
			client.startTransaction();
			client.insert("ns_emp.insertemp",emp);
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
		
		
	}
	public void updateEmployee(EMP emp) {
		// TODO Auto-generated method stub
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		try {
			client.startTransaction();
			client.update("ns_emp.updateemp",emp);
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
		
		

	}

	@Override
	public Student findEmpById(Integer eid) {
		// TODO Auto-generated method stub
		return null;
	}



}
