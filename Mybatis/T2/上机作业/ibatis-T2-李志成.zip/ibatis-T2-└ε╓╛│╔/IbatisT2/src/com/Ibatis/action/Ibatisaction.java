package com.Ibatis.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.Ibatis.dao.EmployeeDAO;
import com.Ibatis.daoImpl.DEPTDAOIMPL;
import com.Ibatis.daoImpl.EMPDAOIMPL;
import com.Ibatis.daoImpl.EmployeeDAOImpl;
import com.Ibatis.pojo.DEPT;
import com.Ibatis.pojo.EMP;
import com.Ibatis.pojo.Student;
import com.opensymphony.xwork2.ActionSupport;

public class Ibatisaction extends ActionSupport{
    private EmployeeDAOImpl dao = new EmployeeDAOImpl();
    private DEPTDAOIMPL deptdao = new DEPTDAOIMPL();
    private EMPDAOIMPL empdao = new EMPDAOIMPL();
    private List<Student> students;
    private Student student = new Student();
    private EMP emp;
    private List<EMP> emps;
    private DEPT dept= new DEPT();
    private List<DEPT> depts;
   
    //查询
	public String query(){		
		students=dao.findAllEmployee();
		for(Student s:students){
			System.out.println(s.getSname());
		}
		
		return null;
	}
	//添加
	public String add() throws IOException{	
		student.setSno("014");
		student.setSname("董兴旺");
		student.setSage(20);
		student.setSsex("男");
		dao.saveEmployee(student);
		return result();
	}
	//修改
	public String update() throws IOException{
		student.setSno("s011");
		student.setSname("董兴旺");
		student.setSage(21);
		student.setSsex("男");
		dao.updateEmployee(student);
		return result();
		
	}
	//删除
	public String delete() throws IOException{
		student.setSno("013");
		dao.deleteEmployee(student);
		return result();
	}
	
	  public String result() throws IOException{
		    HttpServletResponse response=ServletActionContext.getResponse();
			response.setContentType("text/html;charset=UTF-8");
			PrintWriter out=response.getWriter();
	 	    String result = "123";	    
			out.print(result);
			out.flush();
			out.close();
		    return null;
	  }
	  //查询员工信息
	  public String querydept(){
		  depts=deptdao.findAllEmployee();
		  emps=empdao.findAllEmployee();
		  return "emp";
	  }
	  //添加前查询部门
	  public String listdept(){
		  depts=deptdao.findAllEmployee();
		  return "add";
	  }
	  //添加
	  public String addemp(){
		  empdao.saveEmployee(emp);
		  return "tolist";
	  }
	  
	  
	public EmployeeDAOImpl getDao() {
		return dao;
	}
	public void setDao(EmployeeDAOImpl dao) {
		this.dao = dao;
	}
	public List<Student> getStudents() {
		return students;
	}
	public void setStudents(List<Student> students) {
		this.students = students;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public EMP getEmp() {
		return emp;
	}
	public void setEmp(EMP emp) {
		this.emp = emp;
	}
	public DEPT getDept() {
		return dept;
	}
	public void setDept(DEPT dept) {
		this.dept = dept;
	}
	public List<EMP> getEmps() {
		return emps;
	}
	public void setEmps(List<EMP> emps) {
		this.emps = emps;
	}
	public List<DEPT> getDepts() {
		return depts;
	}
	public void setDepts(List<DEPT> depts) {
		this.depts = depts;
	}
	public DEPTDAOIMPL getDeptdao() {
		return deptdao;
	}
	public void setDeptdao(DEPTDAOIMPL deptdao) {
		this.deptdao = deptdao;
	}
	public EMPDAOIMPL getEmpdao() {
		return empdao;
	}
	public void setEmpdao(EMPDAOIMPL empdao) {
		this.empdao = empdao;
	}

	
	
	
	
}
