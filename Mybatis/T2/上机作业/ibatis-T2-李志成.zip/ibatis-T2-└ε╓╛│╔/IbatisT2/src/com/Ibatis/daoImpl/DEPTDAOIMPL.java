package com.Ibatis.daoImpl;

import java.sql.SQLException;
import java.util.List;

import com.Ibatis.Factory.SqlMapClientFactory;
import com.Ibatis.dao.DEPTDAO;
import com.Ibatis.pojo.DEPT;
import com.Ibatis.pojo.EMP;
import com.Ibatis.pojo.Student;
import com.ibatis.sqlmap.client.SqlMapClient;

public class DEPTDAOIMPL implements DEPTDAO {

	public void deleteEmployee(DEPT dept) {
		// TODO Auto-generated method stub
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		try {
			client.startTransaction();
			client.delete("d_dept.deletedept",dept.getDid());
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
		
		
	}

	public List findAllEmployee() {
		// TODO Auto-generated method stub
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		List list= null;
		try {
			client.startTransaction();
			list=client.queryForList("ns_dept.querydept");
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}	
		
		return list;
	}

	public void saveEmployee(DEPT dept) {
		// TODO Auto-generated method stub
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		try {
			client.startTransaction();
			client.insert("d_dept.insertdept",dept);
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
		
		
	}
	public void updateEmployee(DEPT dept) {
		// TODO Auto-generated method stub
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		try {
			client.startTransaction();
			client.update("d_dept.updatedept",dept);
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
		
		

	}

	@Override
	public Student findEmpById(Integer eid) {
		// TODO Auto-generated method stub
		return null;
	}


}
