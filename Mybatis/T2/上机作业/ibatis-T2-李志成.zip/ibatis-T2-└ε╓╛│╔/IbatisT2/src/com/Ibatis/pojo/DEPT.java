package com.Ibatis.pojo;

import java.util.HashSet;
import java.util.Set;

public class DEPT {
	
	private Integer did;
	private String dname;
	private Integer manager;
	private String tel;
	private Integer master;
	private Set emp=new HashSet();
	public DEPT(){
		
	}
	
	public DEPT(Integer did,String dname,Integer manager,String tel,Integer master){
		this.did=did;
		this.dname=dname;
		this.manager=manager;
		this.tel=tel;
		this.master=master;
		
	}

	public Integer getDid() {
		return did;
	}

	public void setDid(Integer did) {
		this.did = did;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public Integer getManager() {
		return manager;
	}

	public void setManager(Integer manager) {
		this.manager = manager;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public Integer getMaster() {
		return master;
	}

	public void setMaster(Integer master) {
		this.master = master;
	}

	public Set getEmp() {
		return emp;
	}

	public void setEmp(Set emp) {
		this.emp = emp;
	}





	
	
}
