package pojo;

import java.util.HashSet;
import java.util.Set;

public class Grade  implements java.io.Serializable {

	private  int  gid;//班级id
	private  String gname;//班级名称
	
	//增加一个java.util.Set类型的属性students，表示与班级关联的学生对象集合
	private Set<Student> students =new HashSet();
	
	
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public Set<Student> getStudents() {
		return students;
	}
	public void setStudents(Set<Student> students) {
		this.students = students;
	}
	
	
	
	
}
