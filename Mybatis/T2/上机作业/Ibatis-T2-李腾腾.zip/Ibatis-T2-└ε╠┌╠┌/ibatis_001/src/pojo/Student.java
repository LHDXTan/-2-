package pojo;

import javax.persistence.Table;


/**
 * Student entity. @author MyEclipse Persistence Tools
 */

@SuppressWarnings("serial")
public class Student implements java.io.Serializable {

	// Fields

	private String sno;
	private String sname;
	private String sage;
	private String ssex;
	private String password; 
	//private int gid;//班级id
	
	private  Grade grade;//增加一个Grade类型的grade属性，表示与学生关联的班级对象

	// Constructors

	public Student() {
	}

	

	// Property accessors

	public Student(String sno, String sname, String sage, String ssex,
			String password) {
		super();
		this.sno = sno;
		this.sname = sname;
		this.sage = sage;
		this.ssex = ssex;
		this.password = password;
	}



	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSno() {
		return this.sno;
	}

	public void setSno(String sno) {
		this.sno = sno;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	

	

	public String getSage() {
		return sage;
	}



	public void setSage(String sage) {
		this.sage = sage;
	}



	public String getSsex() {
		return this.ssex;
	}

	public void setSsex(String ssex) {
		this.ssex = ssex;
	}



	public Grade getGrade() {
		return grade;
	}



	public void setGrade(Grade grade) {
		this.grade = grade;
	}
	

	public Student(String sno, String sname, String sage, String ssex,
			String password, Grade grade) {
		super();
		this.sno = sno;
		this.sname = sname;
		this.sage = sage;
		this.ssex = ssex;
		this.password = password;
		this.grade = grade;
	}

	


}