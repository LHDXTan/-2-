package factory;

import java.io.Reader;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

public class SqlMapClientFactory {
	
	private static SqlMapClient sqlMapClient = null;
	
	public synchronized static SqlMapClient getSqlMapClient(){
		if(sqlMapClient == null){			
			try{

				Reader reader = Resources.getResourceAsReader("SqlMapConfig.xml");
				System.out.println("2你好1");

				sqlMapClient = SqlMapClientBuilder.buildSqlMapClient(reader);	
				System.out.println("1你好1");

			}catch(Exception e){
				e.printStackTrace();
			}		
		}
		return sqlMapClient;
	}
	
	public static void main(String [] args){
		
		System.out.println(SqlMapClientFactory.getSqlMapClient());
		
	}
}
