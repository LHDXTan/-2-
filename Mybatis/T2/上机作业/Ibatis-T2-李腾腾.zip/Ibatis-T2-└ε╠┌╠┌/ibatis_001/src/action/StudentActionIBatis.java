package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.google.gson.Gson;

import dao.IBeandao;
import dao.ImpBeandao;
import pojo.Grade;
import pojo.Student;

public class StudentActionIBatis {
	private IBeandao ib=new ImpBeandao();
	private List studentlist;//student集合信息
	//属性
	private String sno;
	private String sname;
	private String sage;
	private String ssex;
	private String password;
	private int gid;//部门id
	
	//列表显示
	public void studentList() throws IOException{
		
		studentlist=ib.querystudent();
		//创建输出流
	    HttpServletResponse response=ServletActionContext.getResponse();

	    response.setCharacterEncoding("utf-8");
	    
		PrintWriter out=response.getWriter();

		Gson gson=new Gson();
		
		
		String papers=gson.toJson(studentlist);
		
		out.write(papers);
		out.flush();
		out.close();
		
		
	}
	
	//人员添加和修改(为什么添加不上?答案：应该指定序列suqence)
	public void studentAdd() throws IOException{
		
		if( sno==null || sno.equals("")){
			//添加(ibatis如何使oracle自动增长序列（触发器？？？）)

			Student student1=new Student();
			
            Grade grade=new Grade();
            grade.setGid(gid);
            
			student1.setPassword(password);
			student1.setSage(sage);
			student1.setSname(sname);
			student1.setSsex(ssex);
			
			student1.setGrade(grade);
						
			ib.saveStudent(student1);;	
		}else{
			//修改
			Student student=new Student();
			
			 Grade grade=new Grade();
	         grade.setGid(gid);
	         
	        student.setGrade(grade);
			student.setSno(sno);
			student.setSage(sage);
			student.setSname(sname);
			student.setSsex(ssex);
			student.setPassword(password);
			ib.updateStudent(student);
		}
		
		//创建输出流
	    HttpServletResponse response=ServletActionContext.getResponse();
	    response.setCharacterEncoding("utf-8");
		PrintWriter out=response.getWriter();
		out.write("ok");
		out.flush();
		out.close();
		
	}
	
	//删除
	public void deletestudent() throws IOException{

		Student  student =new Student();
		student.setSno(sno);
		ib.deleteStudent(student);
		
		//创建输出流
	    HttpServletResponse response=ServletActionContext.getResponse();
	    response.setCharacterEncoding("utf-8");
		PrintWriter out=response.getWriter();
		int a=1;
		out.println(a);
		out.flush();
		out.close();
		
	}

	
	public void gradelist() throws IOException{
		List gradelist=ib.gradeList();
		
		//创建输出流
	    HttpServletResponse response=ServletActionContext.getResponse();
	    response.setCharacterEncoding("utf-8");
		PrintWriter out=response.getWriter();

		Gson gson=new Gson();
		String grades=gson.toJson(gradelist);
		out.write(grades);
		out.flush();
		out.close();
		
	}
	//get和set方法
	public List getStudentlist() {
		return studentlist;
	}

	public void setStudentlist(List studentlist) {
		this.studentlist = studentlist;
	}

	public String getSno() {
		return sno;
	}

	public void setSno(String sno) {
		this.sno = sno;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	

	public String getSage() {
		return sage;
	}

	public void setSage(String sage) {
		this.sage = sage;
	}

	public String getSsex() {
		return ssex;
	}

	public void setSsex(String ssex) {
		this.ssex = ssex;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getGid() {
		return gid;
	}

	public void setGid(int gid) {
		this.gid = gid;
	}

	
	
    
}


