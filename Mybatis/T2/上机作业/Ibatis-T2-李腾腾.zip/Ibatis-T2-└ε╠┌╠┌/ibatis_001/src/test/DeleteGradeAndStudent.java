package test;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import pojo.Grade;
import pojo.Student;

import com.ibatis.sqlmap.client.SqlMapClient;

import factory.SqlMapClientFactory;

public class DeleteGradeAndStudent {

	public static void main(String[] args) {
		
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		Integer g=new Integer(1);
		
		try {
			client.delete("ns_grade.deleteGradeAndStudent", g);
			
			try {
				
				List gradelist=client.queryForList("ns_grade.queryGradeAndStudent");//并没有删除student表信息
				
				for(int i=0;i<gradelist.size();i++){

					Grade grades=(Grade) gradelist.get(i);			
					//注意key值的 大小写
					System.out.println("删除后班级名称："+grades.getGname()+"....学生：");
					
					 Set<Student> students = (Set<Student>)grades.getStudents(); 
					
		                Iterator ite = students.iterator();  
		                while(ite.hasNext()){  
		                	Student stu = (Student)ite.next();  
		                    System.out.println("学生姓名:"+stu.getSname()+",性别: "+stu.getSsex());  
		                }  
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
