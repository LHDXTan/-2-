package test;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import factory.SqlMapClientFactory;

public class testGradeNum {

 
	public static void main(String [] args){
		
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		
		try {
			
			List list=client.queryForList("graders.queryGrade");
			
			for(int i=0;i<list.size();i++){

				HashMap gradeinfo=(HashMap)list.get(i);
				
				//注意key值的 大小写
				System.out.println("班级名称："+gradeinfo.get("BGNAME")+"....人数："+gradeinfo.get("SCOUNT"));
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
}
