package dao;

import java.util.List;

import pojo.Student;



public interface IBeandao {
	
	//信息显示
	public List querystudent();
	
	//修改
    public void updateStudent(Student student);
	//删除
	public void deleteStudent(Student student);
	
	//添加
	public void saveStudent(Student student);

	//部门下拉框集合
	public List gradeList();
	
	
}
