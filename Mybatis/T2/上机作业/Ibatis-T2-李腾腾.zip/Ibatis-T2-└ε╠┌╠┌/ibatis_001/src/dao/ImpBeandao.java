package dao;


import java.sql.SQLException;
import java.util.List;

import pojo.Student;

import com.ibatis.sqlmap.client.SqlMapClient;

import factory.SqlMapClientFactory;





public class ImpBeandao  implements IBeandao {

	//信息显示
	public List querystudent() {
		
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();//

		List list=null;
		try {

			client.startTransaction();;//开启事务(必须有关闭事务)

			list=client.queryForList("ns_student.queryStudent");

		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				client.endTransaction();//关闭事务
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return list;
	}

	
	//修改
	public void updateStudent(Student student) {

		 SqlMapClient client =SqlMapClientFactory.getSqlMapClient();
	      
	      try {
	    	  
			client.startTransaction();//开启事务
			client.update("ns_student.updateStudent",student);
			client.commitTransaction();//提交事务
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				client.endTransaction();//关闭事务
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		};//开启事务(必须有关闭事务)
			
	}

	@Override
	//删除
	public void deleteStudent(Student student) {
		 SqlMapClient client =SqlMapClientFactory.getSqlMapClient();
	      
	      try {
	    	  
			client.startTransaction();
			
			client.delete("ns_student.deleteStudent",student.getSno());
			client.commitTransaction();//
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		};//开启事务(必须有关闭事务)
			
	}
	@Override
	//添加
	public void saveStudent(Student student) {
		
      SqlMapClient client =SqlMapClientFactory.getSqlMapClient();
      
      try {
    	  
		client.startTransaction();
		client.insert("ns_student.insertStudent",student);
		client.commitTransaction();//
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		try {
			client.endTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	};//开启事务(必须有关闭事务)
		
	}


    //部门集合
	public List gradeList() {

		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();//

		List list=null;
		try {

			client.startTransaction();;//开启事务(必须有关闭事务)

			list=client.queryForList("ns_grade.queryGradeList");

		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				client.endTransaction();//关闭事务
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}


   
}
