package com.tsing.dao;

import java.util.List;

import com.tsing.pojo.Emp;

public interface EmpDao {

	
public List findAllEmp();
	
	public void updateEmployee(Emp emp);
	
	public void deleteEmployee(Emp emp);
	
	public Emp findEmpById(Integer eid);
	
	public void saveEmp(Emp emp);
	
	public List findByEmpDy(Emp emp);
	
	
}
