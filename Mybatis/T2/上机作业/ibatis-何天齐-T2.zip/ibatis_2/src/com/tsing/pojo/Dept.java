package com.tsing.pojo;

import java.util.HashSet;
import java.util.Set;

public class Dept implements java.io.Serializable{
	private Integer did;
	private String dname;
	private String loc;
	private Set emps = new HashSet();
	
	public Integer getDid() {
		return did;
	}
	public void setDid(Integer did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public Set getEmps() {
		return emps;
	}
	public void setEmps(Set emps) {
		this.emps = emps;
	}
}
