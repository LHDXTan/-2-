package com.tsing.action;

import java.util.List;

import com.opensymphony.xwork2.ActionSupport;
import com.tsing.dao.DeptDao;
import com.tsing.dao.DeptDaoimpl;
import com.tsing.dao.EmpDao;
import com.tsing.dao.EmpDaoimpl;
import com.tsing.pojo.Dept;
import com.tsing.pojo.Emp;

public class EmpAction extends ActionSupport{
private Emp emp;
//������list���󣬰Ѳ�ѯ����浽list����
private List list_emp;
private List list_dept;
	

private EmpDao emdao =new EmpDaoimpl();
	private DeptDao deddao=new DeptDaoimpl();
	
	//��ѯemp����dept��������浽list����
	
	public String listemp(){
		
		System.out.println("���뷽����2");
		list_emp=emdao.findAllEmp();
		list_dept=deddao.findAlldept();
		System.out.println("����"+list_emp);
		
		System.out.println("����"+list_dept);
		
		
		return "listemp";
	}
	
	
	public String toaddemp(){
		list_dept=	deddao.findAlldept();
		
		
		return "addemp";
	}
	//����
	public String addemp(){
		if(emp==null){
			emdao.saveEmp(emp);
			
			return "tolist";
		}else 
			
			
			return ActionSupport.ERROR;
		
		
		
	}
	
	
	
	
	
	
	public String findEmpByDy(){
		
		System.out.println("����findEmpByDy�������");
		list_dept=deddao.findAlldept();
		list_emp=emdao.findByEmpDy(emp);
		System.out.println(list_dept);
		System.out.println(list_emp);
		
		return "listemp";
	}
	
	
	
//setget����
	public Emp getEmp() {
		return emp;
	}

	public void setEmp(Emp emp) {
		this.emp = emp;
	}

	public List getList_emp() {
		return list_emp;
	}

	public void setList_emp(List list_emp) {
		this.list_emp = list_emp;
	}

	public List getList_dept() {
		return list_dept;
	}

	public void setList_dept(List list_dept) {
		this.list_dept = list_dept;
	}

	public EmpDao getEmdao() {
		return emdao;
	}

	public void setEmdao(EmpDao emdao) {
		this.emdao = emdao;
	}

	public DeptDao getDeddao() {
		return deddao;
	}

	public void setDeddao(DeptDao deddao) {
		this.deddao = deddao;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
