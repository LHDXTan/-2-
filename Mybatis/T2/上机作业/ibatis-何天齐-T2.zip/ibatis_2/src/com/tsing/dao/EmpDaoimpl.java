package com.tsing.dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.tsing.factory.SqlMapClientFactory;
import com.tsing.pojo.Emp;

public class EmpDaoimpl implements EmpDao{

	@Override
	
	public List findAllEmp() {
		
		System.out.println("���뷽����1");
		//ʹ�ù����ഴ��SqlMap����
		SqlMapClient client=	SqlMapClientFactory.getSqlMapClient();
		List list= null;
		
		try {
			//��������
			client.startTransaction();
			//���ñ�дsql���ķ���
			client.queryForList("ns_emp.queryEmployee");
			//�ύ����
			client.commitTransaction();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				//��������
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}	
		
		
		
		return list;
		
	}

	@Override
	
	
	//�޸�
	public void updateEmployee(Emp emp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	//ɾ��
	public void deleteEmployee(Emp emp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Emp findEmpById(Integer eid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	//����
	public void saveEmp(Emp emp) {
		// TODO Auto-generated method stub
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();
		try {
			client.startTransaction();
			client.insert("ns_emp.insertEmployee",emp);
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{			
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
		
	}

	@Override
	public List findByEmpDy(Emp emp) {
		//ʹ�ù����ഴ��SqlMap����
				SqlMapClient client=	SqlMapClientFactory.getSqlMapClient();
				List list= null;
				
				try {
					//��������
					client.startTransaction();
					//���ñ�дsql���ķ���
					client.queryForList("ns_emp.queryEmpDynamic",emp);
					//�ύ����
					client.commitTransaction();
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally{			
					try {
						//��������
						client.endTransaction();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}}	
		return null;
	}

}
