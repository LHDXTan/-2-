package com.tsing.dao;

import java.util.List;

public interface DeptDao {
	public List findAlldept();
}
