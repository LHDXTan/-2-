package com.tsing.test;

import java.io.Reader;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;
import com.tsing.pojo.Emp;




public class testIbatisCase extends TestCase {

	private SqlMapClient sqlMapClient = null;

	protected void setUp() throws Exception {
		Reader reader = Resources.getResourceAsReader("SqlMapConfig.xml");
		sqlMapClient = SqlMapClientBuilder.buildSqlMapClient(reader);
	}

//	public void testQuery() {
//		if (sqlMapClient != null) {
//
//			try {
//				List list = sqlMapClient.queryForList("ns_emp.queryEmployeeInfo");
//				
//				for(int i=0;i<list.size();i++){
//					HashMap deptInfo=(HashMap) list.get(i);
//					System.out.println(deptInfo.size());
//					System.out.println("�������ƣ�"+deptInfo.get("dname")+"������"+deptInfo.get("d_count"));
//
//				}
//			} catch (SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//	}
	
	
	
	
	
//	//��ѯemp��
	public void testQuery() {
		if (sqlMapClient != null) {

			try {
				List list = sqlMapClient.queryForList("ns_emp.queryEmployee");				
				for (Iterator iterator = list.iterator(); iterator.hasNext();) {
					Emp employee = (Emp) iterator.next();
					// �������
//					System.out.println(employee.getEname() + " - ");
					System.out.println(employee.getEname() + " - ");
						System.out.println(employee.getDepartment().getDname() + " - ");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	
	
}
