package factory;

import java.io.Reader;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

public class SqlMapClientFactory {
	
	private static SqlMapClient sqlMapClient = null;
	
	public synchronized static SqlMapClient getSqlMapClient(){
		if(sqlMapClient == null){			
			try{
				
				System.out.println("你好呀");
				Reader reader = Resources.getResourceAsReader("SqlMapConfig.xml");
				System.out.println("你好呀2");
				sqlMapClient = SqlMapClientBuilder.buildSqlMapClient(reader);			
			}catch(Exception e){
				e.printStackTrace();
			}		
		}
		return sqlMapClient;
	}
	
	public static void main(String [] args){
		
		System.out.println(SqlMapClientFactory.getSqlMapClient());
		
	}
}
