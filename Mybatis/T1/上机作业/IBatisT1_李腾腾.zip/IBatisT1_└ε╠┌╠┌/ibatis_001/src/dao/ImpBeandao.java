package dao;


import java.sql.SQLException;
import java.util.List;

import pojo.Student;

import com.ibatis.sqlmap.client.SqlMapClient;

import factory.SqlMapClientFactory;





public class ImpBeandao  implements IBeandao {

	//信息显示
	public List querystudent() {
		SqlMapClient client=SqlMapClientFactory.getSqlMapClient();//
		List list=null;
		try {
			client.startTransaction();;//开启事务(必须有关闭事务)
			list=client.queryForList("queryStudent");
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				client.endTransaction();//关闭事务
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return list;
	}

	
	//修改
	public void updateStudent(Student student) {

		 SqlMapClient client =SqlMapClientFactory.getSqlMapClient();
	      
	      try {
	    	  
			client.startTransaction();
			client.update("updateStudent",student);
			client.commitTransaction();//
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		};//开启事务(必须有关闭事务)
			
	}

	@Override
	//删除
	public void deleteStudent(Student student) {
		 SqlMapClient client =SqlMapClientFactory.getSqlMapClient();
	      
	      try {
	    	  
			client.startTransaction();
			
			client.delete("deleteStudent",student.getSno());
			client.commitTransaction();//
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		};//开启事务(必须有关闭事务)
			
	}
	@Override
	//添加
	public void saveStudent(Student student) {
		
      SqlMapClient client =SqlMapClientFactory.getSqlMapClient();
      
      try {
    	  
		client.startTransaction();
		client.insert("insertStudent",student);
		client.commitTransaction();//
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		try {
			client.endTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	};//开启事务(必须有关闭事务)
		
	}


   
}
