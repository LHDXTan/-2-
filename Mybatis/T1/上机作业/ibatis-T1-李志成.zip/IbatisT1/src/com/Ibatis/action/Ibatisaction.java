package com.Ibatis.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.Ibatis.dao.EmployeeDAO;
import com.Ibatis.daoImpl.EmployeeDAOImpl;
import com.Ibatis.pojo.Student;
import com.opensymphony.xwork2.ActionSupport;

public class Ibatisaction extends ActionSupport{
    private EmployeeDAOImpl dao = new EmployeeDAOImpl();
    private List<Student> students;
    private Student student = new Student();
    //查询
	public String query(){		
		students=dao.findAllEmployee();
		for(Student s:students){
			System.out.println(s.getSname());
		}
		
		return null;
	}
	//添加
	public String add() throws IOException{	
		student.setSno("014");
		student.setSname("董兴旺");
		student.setSage(20);
		student.setSsex("男");
		dao.saveEmployee(student);
		return result();
	}
	//修改
	public String update() throws IOException{
		student.setSno("s011");
		student.setSname("董兴旺");
		student.setSage(21);
		student.setSsex("男");
		dao.updateEmployee(student);
		return result();
		
	}
	//删除
	public String delete() throws IOException{
		student.setSno("013");
		dao.deleteEmployee(student);
		return result();
	}
	
	  public String result() throws IOException{
		    HttpServletResponse response=ServletActionContext.getResponse();
			response.setContentType("text/html;charset=UTF-8");
			PrintWriter out=response.getWriter();
	 	    String result = "123";	    
			out.print(result);
			out.flush();
			out.close();
		    return null;
	  }
	  
	public EmployeeDAOImpl getDao() {
		return dao;
	}
	public void setDao(EmployeeDAOImpl dao) {
		this.dao = dao;
	}
	public List<Student> getStudents() {
		return students;
	}
	public void setStudents(List<Student> students) {
		this.students = students;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	
	
	
	
}
