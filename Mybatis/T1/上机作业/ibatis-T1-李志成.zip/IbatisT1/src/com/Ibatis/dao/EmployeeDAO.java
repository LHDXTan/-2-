package com.Ibatis.dao;

import java.util.List;

import com.Ibatis.pojo.Student;


public interface EmployeeDAO {

	public List findAllEmployee();
	
	public void updateEmployee(Student student);
	
	public void deleteEmployee(Student student);
	
	public Student findEmpById(Integer sno);
	
	public void saveEmployee(Student student);
}
