package com.tsing.factory;

import java.io.Reader;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;
//SqlMapClient������

public class SqlMapClientFactory {
	private static SqlMapClient sqlMapClient = null;
	
	public synchronized static SqlMapClient getSqlMapClient(){
		if(sqlMapClient == null){			
			try{
				Reader reader = Resources.getResourceAsReader("SqlMapConfig.xml");
				sqlMapClient = SqlMapClientBuilder.buildSqlMapClient(reader);			
			}catch(Exception e){
				e.printStackTrace();
			}		
		}
		return sqlMapClient;
	}
}
