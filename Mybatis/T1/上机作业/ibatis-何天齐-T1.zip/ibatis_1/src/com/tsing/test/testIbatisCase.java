package com.tsing.test;

import java.io.Reader;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import com.tsing.pojo.Login;

public class testIbatisCase extends TestCase {

	private SqlMapClient sqlMapClient = null;

	protected void setUp() throws Exception {
		Reader reader = Resources.getResourceAsReader("SqlMapConfig.xml");
		sqlMapClient = SqlMapClientBuilder.buildSqlMapClient(reader);
	}

	public void testQuery() {
		if (sqlMapClient != null) {

			try {
				List list = sqlMapClient.queryForList("queryEmployee");
				for (Iterator iterator = list.iterator(); iterator.hasNext();) {
					Login login = (Login) iterator.next();
					// �������
					System.out.println(login.getName() + " - ");

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
