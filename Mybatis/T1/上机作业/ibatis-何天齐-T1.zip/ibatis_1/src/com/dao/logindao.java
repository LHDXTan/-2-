package com.dao;

import java.util.List;






import com.tsing.pojo.Login;



public interface logindao {
//��ѯ
	public List loginlist();
	//����
	public void saveLogin(Login login);
	//ɾ��
	public void deleteLogin(Integer id);
	//��ȡid
	public Login findEmpById(Class clazz,Integer id);
	//�޸�
	public void updateLogin(Login login);
}
