package com.action;

import java.util.List;

import com.dao.logindaoimpl;
import com.opensymphony.xwork2.ActionSupport;
import com.tsing.pojo.Login;

public class LoginAction extends ActionSupport{

logindaoimpl dao=new logindaoimpl();	





private Login login;	

private List loginlist;

//��ѯ����
public String list(){
	System.out.println("�����ѯ����");
	loginlist=dao.loginlist();
	
	
	
	return "list";
}
//���ӷ���
public String add(){
	System.out.println("�������ӷ���");

	
	dao.saveLogin(login);
	
	return "tolist";
}
//��ȡ�޸ĵ�id
public String toupdate(){
	System.out.println("��ȡ�޸ĵ�id"+login.getId());

	login =dao.findEmpById(Login.class,login.getId());
	return "update";
}


//�޸�
public String update(){	
	System.out.println("�����޸ķ���");
	
	
   dao.updateLogin(login);
	
	
	return "tolist";
}




//ɾ������
public String delete(){
	System.out.println("����ɾ������");
	dao.deleteLogin(login.getId());

	
	return "tolist";
}







public logindaoimpl getDao() {
	return dao;
}
public void setDao(logindaoimpl dao) {
	this.dao = dao;
}
public Login getLogin() {
	return login;
}
public void setLogin(Login login) {
	this.login = login;
}
public List getLoginlist() {
	return loginlist;
}
public void setLoginlist(List loginlist) {
	this.loginlist = loginlist;
}



}
