package factory;

import java.io.IOException;
import java.io.Reader;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

public class SqlMapClientFactory {
	private static SqlMapClient sqlMapClient=null;
	
	public synchronized static SqlMapClient getSqlMapClient(){
		if(sqlMapClient==null){
			Reader reader;
			try {
				reader = com.ibatis.common.resources.Resources.getResourceAsReader("SqlMapConfig.xml");
				sqlMapClient=SqlMapClientBuilder.buildSqlMapClient(reader);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return sqlMapClient;
		
	}
	
	
	

}
