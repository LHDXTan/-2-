package dao;

import java.util.List;

import pojo.Emp;

public interface IEmpDao {
	
	public List getList();

	public void insertEmp(Emp e);

	public void updateEmp(Emp emp);

	public void deleteEmp(Emp e);

}
