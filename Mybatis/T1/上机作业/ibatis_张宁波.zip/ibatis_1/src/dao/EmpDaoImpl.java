package dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import pojo.Emp;

import com.ibatis.sqlmap.client.SqlMapClient;

import factory.SqlMapClientFactory;

public class EmpDaoImpl implements IEmpDao {

	@Override
	public List getList() {
		// TODO Auto-generated method stub
		SqlMapClient sqlmapClient=SqlMapClientFactory.getSqlMapClient();
		List list=new ArrayList();
		try {
			sqlmapClient.startTransaction();
			list=sqlmapClient.queryForList("queryEmp","emp");
			sqlmapClient.commitTransaction();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				sqlmapClient.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return list;
	}

	@Override
	public void insertEmp(Emp e) {
		// TODO Auto-generated method stub
		SqlMapClient sqlmapClient=SqlMapClientFactory.getSqlMapClient();
		try {
			sqlmapClient.startTransaction();
			sqlmapClient.insert("insertEmp", e);
			sqlmapClient.commitTransaction();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally{
			try {
				sqlmapClient.endTransaction();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		
	}

	@Override
	public void updateEmp(Emp emp) {
		SqlMapClient sqlmapClient=SqlMapClientFactory.getSqlMapClient();
		try {
			sqlmapClient.startTransaction();
			sqlmapClient.update("updateEmp",emp);
			sqlmapClient.commitTransaction();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally{
			try {
				sqlmapClient.endTransaction();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}

	@Override
	public void deleteEmp(Emp e) {
		// TODO Auto-generated method stub
		SqlMapClient sqlmapClient=SqlMapClientFactory.getSqlMapClient();
		try {
			sqlmapClient.startTransaction();
			sqlmapClient.delete("deleteEmp",e.getEid());
			sqlmapClient.commitTransaction();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally{
			try {
				sqlmapClient.endTransaction();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
}
