package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import pojo.Emp;

import com.google.gson.Gson;
import com.opensymphony.xwork2.ActionSupport;

import dao.EmpDaoImpl;
import dao.IEmpDao;

public class EmpAction extends ActionSupport {

	static IEmpDao idao=new EmpDaoImpl();
	private static List list=new ArrayList();
	
	private Emp emp;
	private int eid;
	private String ename;
	private String pwd;
	private String birthday;
	private int did;
	
	
	
	
	public static String getEmpList(){
		System.out.println("sss");
		list=idao.getList();
		Gson gs=new Gson();
		String s=gs.toJson(list);
		HttpServletResponse response=ServletActionContext.getResponse();
		response.setCharacterEncoding("UTF-8");
		try {
			PrintWriter out=response.getWriter();
			out.write(s);
			out.flush();
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "list";
		
	}
	
	public String add(){
		Emp e=new Emp();
		e.setEname(ename);
		e.setBirthday(birthday);
		e.setPwd(pwd);
		e.setDid(did);
		if(eid!=0){
			e.setEid(eid);
			idao.updateEmp(e);
		}else{
		idao.insertEmp(e);
		}
		return "list";
		
	}

	public String selectUserById(){
		Emp e=new Emp();
		/*e=idao.updateEmp(emp);*/
		return "list";
		
	}

	public String delete(){
		Emp e=new Emp();
		e.setEid(eid);
		idao.deleteEmp(e);
		EmpAction.getEmpList();
		return "list";
		
	}


	public List getList() {
		return list;
	}


	public void setList(List list) {
		this.list = list;
	}

	public Emp getEmp() {
		return emp;
	}

	public void setEmp(Emp emp) {
		this.emp = emp;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	
	
	
	
}
