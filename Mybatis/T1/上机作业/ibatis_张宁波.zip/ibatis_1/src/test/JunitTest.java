package test;

import java.io.Reader;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import pojo.Emp;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import junit.framework.TestCase;

public class JunitTest extends TestCase {

	private SqlMapClient sqlMapClient=null;
	
	protected void setUp() throws Exception{
		Reader reader=com.ibatis.common.resources.Resources.getResourceAsReader("SqlMapConfig.xml");
		sqlMapClient=SqlMapClientBuilder.buildSqlMapClient(reader);
	}
	
	public void testQuery(){
		if(sqlMapClient!=null){
			try {
				List list=sqlMapClient.queryForList("queryEmp");
				for(Iterator it=list.iterator();it.hasNext();){
					Emp emplist=(Emp) it.next();
					System.out.println(emplist.getEname());
				}
			} catch (SQLException e) {
				
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
