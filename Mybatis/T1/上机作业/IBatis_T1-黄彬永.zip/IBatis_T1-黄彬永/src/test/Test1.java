package test;

import java.io.Reader;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import pojo.Student;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import junit.framework.TestCase;

public class Test1 extends TestCase {

	private SqlMapClient client=null;
	@Before
	protected void setUp() throws Exception {
		Reader reader = Resources.getResourceAsReader("SqlMapConfig.xml");
		client = SqlMapClientBuilder.buildSqlMapClient(reader);
	}

	@Test
	public void test() {
		if(client!=null){
			try {
				List list = client.queryForList("queryStudent");
				for(Iterator iterator = list.iterator();iterator.hasNext();){
					Student student = (Student) iterator.next();
					System.out.println("姓名:"+student.getSname()+"  "+"性别:"+student.getSex()+"  "+"年龄:"+student.getAge());
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
 		}
	}

}
