package dao;

import java.util.List;

import pojo.Student;

public interface IStudentDao {

	public List<Student> stulist();
	
	public void addstudent(Student student);
	
	public Student getStuById(Integer sid);
	
	public void updatestudent(Student student);
	
	public void deletestudent(Student student);
}
