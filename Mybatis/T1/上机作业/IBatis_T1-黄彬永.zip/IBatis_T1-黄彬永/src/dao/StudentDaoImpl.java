package dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import factory.SqlMapClientFactory;
import pojo.Student;

public class StudentDaoImpl implements IStudentDao {

	@Override
	public List<Student> stulist() {
		SqlMapClient client = SqlMapClientFactory.getSqlMapClient();
		List list =null;
		try {
			client.startTransaction();				//开始事务
			list = client.queryForList("queryStudent");
			client.commitTransaction();				//提交事务
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				client.endTransaction();			//关闭事务
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
 		return list;
	}

	@Override
	public void addstudent(Student student) {
		// TODO Auto-generated method stub

		SqlMapClient client = SqlMapClientFactory.getSqlMapClient();
		try {
			client.startTransaction();
			client.insert("insertStudent", student);
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public Student getStuById(Integer sid){
		SqlMapClient client = SqlMapClientFactory.getSqlMapClient();
		Student student = null;
		try {
			client.startTransaction();
			student=(Student) client.queryForObject("queryStuById",sid);
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return student;
	}
	
	@Override
	public void updatestudent(Student student) {
		// TODO Auto-generated method stub
		SqlMapClient client = SqlMapClientFactory.getSqlMapClient();
		try {
			client.startTransaction();
			client.update("updateStudent", student);
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public void deletestudent(Student student) {
		// TODO Auto-generated method stub
		SqlMapClient client = SqlMapClientFactory.getSqlMapClient();
		try {
			client.startTransaction();
			client.delete("deleteStudent",student.getSid());
			client.commitTransaction();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				client.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
