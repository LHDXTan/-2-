package action;

import java.util.List;

import pojo.Student;

import com.opensymphony.xwork2.ActionSupport;

import dao.IStudentDao;
import dao.StudentDaoImpl;

public class StudentAction extends ActionSupport {

	private Student student;
	private List<Student> studentlist;
	private IStudentDao studentdao = new StudentDaoImpl();
	
	public String list(){
		studentlist = studentdao.stulist();
		return "list";
	}
	public String add(){
		studentdao.addstudent(student);
		return "tolist";
	}
	public String selectStuById(){
		student = studentdao.getStuById(student.getSid());
		return "toupdate";
	}
	public String update(){
		studentdao.updatestudent(student);
		return "tolist";
	}
	public String delete(){
		studentdao.deletestudent(student);
		return "tolist";
	}
	
	
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public List<Student> getStudentlist() {
		return studentlist;
	}
	public void setStudentlist(List<Student> studentlist) {
		this.studentlist = studentlist;
	}

}
