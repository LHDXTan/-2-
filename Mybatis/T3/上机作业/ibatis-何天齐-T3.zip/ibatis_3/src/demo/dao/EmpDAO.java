package demo.dao;


import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;


import demo.bean.Employee;

public class EmpDAO extends SqlMapClientDaoSupport implements IEmpDAO{
	//添加
	public int add(Employee emp) {
		//调用本类的add方法，把添加的数据放到emp封装类里面
		super.getSqlMapClientTemplate().insert("Employee.add",emp);
		return 1;
	}
//删除
	public int delete(Employee emp) {
		super.getSqlMapClientTemplate().delete("Employee.delete",emp);
		return 1;
	}
	
	
	public Object getObjectById(Integer id) {
		return super.getSqlMapClientTemplate().queryForObject("Employee.selectById",id);		
	}
//查询emp表
	public List getObjects() {
		return super.getSqlMapClientTemplate().queryForList("Employee.selectAll");					
	}
			
	
//模糊查询
	public List getObjects(Employee emp) {
		return super.getSqlMapClientTemplate().queryForList("Employee.selectByNameAndDept",emp);	
	}
//修改
	public int update(Employee emp) {
		super.getSqlMapClientTemplate().update("Employee.update",emp);
		return 1;
	}



}
