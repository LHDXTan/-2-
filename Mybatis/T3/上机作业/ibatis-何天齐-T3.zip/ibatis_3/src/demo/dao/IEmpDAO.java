package demo.dao;

import java.util.List;

import demo.bean.Employee;

public interface IEmpDAO {
	public Object getObjectById(Integer id);
	public List getObjects();
	
	public List getObjects(Employee emp);
	
	public int add(Employee emp);
	public int update(Employee emp);
	public int delete(Employee emp);
}
