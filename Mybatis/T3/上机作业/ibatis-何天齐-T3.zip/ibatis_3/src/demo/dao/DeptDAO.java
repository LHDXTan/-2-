package demo.dao;

import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import demo.bean.Department;


public class DeptDAO extends SqlMapClientDaoSupport implements IDeptDAO{

	public List getObjects() {
		return super.getSqlMapClientTemplate().queryForList("Department.selectAll");
	}

	
}
