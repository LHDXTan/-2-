package demo.dao;

import java.util.List;

import demo.bean.Department;


public interface IDeptDAO {
	//查询
	public List getObjects();
  
	
	
}
