package demo.bean;


public class Employee  implements java.io.Serializable{
	private Integer oid; //主键属性
	private String empName; 
	private String school;
	private String phone;
	
	private Integer deptid;
	
	private Department dept;

	public Employee(){}
	
	public Employee(String empName,String school){
		this.empName = empName;
		this.school = school;
	}
	
	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public Integer getOid() {
		return oid;
	}

	public void setOid(Integer oid) {
		this.oid = oid;
	}


	public Integer getDeptid() {
		return deptid;
	}

	public void setDeptid(Integer deptid) {
		this.deptid = deptid;
	}



	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public String toString(){
		return "Emp[oid="+oid+",Name="+empName+",deptid="+deptid+"]";
	}
	
}
