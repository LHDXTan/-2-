package demo.web;

import java.util.List;

import com.opensymphony.xwork2.ActionSupport;

import demo.bean.Department;
import demo.bean.Employee;
import demo.dao.DeptDAO;
import demo.dao.EmpDAO;
import demo.dao.IDeptDAO;
import demo.dao.IEmpDAO;

public class EmpAction extends ActionSupport{

	private Employee emp;
	private List<Employee> emplist;	
	private List<Department> deptlist;
	
	private IEmpDAO empdao;
	private IDeptDAO deptdao;
	
	
	
	//查询加模糊
	public String list(){		
		emplist = empdao.getObjects(emp);
		deptlist = deptdao.getObjects();
		return "list";
	}	
	
	

	//点击添加跳转到这个方法
	public String toAdd(){
		deptlist = deptdao.getObjects();
		return "edit";
	}
	//添加
	public String add(){
		empdao.add(emp);
		return "emplist";
	}
	
	//点击修改进入这个方法
	public String toUpdate(){
		emp = (Employee)empdao.getObjectById( emp.getOid());	    
		deptlist = deptdao.getObjects();
		return "edit";
	}
	//修改方法
	public String update(){	    	    	
		empdao.update(emp);		
		return "emplist";
	}
	
	
	public String delete(){
		Employee emp1 = (Employee)empdao.getObjectById(emp.getOid());
		empdao.delete(emp1);
		return "emplist";
	}
	
//==============================================================
	public List<Employee> getEmplist() {
		return emplist;
	}

	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}
	
	
	public Employee getEmp() {
		return emp;
	}

	public void setEmp(Employee emp) {
		this.emp = emp;
	}
	
	public void setEmpdao(IEmpDAO empdao) {
		this.empdao = empdao;
	}


	public void setDeptdao(IDeptDAO deptdao) {
		this.deptdao = deptdao;
	}

	public List<Department> getDeptlist() {
		return deptlist;
	}

	public void setDeptlist(List<Department> deptlist) {
		this.deptlist = deptlist;
	}
		
}
