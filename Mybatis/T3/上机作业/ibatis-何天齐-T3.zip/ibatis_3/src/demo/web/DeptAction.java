package demo.web;


import java.util.List;

import com.opensymphony.xwork2.ActionSupport;

import demo.bean.Department;
import demo.bean.Employee;
import demo.dao.DeptDAO;
import demo.dao.IDeptDAO;
import demo.dao.IEmpDAO;


public class DeptAction extends ActionSupport{
	private IDeptDAO deptdao;
		
	private Department dept;

	private IEmpDAO empdao;
	private IDeptDAO deptdaoo;
	
	private List<Department> deptlist;
			
	private List<Employee> emplist;
	//查询
	public String list(){
		deptlist = deptdao.getObjects();			
		return "list";
	}
	
	//点击添加跳转到这个方法
		public String toAdd(){
			deptlist = deptdaoo.getObjects();
			return "edit";
		}
	


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	public List<Employee> getEmplist() {
		return emplist;
	}

	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}

	public List<Department> getDeptlist() {
		return deptlist;
	}

	public void setDeptlist(List<Department> deptlist) {
		this.deptlist = deptlist;
	}


	public Department getDept() {
		return dept;
	}


	public void setDept(Department dept) {
		this.dept = dept;
	}

	
	public void setDeptdao(IDeptDAO deptdao) {
		this.deptdao = deptdao;
	}				
}
